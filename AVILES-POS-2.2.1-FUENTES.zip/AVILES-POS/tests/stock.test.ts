import { describe, it, expect } from 'vitest';
import { fixture, product } from './support';
import { parseQuantity, costOf } from '../src/domain/stock';

describe('inventario inteligente', () => {
  it('cantidades exactas y costo sin redondeo flotante', () => {
    expect(parseQuantity('0.150')).toBe(150);
    expect(parseQuantity('1,001')).toBe(1001);
    expect(costOf(150, 32000)).toBe(4800);
    expect(() => parseQuantity('0.0001')).toThrow();
  });
  it('descuenta receta agregada solo al completar e impide el doble descuento', async () => {
    const { pos, db } = await fixture();
    const item = await pos.inventory.smart.saveItem({
      name: 'Carne',
      kind: 'ingredient',
      unit: 'kg',
      cost: 32000,
      lowStock: 1000,
      initialStock: 2000,
    });
    const pid = await product(pos, { track_stock: 0, stock: 0 });
    await pos.inventory.smart.saveRecipe(pid, [{ itemId: item, quantity: 150 }]);
    const { active } = await pos.snapshot();
    await pos.addProduct(active.id, pid);
    await pos.addProduct(active.id, pid);
    await pos.park(active.id, 'Mesa pendiente');
    expect((await pos.inventory.smart.snapshot()).items[0].stock).toBe(2000);
    await pos.resume(active.id);
    const receipt = await pos.checkout(active.id, 28000);
    expect(receipt.lines[0].cost_total).toBe(9600);
    expect((await pos.inventory.smart.snapshot()).items[0].stock).toBe(1700);
    await pos.checkout(active.id, 28000);
    expect(
      (await pos.inventory.smart.snapshot()).movements.filter((m) => m.kind === 'sale'),
    ).toHaveLength(1);
    expect(await db.read((s) => s.query('PRAGMA foreign_key_check'))).toEqual([]);
  });
  it('falta de ingredientes revierte pago, producto, receta y mesa', async () => {
    const { pos, db } = await fixture();
    const i = await pos.inventory.smart.saveItem({
      name: 'Pan',
      kind: 'ingredient',
      unit: 'pieza',
      cost: 1000,
      lowStock: 1000,
      initialStock: 1000,
    });
    const p = await product(pos, { track_stock: 0, stock: 0 });
    await pos.inventory.smart.saveRecipe(p, [{ itemId: i, quantity: 2000 }]);
    const { active } = await pos.snapshot();
    await pos.addProduct(active.id, p);
    await expect(pos.checkout(active.id, 14000)).rejects.toThrow('insuficientes');
    expect((await pos.inventory.smart.snapshot()).items[0].stock).toBe(1000);
    expect(await db.read((s) => s.query('SELECT * FROM payments'))).toEqual([]);
  });
  it('vuelve de receta a producto sin borrar receta, movimientos ni costos históricos', async () => {
    const { pos, db } = await fixture();
    const a = pos.inventory.smart;
    const item = await a.saveItem({
      name: 'Ingrediente conservado',
      kind: 'ingredient',
      unit: 'kg',
      cost: 1000,
      lowStock: 0,
      initialStock: 3000,
    });
    const pid = await product(pos, { track_stock: 0, stock: 0, cost: 4800 });
    await a.saveRecipe(pid, [{ itemId: item, quantity: 500 }]);
    const first = (await pos.snapshot()).active;
    await pos.addProduct(first.id, pid);
    const receipt = await pos.checkout(first.id, 14000);
    const before = await a.snapshot();
    expect(receipt.lines[0].cost_total).toBe(500);

    await a.useProductStock(pid, 0, 'Usaremos producto terminado');
    const changed = await a.snapshot();
    expect(changed.products[0]).toMatchObject({
      inventory_mode: 'product',
      track_stock: 1,
      stock: 0,
      cost: 4800,
    });
    expect(changed.recipes).toEqual(before.recipes);
    expect(changed.items).toEqual(before.items);
    expect(changed.movements).toEqual(before.movements);
    expect(
      await db.read((s) =>
        s.query('SELECT expected,counted FROM inventory_counts WHERE product_id=?', [pid]),
      ),
    ).toEqual([{ expected: 0, counted: 0 }]);
    expect((await pos.inventory.snapshot({ productId: pid })).movements[0]).toMatchObject({
      kind: 'count',
      quantity: 0,
      before_stock: 0,
      after_stock: 0,
    });
    await pos.inventory.move({
      productId: pid,
      kind: 'receipt',
      quantity: 2,
      reason: 'Producto terminado recibido',
    });
    const next = (await pos.snapshot()).active;
    await pos.addProduct(next.id, pid);
    const directReceipt = await pos.checkout(next.id, 14000);
    expect(directReceipt.lines[0].cost_total).toBe(4800);
    expect((await a.snapshot()).items[0].stock).toBe(2500);
    expect((await pos.snapshot()).products[0].stock).toBe(1);
    expect((await pos.getReceipt(first.id)).lines[0].cost_total).toBe(500);
    const actions = await db.read((s) =>
      s.query<{ details: string }>(
        "SELECT details FROM administrative_actions WHERE action='recipe.use_product_stock' AND target=?",
        [pid],
      ),
    );
    expect(actions).toHaveLength(1);
    expect(JSON.parse(actions[0].details)).toMatchObject({
      reason: 'Usaremos producto terminado',
      recipePreserved: true,
      stock: 0,
      counted: 0,
    });
    await pos.inventory.move({
      productId: pid,
      kind: 'count',
      quantity: 0,
      reason: 'Cambio documentado',
    });
    await a.saveRecipe(
      pid,
      before.recipes.map((r) => ({ itemId: r.item_id, quantity: r.quantity })),
    );
    expect((await a.snapshot()).products[0].inventory_mode).toBe('recipe');
  });
  it('cambiar de receta exige permisos y revierte si no se puede persistir', async () => {
    const { pos, db, persistence } = await fixture();
    const a = pos.inventory.smart;
    const item = await a.saveItem({
      name: 'Pan conservado',
      kind: 'ingredient',
      unit: 'pieza',
      cost: 1000,
      lowStock: 0,
    });
    const pid = await product(pos, { track_stock: 0, stock: 7 });
    await a.saveRecipe(pid, [{ itemId: item, quantity: 1000 }]);
    const before = await a.snapshot();
    persistence.fail = true;
    await expect(a.useProductStock(pid, 3, 'Cambio de prueba')).rejects.toThrow('disk full');
    persistence.fail = false;
    expect((await a.snapshot()).products).toEqual(before.products);
    expect((await a.snapshot()).recipes).toEqual(before.recipes);
    expect(await db.read((s) => s.query('SELECT * FROM inventory_counts'))).toEqual([]);
    await pos.access.save({
      name: 'Solo inventario',
      identifier: 'stock',
      role: 'cashier',
      active: 1,
      pin: '739154',
      permissions: ['inventory'],
    });
    await pos.access.login('739154');
    await expect(a.useProductStock(pid, 3, 'Intento sin permiso')).rejects.toThrow('Sin permiso');
    expect((await a.snapshot()).products).toEqual(before.products);
    await pos.access.login('832641');
    expect(() => a.useProductStock(pid, -1, 'Conteo imposible')).toThrow();
    await a.useProductStock(pid, 3, 'Conteo físico al cambiar de control');
    expect((await a.snapshot()).products[0]).toMatchObject({
      stock: 3,
      cost: 4800,
      track_stock: 1,
      inventory_mode: 'product',
    });
    expect((await a.snapshot()).recipes).toEqual(before.recipes);
    expect((await a.snapshot()).items).toEqual(before.items);
    expect(
      await db.read((s) =>
        s.query('SELECT expected,counted FROM inventory_counts WHERE product_id=?', [pid]),
      ),
    ).toEqual([{ expected: 7, counted: 3 }]);
    expect((await pos.inventory.snapshot({ productId: pid })).movements[0]).toMatchObject({
      kind: 'count',
      quantity: -4,
      before_stock: 7,
      after_stock: 3,
    });
  });
  it('compras parciales, promedio ponderado, precios e idempotencia', async () => {
    const { pos } = await fixture();
    const a = pos.inventory.smart;
    const item = await a.saveItem({
      name: 'Harina',
      kind: 'ingredient',
      unit: 'kg',
      cost: 1000,
      lowStock: 1000,
      initialStock: 1000,
    });
    const supplier = await a.saveSupplier({ name: 'Proveedor', phone: '', email: '', note: '' });
    const order = await a.createOrder({
      supplierId: supplier,
      note: 'Compra prueba',
      lines: [{ itemId: item, quantity: 3000, unitCost: 2000 }],
    });
    const line = (await a.snapshot()).orderLines[0];
    const request = {
      orderId: order,
      requestId: crypto.randomUUID(),
      lines: [{ lineId: line.id, quantity: 1000, unitCost: 2000 }],
    };
    await a.receive(request);
    await a.receive(request);
    const s = await a.snapshot();
    expect(s.items[0].stock).toBe(2000);
    expect(s.items[0].cost).toBe(1500);
    expect(s.orders[0].status).toBe('partial');
    expect(s.variations).toHaveLength(1);
    await expect(
      a.receive({
        ...request,
        requestId: crypto.randomUUID(),
        lines: [{ ...request.lines[0], quantity: 3000 }],
      }),
    ).rejects.toThrow('supera');
    expect((await a.snapshot()).items[0].stock).toBe(2000);
    await a.receive({
      ...request,
      requestId: crypto.randomUUID(),
      lines: [{ ...request.lines[0], quantity: 2000 }],
    });
    expect((await a.snapshot()).orders[0].status).toBe('received');
  });
  it('conteos guardan diferencias y exigen autorización y stock vigente', async () => {
    const { pos } = await fixture();
    const a = pos.inventory.smart;
    const item = await a.saveItem({
      name: 'Azúcar',
      kind: 'ingredient',
      unit: 'kg',
      cost: 1000,
      lowStock: 0,
      initialStock: 2000,
    });
    const count = await a.count({ itemId: item, counted: 1500, reason: 'Conteo semanal' });
    expect((await a.snapshot()).items[0].stock).toBe(2000);
    await a.approveCount(count);
    const s = await a.snapshot();
    expect(s.items[0].stock).toBe(1500);
    expect(s.counts[0].status).toBe('approved');
    expect(s.counts[0].expected).toBe(2000);
    await expect(a.approveCount(count)).rejects.toThrow('resuelto');
    const stale = await a.count({ itemId: item, counted: 1000, reason: 'Nuevo conteo' });
    const changed = await a.count({ itemId: item, counted: 1200, reason: 'Otro conteo' });
    await a.approveCount(changed);
    await expect(a.approveCount(stale)).rejects.toThrow('cambiaron');
    await a.approveCount(stale, false);
  });
  it('rollback de recepción si el archivo no se guarda', async () => {
    const { pos, persistence } = await fixture();
    const a = pos.inventory.smart;
    const item = await a.saveItem({
      name: 'Sal',
      kind: 'supply',
      unit: 'kg',
      cost: 100,
      lowStock: 0,
    });
    const supplier = await a.saveSupplier({ name: 'Proveedor', phone: '', email: '', note: '' });
    const order = await a.createOrder({
      supplierId: supplier,
      note: '',
      lines: [{ itemId: item, quantity: 1000, unitCost: 100 }],
    });
    const line = (await a.snapshot()).orderLines[0];
    persistence.fail = true;
    await expect(
      a.receive({
        orderId: order,
        requestId: crypto.randomUUID(),
        lines: [{ lineId: line.id, quantity: 1000, unitCost: 100 }],
      }),
    ).rejects.toThrow('disk full');
    persistence.fail = false;
    expect((await a.snapshot()).items[0].stock).toBe(0);
    expect((await a.snapshot()).orders[0].status).toBe('ordered');
  });
});

it('una orden recibe productos de venta en el libro original, sin duplicar inventario', async () => {
  const { pos } = await fixture();
  const p = await product(pos, { stock: 10, cost: 1000 });
  const a = pos.inventory.smart;
  const supplier = await a.saveSupplier({
    name: 'Proveedor de productos',
    phone: '',
    email: '',
    note: '',
  });
  const order = await a.createOrder({
    supplierId: supplier,
    note: 'Mercancía',
    lines: [{ productId: p, quantity: 2000, unitCost: 2200 }],
  });
  const line = (await a.snapshot()).orderLines[0];
  expect(line.product_id).toBe(p);
  await a.receive({
    orderId: order,
    requestId: crypto.randomUUID(),
    lines: [{ lineId: line.id, quantity: 2000, unitCost: 2200 }],
  });
  const s = await pos.snapshot();
  expect(s.products[0]).toMatchObject({ stock: 12, cost: 1200 });
  expect((await pos.inventory.snapshot()).movements[0]).toMatchObject({
    kind: 'receipt',
    quantity: 2,
    unit_cost: 2200,
  });
  expect((await a.snapshot()).items).toHaveLength(0);
});
