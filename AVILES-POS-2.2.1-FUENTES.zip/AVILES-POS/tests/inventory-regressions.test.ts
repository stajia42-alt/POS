import { describe, expect, it } from 'vitest';
import { fixture, product } from './support';

async function shortage() {
  const context = await fixture();
  const { pos } = context;
  const pid = await product(pos, { stock: 0, price: 1000, cost: 200 });
  const { active, business } = await pos.snapshot();
  await pos.saveBusiness({ ...business, inventoryPolicy: 'allow_negative' });
  await pos.addProduct(active.id, pid);
  const line = (await pos.snapshot()).lines[0];
  await pos.updateLine(active.id, line.id, 5, '');
  await pos.checkout(active.id, 5000);
  return { ...context, pid };
}

describe('recuperación de existencias negativas autorizadas por ventas', () => {
  it('permite editar el producto y reducir su faltante después de bloquear ventas negativas', async () => {
    const { pos, pid } = await shortage();
    const { business, products, active } = await pos.snapshot();
    await pos.saveBusiness({ ...business, inventoryPolicy: 'block' });
    const original = products.find((p) => p.id === pid)!;
    expect(original.stock).toBe(-5);

    await pos.saveProduct({ ...original, name: 'Nombre corregido' });
    expect((await pos.snapshot()).products.find((p) => p.id === pid)).toMatchObject({
      name: 'Nombre corregido',
      stock: -5,
    });
    await expect(pos.saveProduct({ ...original, stock: -3 })).rejects.toThrow('motivo');
    await pos.saveProduct({ ...original, stock: -3 }, 'Revisión física del faltante');
    await expect(pos.saveProduct({ ...original, stock: -4 }, 'Ajuste')).rejects.toThrow(
      'aumentar existencias negativas',
    );
    await pos.addProduct(active.id, pid);
    await expect(pos.checkout(active.id, 1000)).rejects.toThrow('insuficientes');
    expect((await pos.snapshot()).products.find((p) => p.id === pid)!.stock).toBe(-3);
  });

  it('recibe mercancía parcial, exacta y excedente sin promediar cantidades negativas', async () => {
    const { pos, pid } = await shortage();
    await pos.saveBusiness({ ...(await pos.snapshot()).business, inventoryPolicy: 'block' });
    for (const [quantity, unitCost, stock] of [
      [2, 400, -3],
      [3, 500, 0],
      [1, 600, 1],
    ]) {
      await pos.inventory.move({
        productId: pid,
        kind: 'receipt',
        quantity,
        unitCost,
        reason: 'Reposición del faltante',
      });
      expect((await pos.snapshot()).products.find((p) => p.id === pid)).toMatchObject({
        stock,
        cost: unitCost,
      });
    }
    await pos.inventory.move({
      productId: pid,
      kind: 'receipt',
      quantity: 1,
      unitCost: 800,
      reason: 'Siguiente reposición',
    });
    expect((await pos.snapshot()).products.find((p) => p.id === pid)).toMatchObject({
      stock: 2,
      cost: 700,
    });
    const snapshot = await pos.inventory.snapshot({ productId: pid });
    expect(snapshot.movements.filter((m) => m.kind === 'receipt').map((m) => m.quantity)).toEqual([
      1, 1, 3, 2,
    ]);
  });

  it('un movimiento manual puede corregir el faltante, pero no aumentarlo', async () => {
    const { pos, pid, db } = await shortage();
    await expect(
      pos.inventory.move({ productId: pid, kind: 'issue', quantity: 1, reason: 'Salida' }),
    ).rejects.toThrow('supera');
    await expect(
      pos.inventory.move({ productId: pid, kind: 'adjustment', quantity: -1, reason: 'Ajuste' }),
    ).rejects.toThrow('supera');
    await pos.inventory.move({
      productId: pid,
      kind: 'adjustment',
      quantity: 1,
      reason: 'Corrección parcial',
    });
    expect((await pos.snapshot()).products.find((p) => p.id === pid)!.stock).toBe(-4);
    await pos.inventory.move({ productId: pid, kind: 'count', quantity: 0, reason: 'Conteo real' });
    expect((await pos.snapshot()).products.find((p) => p.id === pid)!.stock).toBe(0);
    expect(
      await db.read((sql) =>
        sql.query('SELECT expected,counted FROM inventory_counts WHERE product_id=?', [pid]),
      ),
    ).toEqual([{ expected: -4, counted: 0 }]);
  });

  it('la política de ventas negativas no permite crear faltantes desde el catálogo o movimientos', async () => {
    const { pos } = await fixture();
    await pos.saveBusiness({
      ...(await pos.snapshot()).business,
      inventoryPolicy: 'allow_negative',
    });
    await expect(product(pos, { stock: -1 })).rejects.toThrow('generar');
    const pid = await product(pos, { stock: 2 });
    const original = (await pos.snapshot()).products.find((p) => p.id === pid)!;
    await expect(pos.saveProduct({ ...original, stock: -1 }, 'Ajuste')).rejects.toThrow('generar');
    await expect(
      pos.inventory.move({ productId: pid, kind: 'issue', quantity: 3, reason: 'Salida' }),
    ).rejects.toThrow('supera');
    expect((await pos.snapshot()).products.find((p) => p.id === pid)!.stock).toBe(2);
  });
});
