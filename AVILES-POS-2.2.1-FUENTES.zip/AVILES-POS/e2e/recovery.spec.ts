import { test, expect } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
import { createProduct, navigate, ready } from './helpers';

test('venta legible e inventario directo sin obligar a configurar recetas', async ({ page }) => {
  await page.setViewportSize({ width: 893, height: 533 });
  await ready(page);
  const name = 'Café americano para llevar';
  await createProduct(page, name, '40.00', true, undefined, 10);
  await navigate(page, 'Punto de venta');
  const card = page.getByRole('button', { name: `Agregar ${name}`, exact: true });
  await expect(card).toBeVisible();
  await expect(card.getByText(name, { exact: true })).toBeVisible();
  await expect(card.getByText('$40.00 MXN', { exact: true })).toBeVisible();
  const photo = await card.locator('img').boundingBox();
  const caption = await card.locator('.product-caption').boundingBox();
  expect(photo!.y + photo!.height).toBeLessThanOrEqual(caption!.y + 1);
  const catalogue = await page.locator('.main-panel').boundingBox();
  expect(catalogue!.width).toBeGreaterThan(893 * 0.6);
  await card.click();
  await expect(page.getByTestId('ticket-total')).toHaveText('$40.00 MXN');
  await expect(page.getByRole('button', { name: 'COBRAR', exact: true })).toBeInViewport();
  await mkdir('docs/capturas/2.2.1', { recursive: true });
  await page.screenshot({
    path: 'docs/capturas/2.2.1/28-venta-tableta.png',
    animations: 'disabled',
  });

  await navigate(page, 'Inventario');
  await expect(
    page.getByRole('button', { name: 'Ingredientes e insumos', exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole('button', { name: 'Registrar movimiento', exact: true }),
  ).toBeVisible();
  await page.getByRole('button', { name: 'Registrar movimiento', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await dialog
    .getByRole('combobox', { name: 'Producto', exact: true })
    .selectOption({ label: `${name} · 10 pieza` });
  await dialog.getByLabel('Cantidad de unidades', { exact: true }).fill('3');
  await dialog
    .getByLabel('Motivo', { exact: true })
    .fill('Entrada de prueba sin configurar recetas');
  await dialog.getByRole('button', { name: 'Guardar movimiento', exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await expect(
    page.locator('table').first().getByRole('row').filter({ hasText: name }),
  ).toContainText('13 pieza');
  await page.screenshot({
    path: 'docs/capturas/2.2.1/29-inventario-directo.png',
    animations: 'disabled',
  });

  await page.getByRole('button', { name: 'Más opciones de inventario', exact: true }).click();
  await page.getByRole('button', { name: 'Recetas', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Recetas y costos', exact: true })).toBeVisible();
  await page
    .getByRole('button', { name: 'Volver al inventario de productos', exact: true })
    .click();
  await expect(
    page.getByRole('button', { name: 'Ingredientes e insumos', exact: true }),
  ).toHaveCount(0);
  await expect(
    page.locator('table').first().getByRole('row').filter({ hasText: name }),
  ).toContainText('13 pieza');
});
