import { test, expect, type Page } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
import { createProduct, navigate, signIn, unlock } from './helpers';
const path = 'docs/capturas/2.2.1';
async function fit(page: Page) {
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  const modal = page.getByRole('dialog');
  if (await modal.count()) {
    const box = (await modal.boundingBox())!;
    const size = page.viewportSize()!;
    expect(box.x).toBeGreaterThanOrEqual(0);
    expect(box.y).toBeGreaterThanOrEqual(0);
    expect(box.x + box.width).toBeLessThanOrEqual(size.width + 1);
    expect(box.y + box.height).toBeLessThanOrEqual(size.height + 1);
  }
}
async function shot(page: Page, name: string) {
  if (await page.getByTestId('app-ready').count())
    await expect(page.getByTestId('app-ready')).toHaveAttribute('aria-busy', 'false');
  await page.evaluate(() => document.fonts.ready);
  await fit(page);
  await page.screenshot({ animations: 'disabled', path: `${path}/${name}.png` });
}

test('referencias del rediseño y revisión de pantallas principales', async ({ page }) => {
  test.setTimeout(90000);
  await mkdir(path, { recursive: true });
  await page.goto('/');
  await signIn(page);
  await shot(page, '02-apertura');
  await page.getByLabel('Fondo inicial de caja (MXN)', { exact: true }).fill('100.00');
  await page.getByLabel('Tipo de cambio · MXN por 1 USD', { exact: true }).fill('18.0000');
  await page.getByRole('button', { name: 'ABRIR TURNO', exact: true }).click();
  await shot(page, '03-ventas-vacio');
  await navigate(page, 'Categorías');
  await page.getByRole('button', { name: 'Crear categoría', exact: true }).click();
  await page.getByLabel('Nombre de la categoría', { exact: true }).fill('Cocina de prueba');
  await page.getByRole('button', { name: 'Guardar categoría', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await createProduct(page, 'Hamburguesa de prueba', '140.00', true, 'Cocina de prueba', 20);
  await createProduct(page, 'Agua de prueba', '35.00', false, undefined, 30);
  await createProduct(page, 'Café de prueba', '40.00', true, undefined, 25);
  await shot(page, '04-productos');
  await navigate(page, 'Punto de venta');
  await page.getByRole('button', { name: 'Agregar Hamburguesa de prueba', exact: true }).click();
  await expect(
    page.getByRole('button', { name: 'Cantidad de Hamburguesa de prueba', exact: true }),
  ).toHaveText('1');
  await page.getByRole('button', { name: 'Agregar Agua de prueba', exact: true }).click();
  await expect(page.getByTestId('ticket-total')).toHaveText('$175.00 MXN');
  await shot(page, '13-ticket-cuadricula');
  await page.getByRole('button', { name: 'Ver como lista', exact: true }).click();
  await shot(page, '14-lista');
  await page.getByRole('button', { name: 'Ver como cuadrícula', exact: true }).click();
  await page.getByRole('button', { name: 'Cantidad de Agua de prueba', exact: true }).click();
  await shot(page, '16-edicion-cantidad');
  await page.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
  await page.getByRole('button', { name: 'Opciones del ticket', exact: true }).click();
  await shot(page, '17-opciones-ticket');
  await page.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
  await page.getByRole('button', { name: 'COBRAR', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Confirmar cobro', exact: true })).toBeInViewport();
  await page.getByLabel('Efectivo recibido (MXN)', { exact: true }).fill('200');
  await shot(page, '15-cobro');
  await page.getByRole('button', { name: 'Confirmar cobro', exact: true }).click();
  await expect(page.getByTestId('receipt')).toBeVisible();
  await shot(page, '18-recibo');
  await page.getByRole('button', { name: 'Nueva venta', exact: true }).click();
  await navigate(page, 'Productos');
  await page.getByRole('button', { name: 'Crear producto', exact: true }).first().click();
  await shot(page, '12-producto-formulario');
  await page.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
  await navigate(page, 'Clientes');
  await page.getByRole('button', { name: 'Crear cliente', exact: true }).click();
  await page.getByLabel('Nombre del cliente', { exact: true }).fill('Cliente de prueba');
  await page.getByRole('button', { name: 'Guardar cliente', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await shot(page, '06-clientes');
  await navigate(page, 'Empleados');
  await expect(page.getByRole('heading', { name: 'Empleados', exact: true }).first()).toBeVisible();
  await shot(page, '07-empleados');
  await navigate(page, 'Inventario');
  await page.getByRole('button', { name: 'Más opciones de inventario', exact: true }).click();
  await expect(
    page.getByRole('button', { name: 'Registrar movimiento', exact: true }),
  ).toBeVisible();
  await expect(page.getByText('Valor a costo · productos activos', { exact: true })).toBeVisible();
  await shot(page, '05-inventario');
  await page.getByRole('button', { name: 'Ingredientes e insumos', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Crear insumo', exact: true })).toBeVisible();
  await shot(page, '19-insumos');
  await page.getByRole('button', { name: 'Recetas', exact: true }).click();
  await shot(page, '20-recetas');
  await page.getByRole('button', { name: 'Compras y proveedores', exact: true }).click();
  await shot(page, '21-compras');
  await page.getByRole('button', { name: 'Conteos de insumos', exact: true }).click();
  await shot(page, '22-conteos');
  await navigate(page, 'Reportes');
  await expect(page.getByTestId('report-total')).toHaveText('$175.00 MXN');
  await shot(page, '23-reportes');
  await page.getByRole('button', { name: 'Productos y costos', exact: true }).click();
  await shot(page, '24-costos');
  await navigate(page, 'Respaldos');
  await expect(
    page.getByText('Integridad SQLite y referencias correctas', { exact: true }),
  ).toBeVisible();
  await shot(page, '25-respaldos');
  await navigate(page, 'Configuración');
  await shot(page, '09-configuracion');
  await navigate(page, 'Historial de ventas');
  await shot(page, '10-historial');
  await navigate(page, 'Caja y turnos');
  await expect(page.getByText('Turno abierto', { exact: true })).toBeVisible();
  await shot(page, '08-caja');
  await page.getByRole('button', { name: 'Cerrar turno', exact: true }).click();
  await shot(page, '26-cierre-caja');
  await page.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
  await navigate(page, 'Punto de venta');
  await page.getByRole('button', { name: 'Mesas', exact: true }).click();
  await page.getByRole('button', { name: 'Crear primera área', exact: true }).click();
  await page.getByLabel('Nombre del área', { exact: true }).fill('Salón de prueba');
  await page.getByRole('button', { name: 'Guardar área', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Agregar mesa', exact: true }).click();
  await page.getByLabel('Nombre de la mesa', { exact: true }).fill('1');
  await page.getByRole('button', { name: 'Guardar mesa', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Terminar edición', exact: true }).click();
  await shot(page, '11-mesas');
  for (const size of [
    { width: 1024, height: 600 },
    { width: 960, height: 600 },
    { width: 893, height: 533 },
    { width: 390, height: 844 },
  ]) {
    await page.setViewportSize(size);
    await fit(page);
    await page.getByRole('button', { name: 'Venta rápida', exact: true }).click();
    await expect(
      page.getByRole('button', { name: 'Agregar Agua de prueba', exact: true }),
    ).toBeVisible();
    await fit(page);
    await page.getByRole('button', { name: 'Agregar Agua de prueba', exact: true }).click();
    if (size.width <= 760) await page.getByRole('button', { name: /Ver ticket/ }).click();
    await page.getByRole('button', { name: 'COBRAR', exact: true }).click();
    await expect(
      page.getByRole('button', { name: 'Confirmar cobro', exact: true }),
    ).toBeInViewport();
    await fit(page);
    await page.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
    await shot(page, `27-adaptable-${size.width}`);
    if (size.width <= 760)
      await page.getByRole('button', { name: 'Volver a productos', exact: true }).click();
  }
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.getByRole('button', { name: 'Abrir menú', exact: true }).click();
  await page.getByRole('button', { name: 'Bloquear y cambiar empleado', exact: true }).click();
  await page.getByRole('heading', { name: 'Bienvenido a AVILES POS', exact: true }).waitFor();
  await shot(page, '01-pin');
  await unlock(page);
});
