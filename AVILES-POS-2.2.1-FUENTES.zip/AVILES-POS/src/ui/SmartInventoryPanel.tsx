import { useState, type FormEvent } from 'react';
import { Plus, Pencil, Package, Truck, ChefHat, ClipboardCheck, X } from 'lucide-react';
import { money, parseMoney } from '../domain/money';
import {
  costOf,
  parseQuantity,
  quantityText,
  UNITS,
  type StockItem,
  type Order,
  type Supplier,
} from '../domain/stock';
import { Modal } from './Modal';
import { useModule } from './useModule';
import type { ModuleProps } from './moduleTypes';

export type InventoryTab = 'products' | 'materials' | 'recipes' | 'purchases' | 'counts';
const orderStatus = {
  ordered: 'Por recibir',
  partial: 'Recepción parcial',
  received: 'Recibida',
  cancelled: 'Restante cancelado',
};
const value = (f: FormData, k: string) => String(f.get(k) || '');
const decimal = (n: number, scale = 1000) => (n / scale).toFixed(scale === 1000 ? 3 : 2);
const safeQty = (s: string) => {
  try {
    return parseQuantity(s);
  } catch {
    return 0;
  }
};
export function SmartInventoryPanel({
  pos,
  actor,
  onChanged,
  onLock,
  tab,
}: ModuleProps & { tab: InventoryTab }) {
  const m = useModule(() => pos.inventory.smart.snapshot(), onChanged, onLock);
  const [dialog, setDialog] = useState<
    | 'item'
    | 'recipe'
    | 'productStock'
    | 'supplier'
    | 'order'
    | 'receive'
    | 'cancelOrder'
    | 'count'
    | null
  >(null);
  const [item, setItem] = useState<StockItem>();
  const [supplier, setSupplier] = useState<Supplier>();
  const [order, setOrder] = useState<Order>();
  const [productId, setProductId] = useState('');
  const [recipe, setRecipe] = useState<{ itemId: string; quantity: string }[]>([]);
  const [orderRows, setOrderRows] = useState<{ itemId: string; quantity: string; cost: string }[]>(
    [],
  );
  const [requestId, setRequestId] = useState('');
  const canWrite = actor.permissions.includes('inventory');
  const canConfigureRecipe = canWrite && actor.permissions.includes('products');
  const data = m.data;
  const selectedProduct = data?.products.find((p) => p.id === productId);
  async function submit(e: FormEvent<HTMLFormElement>, action: (f: FormData) => Promise<unknown>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    if (await m.run(() => action(f))) setDialog(null);
  }
  function editRecipe(id: string) {
    setProductId(id);
    setRecipe(
      (data?.recipes.filter((r) => r.product_id === id) || []).map((r) => ({
        itemId: r.item_id,
        quantity: decimal(r.quantity),
      })),
    );
    setDialog('recipe');
  }
  const title =
    tab === 'materials'
      ? 'Ingredientes e insumos'
      : tab === 'recipes'
        ? 'Recetas y costos'
        : tab === 'purchases'
          ? 'Compras y proveedores'
          : 'Conteos físicos';
  return (
    <section className="admin-content smart-inventory">
      <div className="section-heading">
        <div>
          <p className="eyebrow">CONTROL DE COSTOS</p>
          <h1>{title}</h1>
          <p>
            {tab === 'recipes'
              ? 'Costos y margen bruto estimado; no representan utilidad neta.'
              : tab === 'purchases'
                ? 'Recibe mercancía por partes, con costos y trazabilidad.'
                : tab === 'counts'
                  ? 'Compara, revisa y autoriza diferencias antes de ajustar.'
                  : 'Existencias precisas y alertas para tu cocina y operación.'}
          </p>
        </div>
        {canWrite && (tab !== 'recipes' || canConfigureRecipe) && (
          <button
            className="primary"
            onClick={() => {
              m.setError('');
              if (tab === 'materials') {
                setItem(undefined);
                setDialog('item');
              }
              if (tab === 'recipes') editRecipe(data?.products[0]?.id || '');
              if (tab === 'purchases') {
                setOrderRows([{ itemId: data?.items[0]?.id || '', quantity: '1.000', cost: '' }]);
                setDialog('order');
              }
              if (tab === 'counts') setDialog('count');
            }}
          >
            <Plus size={19} />
            {tab === 'materials'
              ? 'Crear insumo'
              : tab === 'recipes'
                ? 'Configurar receta'
                : tab === 'purchases'
                  ? 'Crear orden'
                  : 'Registrar conteo'}
          </button>
        )}
      </div>
      {m.error && !dialog && (
        <p className="inline-error" role="alert">
          {m.error}
        </p>
      )}
      {m.notice && (
        <p className="module-notice" role="status">
          {m.notice}
        </p>
      )}
      {!data ? (
        <p role="status">Cargando inventario…</p>
      ) : (
        <>
          {tab === 'materials' && (
            <>
              <div className="metric-grid">
                <div>
                  <small>Valuación de insumos activos</small>
                  <strong>{money(data.valuation)}</strong>
                </div>
                <div>
                  <small>Agotados o debajo del mínimo</small>
                  <strong>
                    {data.items.filter((i) => i.active && i.stock <= i.low_stock).length}
                  </strong>
                </div>
              </div>
              {data.variations.length > 0 && (
                <div className="stock-alert">
                  <Truck size={22} />
                  <div>
                    <strong>Variación de costo de compra ≥ 20%</strong>
                    <p>
                      {data.variations
                        .slice(0, 5)
                        .map(
                          (v) =>
                            `${v.item_name}: ${money(v.previous_cost)} → ${money(v.unit_cost)}`,
                        )
                        .join(' · ')}
                    </p>
                  </div>
                </div>
              )}
              {!data.items.length ? (
                <div className="empty-state">
                  <Package />
                  <h2>Controla cada ingrediente</h2>
                  <p>Registra unidades, costos y mínimos para comenzar.</p>
                </div>
              ) : (
                <div className="table-scroll">
                  <table className="module-table">
                    <thead>
                      <tr>
                        <th>Ingrediente / insumo</th>
                        <th>Existencia / mínimo</th>
                        <th>Costo por unidad</th>
                        <th>Estado</th>
                        <th />
                      </tr>
                    </thead>
                    <tbody>
                      {data.items.map((i) => (
                        <tr key={i.id}>
                          <td>
                            <strong>{i.name}</strong>
                            <small>
                              {i.kind === 'ingredient' ? 'Ingrediente' : 'Insumo'} · {i.unit}
                            </small>
                          </td>
                          <td>
                            {quantityText(i.stock)} / {quantityText(i.low_stock)} {i.unit}
                          </td>
                          <td>{money(i.cost)}</td>
                          <td>
                            <span
                              className={`state-pill ${i.stock <= i.low_stock ? 'warning' : ''}`}
                            >
                              {!i.active
                                ? 'Inactivo'
                                : i.stock <= 0
                                  ? 'Agotado'
                                  : i.stock <= i.low_stock
                                    ? 'Stock bajo'
                                    : 'Disponible'}
                            </span>
                          </td>
                          <td>
                            {canWrite && (
                              <button
                                className="icon-button"
                                aria-label={`Editar insumo ${i.name}`}
                                onClick={() => {
                                  setItem(i);
                                  setDialog('item');
                                }}
                              >
                                <Pencil size={18} />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <h2>Movimientos y precios recientes</h2>
              <p className="field-hint">
                Últimos 100 movimientos. Las cantidades se expresan en la unidad de cada insumo.
              </p>
              <div className="table-scroll">
                <table className="module-table">
                  <thead>
                    <tr>
                      <th>Fecha / insumo</th>
                      <th>Movimiento</th>
                      <th>Antes → después</th>
                      <th>Costo registrado</th>
                      <th>Empleado / motivo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.movements.map((v) => (
                      <tr key={v.id}>
                        <td>
                          {new Date(v.created_at).toLocaleString('es-MX')}
                          <small>{v.item_name}</small>
                        </td>
                        <td>
                          {quantityText(v.quantity)} {v.unit}
                        </td>
                        <td>
                          {quantityText(v.before_stock)} → {quantityText(v.after_stock)}
                        </td>
                        <td>
                          {money(v.unit_cost)} / {v.unit}
                        </td>
                        <td>
                          {v.actor_name}
                          <small>{v.reason}</small>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
          {tab === 'recipes' && (
            <div className="recipe-cards">
              {data.products.length ? (
                data.products.map((p) => {
                  const lines = data.recipes.filter((r) => r.product_id === p.id);
                  const cost = lines.reduce((n, r) => n + costOf(r.quantity, r.cost), 0);
                  return (
                    <article className="feature-card" key={p.id}>
                      <div className="card-title">
                        <ChefHat size={24} />
                        <h2>{p.name}</h2>
                        {canConfigureRecipe && (
                          <button
                            className="icon-button"
                            aria-label={`Receta de ${p.name}`}
                            onClick={() => editRecipe(p.id)}
                          >
                            <Pencil size={18} />
                          </button>
                        )}
                      </div>
                      {p.inventory_mode === 'recipe' ? (
                        <>
                          <div className="recipe-components">
                            {lines.map((r) => (
                              <div key={r.item_id}>
                                <span>
                                  {r.item_name} · {quantityText(r.quantity)} {r.unit}
                                </span>
                                <strong>{money(costOf(r.quantity, r.cost))}</strong>
                              </div>
                            ))}
                          </div>
                          <div className="cost-grid">
                            <div>
                              <small>Precio</small>
                              <strong>{money(p.price)}</strong>
                            </div>
                            <div>
                              <small>Costo receta</small>
                              <strong>{money(cost)}</strong>
                            </div>
                            <div>
                              <small>Margen bruto estimado</small>
                              <strong>{money(p.price - cost)}</strong>
                            </div>
                            <div>
                              <small>Porcentaje de costo</small>
                              <strong>
                                {p.price ? `${((cost * 100) / p.price).toFixed(2)}%` : 'Sin precio'}
                              </strong>
                            </div>
                          </div>
                          {canConfigureRecipe && (
                            <button
                              className="secondary"
                              onClick={() => {
                                m.setError('');
                                setProductId(p.id);
                                setDialog('productStock');
                              }}
                            >
                              Usar existencias del producto
                            </button>
                          )}
                        </>
                      ) : (
                        <p>
                          {p.inventory_mode === 'none'
                            ? 'Sin control de inventario.'
                            : 'Producto con costo directo; configura una receta para descontar ingredientes.'}
                        </p>
                      )}
                    </article>
                  );
                })
              ) : (
                <div className="empty-state">
                  <ChefHat />
                  <h2>Primero registra productos de venta</h2>
                  <p>Después podrás asociarles ingredientes desde aquí.</p>
                </div>
              )}
            </div>
          )}
          {tab === 'purchases' && (
            <>
              <div className="section-heading subheading">
                <h2>Proveedores</h2>
                {canWrite && (
                  <button
                    className="secondary"
                    onClick={() => {
                      setSupplier(undefined);
                      setDialog('supplier');
                    }}
                  >
                    <Plus size={18} />
                    Crear proveedor
                  </button>
                )}
              </div>
              <div className="supplier-list">
                {data.suppliers.map((s) => (
                  <button
                    disabled={!canWrite}
                    className="supplier-card"
                    key={s.id}
                    onClick={() => {
                      setSupplier(s);
                      setDialog('supplier');
                    }}
                  >
                    <Truck size={21} />
                    <span>
                      <strong>{s.name}</strong>
                      <small>{s.phone || s.email || 'Sin contacto registrado'}</small>
                    </span>
                    <Pencil size={16} />
                  </button>
                ))}
              </div>
              <h2>Órdenes de compra</h2>
              {!data.orders.length ? (
                <div className="empty-state">
                  <Truck />
                  <h2>Todo listo para tu próxima compra</h2>
                  <p>Crea un proveedor y una orden; las existencias cambian al recibirla.</p>
                </div>
              ) : (
                <div className="data-list">
                  {data.orders.map((o) => (
                    <div className="catalog-row" key={o.id}>
                      <div className="row-symbol">
                        <Truck />
                      </div>
                      <div className="grow">
                        <strong>
                          Compra #{o.number} · {o.supplier_name}
                        </strong>
                        <small>
                          {new Date(o.created_at).toLocaleString('es-MX')} · {o.note}
                        </small>
                        <small>
                          {data.orderLines
                            .filter((l) => l.order_id === o.id)
                            .map(
                              (l) =>
                                `${l.item_name}: ${quantityText(l.received)}/${quantityText(l.quantity)} ${l.unit}`,
                            )
                            .join(' · ')}
                        </small>
                      </div>
                      <div className="align-right">
                        <strong>
                          {money(
                            data.orderLines
                              .filter((l) => l.order_id === o.id)
                              .reduce((n, l) => n + costOf(l.quantity, l.unit_cost), 0),
                          )}
                        </strong>
                        <span className="state-pill">{orderStatus[o.status]}</span>
                      </div>
                      {canWrite && ['ordered', 'partial'].includes(o.status) && (
                        <>
                          <button
                            className="primary"
                            onClick={() => {
                              setOrder(o);
                              setRequestId(crypto.randomUUID());
                              setDialog('receive');
                            }}
                          >
                            Recibir
                          </button>
                          <button
                            className="icon-button danger-text"
                            aria-label={`Cancelar restante compra ${o.number}`}
                            onClick={() => {
                              setOrder(o);
                              setDialog('cancelOrder');
                            }}
                          >
                            <X size={19} />
                          </button>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
          {tab === 'counts' && (
            <>
              <p className="field-hint">
                Un conteo pendiente no modifica existencias. Si el stock cambia antes de
                autorizarlo, se exige volver a contar.
              </p>
              {!data.counts.length ? (
                <div className="empty-state">
                  <ClipboardCheck />
                  <h2>Sin conteos registrados</h2>
                  <p>Registra una cantidad física y solicita su autorización.</p>
                </div>
              ) : (
                <div className="table-scroll">
                  <table className="module-table">
                    <thead>
                      <tr>
                        <th>Insumo / empleado</th>
                        <th>Teórico</th>
                        <th>Contado</th>
                        <th>Diferencia</th>
                        <th>Estado / autorización</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.counts.map((c) => (
                        <tr key={c.id}>
                          <td>
                            <strong>{c.item_name}</strong>
                            <small>
                              {c.actor_name} · {new Date(c.created_at).toLocaleString('es-MX')}
                            </small>
                            <small>{c.reason}</small>
                          </td>
                          <td>
                            {quantityText(c.expected)} {c.unit}
                          </td>
                          <td>
                            {quantityText(c.counted)} {c.unit}
                          </td>
                          <td>
                            {quantityText(c.counted - c.expected)} {c.unit}
                          </td>
                          <td>
                            {c.status === 'pending' &&
                            canWrite &&
                            ['admin', 'supervisor'].includes(actor.role) ? (
                              <div className="inline-actions">
                                <button
                                  className="secondary"
                                  disabled={m.busy}
                                  onClick={() =>
                                    void m.run(() => pos.inventory.smart.approveCount(c.id))
                                  }
                                >
                                  Autorizar ajuste
                                </button>
                                <button
                                  className="danger-button"
                                  disabled={m.busy}
                                  onClick={() =>
                                    void m.run(() => pos.inventory.smart.approveCount(c.id, false))
                                  }
                                >
                                  Rechazar
                                </button>
                              </div>
                            ) : (
                              <span>
                                {c.status === 'approved'
                                  ? 'Autorizado'
                                  : c.status === 'rejected'
                                    ? 'Rechazado'
                                    : 'Pendiente'}
                                <small>{c.approved_name}</small>
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </>
      )}
      {dialog && data && (
        <Modal
          wide={dialog === 'order' || dialog === 'recipe' || dialog === 'receive'}
          title={
            dialog === 'item'
              ? item
                ? 'Editar insumo'
                : 'Nuevo ingrediente o insumo'
              : dialog === 'recipe'
                ? 'Configurar receta'
                : dialog === 'productStock'
                  ? 'Usar existencias del producto'
                  : dialog === 'supplier'
                    ? 'Proveedor'
                    : dialog === 'order'
                      ? 'Orden de compra'
                      : dialog === 'receive'
                        ? `Recibir compra #${order?.number}`
                        : dialog === 'count'
                          ? 'Conteo físico'
                          : 'Cancelar recepción restante'
          }
          onClose={() => {
            if (!m.busy) {
              setDialog(null);
              m.setError('');
            }
          }}
        >
          {m.error && (
            <p className="inline-error" role="alert">
              {m.error}
            </p>
          )}
          {dialog === 'item' && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) =>
                  pos.inventory.smart.saveItem({
                    id: item?.id,
                    name: value(f, 'name'),
                    kind: value(f, 'kind') as StockItem['kind'],
                    unit: value(f, 'unit') as StockItem['unit'],
                    cost: parseMoney(value(f, 'cost')),
                    lowStock: parseQuantity(value(f, 'low')),
                    initialStock: item ? undefined : parseQuantity(value(f, 'initial')),
                    active: f.has('active') ? 1 : 0,
                  }),
                )
              }
            >
              <label>
                Nombre del insumo
                <input name="name" required maxLength={120} defaultValue={item?.name} />
              </label>
              <div className="form-row">
                <label>
                  Tipo
                  <select aria-label="Tipo" name="kind" defaultValue={item?.kind || 'ingredient'}>
                    <option value="ingredient">Ingrediente</option>
                    <option value="supply">Insumo</option>
                  </select>
                </label>
                <label>
                  Unidad base
                  <select
                    aria-label="Unidad base"
                    name="unit"
                    defaultValue={item?.unit || 'pieza'}
                    disabled={!!item}
                  >
                    {UNITS.map((u) => (
                      <option key={u}>{u}</option>
                    ))}
                  </select>
                  {item && <input type="hidden" name="unit" value={item.unit} />}
                </label>
              </div>
              <p className="field-hint">
                La receta y las existencias usan esta misma unidad. Por ejemplo, carne en kg: receta
                0.150; costo por kg.
              </p>
              <div className="form-row">
                <label>
                  Costo por unidad (MXN)
                  <input
                    name="cost"
                    inputMode="decimal"
                    required
                    readOnly={!!item}
                    defaultValue={decimal(item?.cost || 0, 100)}
                  />
                </label>
                <label>
                  Existencia mínima
                  <input
                    name="low"
                    inputMode="decimal"
                    required
                    defaultValue={decimal(item?.low_stock || 0)}
                  />
                </label>
              </div>
              {!item && (
                <label>
                  Existencia inicial
                  <input name="initial" inputMode="decimal" required defaultValue="0.000" />
                </label>
              )}
              <label className="check-label">
                <input name="active" type="checkbox" defaultChecked={!item || !!item.active} />
                Activo
              </label>
              <button className="primary" disabled={m.busy}>
                Guardar insumo
              </button>
            </form>
          )}
          {dialog === 'recipe' && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, () =>
                  pos.inventory.smart.saveRecipe(
                    productId,
                    recipe.map((r) => ({ itemId: r.itemId, quantity: parseQuantity(r.quantity) })),
                  ),
                )
              }
            >
              <label>
                Producto de venta
                <select
                  aria-label="Producto de venta"
                  value={productId}
                  required
                  onChange={(e) => {
                    setProductId(e.target.value);
                    setRecipe(
                      data.recipes
                        .filter((r) => r.product_id === e.target.value)
                        .map((r) => ({ itemId: r.item_id, quantity: decimal(r.quantity) })),
                    );
                  }}
                >
                  <option value="">Selecciona un producto</option>
                  {data.products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </label>
              {recipe.map((r, i) => (
                <div className="recipe-edit-row" key={i}>
                  <label>
                    Ingrediente {i + 1}
                    <select
                      aria-label={`Ingrediente ${i + 1}`}
                      required
                      value={r.itemId}
                      onChange={(e) =>
                        setRecipe((old) =>
                          old.map((v, n) => (n === i ? { ...v, itemId: e.target.value } : v)),
                        )
                      }
                    >
                      <option value="">Selecciona</option>
                      {data.items
                        .filter((v) => v.active)
                        .map((v) => (
                          <option key={v.id} value={v.id}>
                            {v.name} ({v.unit})
                          </option>
                        ))}
                    </select>
                  </label>
                  <label>
                    Cantidad {i + 1}
                    <input
                      required
                      inputMode="decimal"
                      value={r.quantity}
                      onChange={(e) =>
                        setRecipe((old) =>
                          old.map((v, n) => (n === i ? { ...v, quantity: e.target.value } : v)),
                        )
                      }
                    />
                  </label>
                  <button
                    className="icon-button danger-text"
                    type="button"
                    aria-label={`Retirar ingrediente ${i + 1}`}
                    onClick={() => setRecipe((old) => old.filter((_, n) => n !== i))}
                  >
                    <X size={18} />
                  </button>
                </div>
              ))}
              <button
                className="secondary"
                type="button"
                onClick={() => setRecipe((old) => [...old, { itemId: '', quantity: '1.000' }])}
              >
                <Plus size={18} />
                Agregar ingrediente
              </button>
              <div className="metadata">
                <strong>
                  Costo estimado:{' '}
                  {money(
                    recipe.reduce(
                      (n, r) =>
                        n +
                        costOf(
                          safeQty(r.quantity),
                          data.items.find((i) => i.id === r.itemId)?.cost || 0,
                        ),
                      0,
                    ),
                  )}
                </strong>
                <span>Se descontará al completar la venta. No al guardar ni abrir una mesa.</span>
              </div>
              <button className="primary" disabled={m.busy || !recipe.length}>
                Guardar receta
              </button>
            </form>
          )}
          {dialog === 'productStock' && selectedProduct && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) =>
                  pos.inventory.smart.useProductStock(
                    productId,
                    Number(value(f, 'counted')),
                    value(f, 'reason'),
                  ),
                )
              }
            >
              <p>
                <strong>{selectedProduct.name}</strong> dejará de descontar ingredientes. Sus
                próximas ventas descontarán existencias del producto terminado.
              </p>
              <p>
                Registro anterior del producto:{' '}
                <strong>
                  {selectedProduct.stock} {selectedProduct.unit}
                </strong>
                . Puede estar desactualizado. Cuenta el producto terminado antes de continuar. Costo
                por producto conservado: <strong>{money(selectedProduct.cost)}</strong>.
              </p>
              <p className="field-hint">
                La receta queda guardada para volver a usarla. Se conservan los ingredientes,
                movimientos y costos de las ventas anteriores.
              </p>
              <label>
                Existencias contadas del producto
                <input name="counted" type="number" min="0" max="999999" step="1" required />
              </label>
              <label>
                Motivo del cambio de control
                <input name="reason" required maxLength={500} />
              </label>
              <button className="primary" disabled={m.busy}>
                Confirmar control por producto
              </button>
            </form>
          )}
          {dialog === 'supplier' && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) =>
                  pos.inventory.smart.saveSupplier({
                    id: supplier?.id,
                    name: value(f, 'name'),
                    phone: value(f, 'phone'),
                    email: value(f, 'email'),
                    note: value(f, 'note'),
                  }),
                )
              }
            >
              <label>
                Nombre del proveedor
                <input name="name" required maxLength={120} defaultValue={supplier?.name} />
              </label>
              <div className="form-row">
                <label>
                  Teléfono proveedor
                  <input name="phone" maxLength={40} defaultValue={supplier?.phone} />
                </label>
                <label>
                  Correo proveedor
                  <input name="email" type="email" maxLength={150} defaultValue={supplier?.email} />
                </label>
              </div>
              <label>
                Notas proveedor
                <textarea name="note" maxLength={500} defaultValue={supplier?.note} />
              </label>
              <button className="primary" disabled={m.busy}>
                Guardar proveedor
              </button>
            </form>
          )}
          {dialog === 'order' && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) =>
                  pos.inventory.smart.createOrder({
                    supplierId: value(f, 'supplier'),
                    note: value(f, 'note'),
                    lines: orderRows.map((r) => ({
                      ...(r.itemId.startsWith('product:')
                        ? { productId: r.itemId.slice(8) }
                        : { itemId: r.itemId }),
                      quantity: parseQuantity(r.quantity),
                      unitCost: parseMoney(r.cost),
                    })),
                  }),
                )
              }
            >
              <label>
                Proveedor de la orden
                <select aria-label="Proveedor de la orden" name="supplier" required>
                  <option value="">Selecciona</option>
                  {data.suppliers
                    .filter((s) => s.active)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                </select>
              </label>
              {orderRows.map((r, i) => (
                <div className="purchase-edit-row" key={i}>
                  <label>
                    Insumo de compra {i + 1}
                    <select
                      aria-label={`Insumo de compra ${i + 1}`}
                      value={r.itemId}
                      required
                      onChange={(e) =>
                        setOrderRows((old) =>
                          old.map((v, n) =>
                            n === i
                              ? {
                                  ...v,
                                  itemId: e.target.value,
                                  cost: decimal(
                                    (e.target.value.startsWith('product:')
                                      ? data.products.find((a) => a.id === e.target.value.slice(8))
                                      : data.items.find((a) => a.id === e.target.value)
                                    )?.cost || 0,
                                    100,
                                  ),
                                }
                              : v,
                          ),
                        )
                      }
                    >
                      <option value="">Selecciona</option>
                      {data.items
                        .filter((v) => v.active)
                        .map((v) => (
                          <option key={v.id} value={v.id}>
                            {v.name} ({v.unit})
                          </option>
                        ))}
                      {data.products
                        .filter((p) => p.track_stock && p.inventory_mode === 'product')
                        .map((p) => (
                          <option key={p.id} value={`product:${p.id}`}>
                            Producto: {p.name} ({p.unit})
                          </option>
                        ))}
                    </select>
                  </label>
                  <label>
                    Cantidad de compra {i + 1}
                    <input
                      value={r.quantity}
                      inputMode="decimal"
                      required
                      onChange={(e) =>
                        setOrderRows((old) =>
                          old.map((v, n) => (n === i ? { ...v, quantity: e.target.value } : v)),
                        )
                      }
                    />
                  </label>
                  <label>
                    Costo unitario de compra {i + 1}
                    <input
                      value={r.cost}
                      inputMode="decimal"
                      required
                      onChange={(e) =>
                        setOrderRows((old) =>
                          old.map((v, n) => (n === i ? { ...v, cost: e.target.value } : v)),
                        )
                      }
                    />
                  </label>
                  <button
                    type="button"
                    className="icon-button danger-text"
                    aria-label={`Retirar insumo de compra ${i + 1}`}
                    onClick={() => setOrderRows((old) => old.filter((_, n) => n !== i))}
                  >
                    <X size={18} />
                  </button>
                </div>
              ))}
              <button
                className="secondary"
                type="button"
                onClick={() =>
                  setOrderRows((old) => [...old, { itemId: '', quantity: '1.000', cost: '' }])
                }
              >
                <Plus size={18} />
                Agregar insumo a compra
              </button>
              <label>
                Notas de la orden
                <textarea name="note" maxLength={500} />
              </label>
              <p className="field-hint">
                La orden no modifica inventario. Las recepciones guardan el precio real y actualizan
                el costo promedio ponderado.
              </p>
              <button className="primary" disabled={m.busy || !orderRows.length}>
                Guardar orden de compra
              </button>
            </form>
          )}
          {dialog === 'receive' && order && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) =>
                  pos.inventory.smart.receive({
                    orderId: order.id,
                    requestId,
                    lines: data.orderLines
                      .filter((l) => l.order_id === order.id)
                      .map((l) => ({
                        lineId: l.id,
                        quantity: parseQuantity(value(f, `qty-${l.id}`) || '0'),
                        unitCost: parseMoney(value(f, `cost-${l.id}`) || '0'),
                      }))
                      .filter((l) => l.quantity > 0),
                  }),
                )
              }
            >
              <p>Captura únicamente lo recibido ahora. Usa cero para dejar un insumo pendiente.</p>
              {data.orderLines
                .filter((l) => l.order_id === order.id && l.received < l.quantity)
                .map((l) => (
                  <div className="form-row" key={l.id}>
                    <label>
                      Recibido · {l.item_name} ({l.unit})
                      <input
                        aria-label={`Recibido · ${l.item_name} (${l.unit})`}
                        name={`qty-${l.id}`}
                        inputMode="decimal"
                        required
                        defaultValue={decimal(l.quantity - l.received)}
                      />
                      <small>
                        Pendiente: {quantityText(l.quantity - l.received)} {l.unit}
                      </small>
                    </label>
                    <label>
                      Costo recibido · {l.item_name}
                      <input
                        name={`cost-${l.id}`}
                        inputMode="decimal"
                        required
                        defaultValue={decimal(l.unit_cost, 100)}
                      />
                    </label>
                  </div>
                ))}
              <button className="primary" disabled={m.busy}>
                Confirmar recepción
              </button>
            </form>
          )}
          {dialog === 'cancelOrder' && order && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) => pos.inventory.smart.cancelOrder(order.id, value(f, 'reason')))
              }
            >
              <p>
                Solo se cancela lo pendiente; las recepciones y movimientos existentes se conservan.
              </p>
              <label>
                Motivo de cancelación
                <input name="reason" required maxLength={500} />
              </label>
              <button className="danger-button" disabled={m.busy}>
                Cancelar restante
              </button>
            </form>
          )}
          {dialog === 'count' && (
            <form
              className="form-body form-stack"
              onSubmit={(e) =>
                void submit(e, (f) =>
                  pos.inventory.smart.count({
                    itemId: value(f, 'item'),
                    counted: parseQuantity(value(f, 'counted')),
                    reason: value(f, 'reason'),
                  }),
                )
              }
            >
              <label>
                Insumo contado
                <select aria-label="Insumo contado" name="item" required>
                  <option value="">Selecciona</option>
                  {data.items
                    .filter((i) => i.active)
                    .map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name} ({i.unit}) · teórico {quantityText(i.stock)}
                      </option>
                    ))}
                </select>
              </label>
              <label>
                Cantidad física contada
                <input name="counted" inputMode="decimal" required />
              </label>
              <label>
                Motivo del conteo
                <input name="reason" required maxLength={500} />
              </label>
              <p className="field-hint">
                Un administrador o supervisor deberá autorizar el ajuste. Se conservarán empleado,
                fecha, motivo y diferencia.
              </p>
              <button className="primary" disabled={m.busy}>
                Guardar conteo pendiente
              </button>
            </form>
          )}
        </Modal>
      )}
    </section>
  );
}
