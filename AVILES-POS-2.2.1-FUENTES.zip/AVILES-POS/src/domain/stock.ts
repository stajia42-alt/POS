import type { Database, SqlDriver } from '../db/database';
import type { AccessControl } from './access';
import type { Actor } from './access-types';
import type { Product, SaleLine } from './types';
import { integer, MAX_CENTS } from './money';
import { audit, newId, textRequired, timestamp } from './shared';
import { business } from './sales';
import { recordStock } from './stock-ledger';

export const QUANTITY_SCALE = 1000;
export const UNITS = ['pieza', 'kg', 'g', 'l', 'ml'] as const;
export function parseQuantity(value: string): number {
  const s = value.trim().replace(',', '.');
  if (!/^\d{1,6}(\.\d{1,3})?$/.test(s))
    throw new Error('Escribe una cantidad con hasta tres decimales.');
  const [whole, frac = ''] = s.split('.');
  return integer(Number(whole) * 1000 + Number(frac.padEnd(3, '0')), 0, 999999999);
}
export const quantityText = (n: number) =>
  new Intl.NumberFormat('es-MX', { maximumFractionDigits: 3 }).format(n / 1000);
export function costOf(quantity: number, cost: number) {
  integer(quantity, 0, 999999999);
  integer(cost);
  return Number((BigInt(quantity) * BigInt(cost) + 500n) / 1000n);
}
export interface StockItem {
  id: string;
  name: string;
  kind: 'ingredient' | 'supply';
  unit: (typeof UNITS)[number];
  stock: number;
  low_stock: number;
  cost: number;
  active: number;
}
export interface RecipeLine {
  product_id: string;
  item_id: string;
  quantity: number;
  item_name: string;
  unit: string;
  cost: number;
}
export interface Order {
  id: string;
  number: number;
  supplier_id: string;
  supplier_name: string;
  status: 'ordered' | 'partial' | 'received' | 'cancelled';
  note: string;
  created_at: string;
}
export interface OrderLine {
  id: string;
  order_id: string;
  item_id: string | null;
  product_id: string | null;
  item_name: string;
  unit: string;
  quantity: number;
  received: number;
  unit_cost: number;
}
export interface Supplier {
  id: string;
  name: string;
  phone: string;
  email: string;
  note: string;
  active: number;
}
export interface MaterialMovement {
  id: string;
  item_id: string;
  item_name: string;
  unit: string;
  quantity: number;
  before_stock: number;
  after_stock: number;
  kind: string;
  unit_cost: number;
  previous_cost: number;
  reason: string;
  actor_name: string;
  created_at: string;
}
export interface MaterialCount {
  id: string;
  item_id: string;
  item_name: string;
  unit: string;
  expected: number;
  counted: number;
  status: 'pending' | 'approved' | 'rejected';
  reason: string;
  actor_name: string;
  created_at: string;
  approved_name: string | null;
}
async function materialMove(
  sql: SqlDriver,
  actor: Actor,
  item: StockItem,
  quantity: number,
  kind: string,
  reason: string,
  unitCost = item.cost,
  options: { saleId?: string; updateCost?: number } = {},
) {
  integer(quantity, -999999999, 999999999);
  const after = integer(item.stock + quantity, -999999999, 999999999);
  integer(unitCost);
  const id = newId();
  await sql.run('UPDATE stock_items SET stock=?,cost=? WHERE id=?', [
    after,
    options.updateCost ?? item.cost,
    item.id,
  ]);
  await sql.run(
    'INSERT INTO material_movements(id,item_id,sale_id,quantity,before_stock,after_stock,unit_cost,previous_cost,kind,reason,actor_id,actor_name,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
    [
      id,
      item.id,
      options.saleId || null,
      quantity,
      item.stock,
      after,
      unitCost,
      item.cost,
      kind,
      reason,
      actor.id,
      actor.name,
      timestamp(),
    ],
  );
  return id;
}
export async function consumeStock(
  sql: SqlDriver,
  actor: Actor,
  saleId: string,
  lines: SaleLine[],
  number: number,
) {
  const required = new Map<string, number>();
  const b = await business(sql);
  for (const line of lines) {
    const [p] = await sql.query<Product>('SELECT * FROM products WHERE id=?', [line.product_id]);
    let unitCost = p.cost;
    if (p.inventory_mode === 'recipe') {
      const recipe = await sql.query<RecipeLine>(
        'SELECT r.*,i.name AS item_name,i.unit,i.cost FROM recipe_lines r JOIN stock_items i ON i.id=r.item_id WHERE r.product_id=?',
        [p.id],
      );
      if (!recipe.length) throw new Error(`El producto ${p.name} no tiene receta configurada.`);
      unitCost = 0;
      for (const r of recipe) {
        unitCost += costOf(r.quantity, r.cost);
        required.set(r.item_id, (required.get(r.item_id) || 0) + r.quantity * line.quantity);
      }
    }
    const cost = integer(unitCost * line.quantity, 0, Number.MAX_SAFE_INTEGER);
    const [category] = await sql.query<{ name: string }>('SELECT name FROM categories WHERE id=?', [
      p.category_id,
    ]);
    await sql.run('UPDATE sale_lines SET cost_total=?,category_name=? WHERE id=?', [
      cost,
      category?.name || 'Sin categoría',
      line.id,
    ]);
  }
  for (const [id, quantity] of required) {
    integer(quantity, 1, 999999999);
    const [item] = await sql.query<StockItem>('SELECT * FROM stock_items WHERE id=?', [id]);
    if (!item.active) throw new Error(`Ingrediente inactivo: ${item.name}.`);
    if (b.inventoryPolicy !== 'allow_negative' && item.stock < quantity)
      throw new Error(
        `Existencias insuficientes: ${item.name} (${quantityText(item.stock)} ${item.unit}).`,
      );
    await materialMove(sql, actor, item, -quantity, 'sale', `Venta #${number}`, item.cost, {
      saleId,
    });
  }
}
export class SmartInventory {
  constructor(
    private db: Database,
    private access: AccessControl,
  ) {}
  snapshot() {
    return this.db.read(async (sql) => {
      const actor = await this.access.require(sql);
      if (!actor.permissions.some((p) => ['inventory', 'reports'].includes(p)))
        throw new Error('Sin permiso para consultar inventario.');
      const items = await sql.query<StockItem>(
        'SELECT * FROM stock_items ORDER BY name COLLATE NOCASE',
      );
      const recipes = await sql.query<RecipeLine>(
        'SELECT r.*,i.name AS item_name,i.unit,i.cost FROM recipe_lines r JOIN stock_items i ON i.id=r.item_id ORDER BY i.name',
      );
      const products = await sql.query<
        Pick<
          Product,
          'id' | 'name' | 'price' | 'cost' | 'stock' | 'unit' | 'track_stock' | 'inventory_mode'
        >
      >(
        'SELECT id,name,price,cost,stock,unit,track_stock,inventory_mode FROM products WHERE active=1 ORDER BY name',
      );
      const suppliers = await sql.query<Supplier>('SELECT * FROM suppliers ORDER BY name');
      const orders = await sql.query<Order>('SELECT * FROM purchase_orders ORDER BY number DESC');
      const orderLines = await sql.query<OrderLine>(
        'SELECT * FROM purchase_order_lines ORDER BY rowid',
      );
      const movements = await sql.query<MaterialMovement>(
        'SELECT m.*,i.name AS item_name,i.unit FROM material_movements m JOIN stock_items i ON i.id=m.item_id ORDER BY m.rowid DESC LIMIT 100',
      );
      const counts = await sql.query<MaterialCount>(
        'SELECT c.*,i.name AS item_name,i.unit FROM material_counts c JOIN stock_items i ON i.id=c.item_id ORDER BY c.rowid DESC LIMIT 100',
      );
      const variations = movements.filter(
        (m) =>
          m.kind === 'purchase' &&
          m.previous_cost > 0 &&
          Math.abs(m.unit_cost - m.previous_cost) * 100 >= m.previous_cost * 20,
      );
      return {
        items,
        recipes,
        products,
        suppliers,
        orders,
        orderLines,
        movements,
        counts,
        variations,
        valuation: items
          .filter((i) => i.active)
          .reduce((n, i) => n + costOf(Math.max(0, i.stock), i.cost), 0),
      };
    });
  }
  saveItem(input: {
    id?: string;
    name: string;
    kind: StockItem['kind'];
    unit: StockItem['unit'];
    cost: number;
    lowStock: number;
    initialStock?: number;
    active?: number;
  }) {
    const name = textRequired(input.name, 'el nombre del ingrediente o insumo');
    integer(input.cost);
    integer(input.lowStock, 0, 999999999);
    integer(input.initialStock || 0, 0, 999999999);
    if (!['ingredient', 'supply'].includes(input.kind) || !UNITS.includes(input.unit))
      throw new Error('Tipo o unidad no válidos.');
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      const id = input.id || newId();
      const [old] = await sql.query<StockItem>('SELECT * FROM stock_items WHERE id=?', [id]);
      if (old && old.unit !== input.unit)
        throw new Error(
          'No cambies la unidad de un insumo existente: registra un insumo nuevo para conservar la trazabilidad.',
        );
      if (old && old.cost !== input.cost)
        throw new Error(
          'Actualiza el costo mediante una compra recibida para conservar el historial.',
        );
      integer(input.active ?? 1, 0, 1);
      await sql.run(
        'INSERT INTO stock_items(id,name,kind,unit,cost,low_stock,active) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,kind=excluded.kind,low_stock=excluded.low_stock,active=excluded.active',
        [id, name, input.kind, input.unit, input.cost, input.lowStock, input.active ?? 1],
      );
      if (!old && input.initialStock)
        await materialMove(
          sql,
          actor,
          {
            id,
            name,
            kind: input.kind,
            unit: input.unit,
            cost: input.cost,
            low_stock: input.lowStock,
            stock: 0,
            active: 1,
          },
          input.initialStock,
          'initial',
          'Existencia inicial',
        );
      await audit(sql, actor, 'material.save', id);
      return id;
    });
  }
  saveRecipe(productId: string, lines: { itemId: string; quantity: number }[]) {
    if (
      !lines.length ||
      lines.length > 100 ||
      new Set(lines.map((l) => l.itemId)).size !== lines.length
    )
      throw new Error('La receta debe tener de 1 a 100 ingredientes sin duplicados.');
    for (const l of lines) integer(l.quantity, 1, 999999999);
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory', 'products');
      const [product] = await sql.query<Product>('SELECT * FROM products WHERE id=?', [productId]);
      if (!product) throw new Error('Producto no disponible.');
      if (product.track_stock && product.stock !== 0)
        throw new Error(
          'Ajusta y documenta primero el stock del producto a cero antes de convertirlo a receta.',
        );
      for (const l of lines)
        if (
          !(await sql.query('SELECT id FROM stock_items WHERE id=? AND active=1', [l.itemId]))
            .length
        )
          throw new Error('Ingrediente no disponible.');
      await sql.run('DELETE FROM recipe_lines WHERE product_id=?', [productId]);
      for (const l of lines)
        await sql.run('INSERT INTO recipe_lines(product_id,item_id,quantity) VALUES(?,?,?)', [
          productId,
          l.itemId,
          l.quantity,
        ]);
      await sql.run("UPDATE products SET inventory_mode='recipe',track_stock=0 WHERE id=?", [
        productId,
      ]);
      await audit(sql, actor, 'recipe.save', productId, { lines });
    });
  }
  useProductStock(productId: string, counted: number, reason: string) {
    integer(counted, 0, 999999);
    const note = textRequired(reason, 'el motivo del cambio de control', 500);
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory', 'products');
      const [product] = await sql.query<Product>('SELECT * FROM products WHERE id=?', [productId]);
      if (!product || product.inventory_mode !== 'recipe')
        throw new Error('El producto ya no utiliza una receta. Actualiza el inventario.');
      const movement = await recordStock(
        sql,
        actor,
        product,
        counted - product.stock,
        'count',
        note,
      );
      await sql.run(
        'INSERT INTO inventory_counts(id,product_id,expected,counted,actor_id,actor_name,reason,movement_id,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
        [
          newId(),
          productId,
          product.stock,
          counted,
          actor.id,
          actor.name,
          note,
          movement.id,
          timestamp(),
        ],
      );
      await sql.run("UPDATE products SET inventory_mode='product',track_stock=1 WHERE id=?", [
        productId,
      ]);
      await audit(sql, actor, 'recipe.use_product_stock', productId, {
        reason: note,
        stock: product.stock,
        counted,
        movementId: movement.id,
        unit: product.unit,
        cost: product.cost,
        recipePreserved: true,
      });
    });
  }
  saveSupplier(input: { id?: string; name: string; phone: string; email: string; note: string }) {
    const name = textRequired(input.name, 'el nombre del proveedor');
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      const id = input.id || newId();
      await sql.run(
        'INSERT INTO suppliers(id,name,phone,email,note) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,phone=excluded.phone,email=excluded.email,note=excluded.note',
        [
          id,
          name,
          input.phone.trim().slice(0, 40),
          input.email.trim().slice(0, 150),
          input.note.trim().slice(0, 500),
        ],
      );
      await audit(sql, actor, 'supplier.save', id);
      return id;
    });
  }
  createOrder(input: {
    supplierId: string;
    note: string;
    lines: { itemId?: string; productId?: string; quantity: number; unitCost: number }[];
  }) {
    if (
      !input.lines.length ||
      input.lines.length > 100 ||
      new Set(input.lines.map((l) => (l.productId ? `p:${l.productId}` : `i:${l.itemId}`))).size !==
        input.lines.length
    )
      throw new Error('Agrega artículos sin duplicados a la orden.');
    for (const l of input.lines) {
      integer(l.quantity, 1, 999999999);
      integer(l.unitCost);
    }
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      const [supplier] = await sql.query<Supplier>(
        'SELECT * FROM suppliers WHERE id=? AND active=1',
        [input.supplierId],
      );
      if (!supplier) throw new Error('Proveedor no disponible.');
      const id = newId();
      const [{ number }] = await sql.query<{ number: number }>(
        'SELECT COALESCE(MAX(number),0)+1 AS number FROM purchase_orders',
      );
      const amount = input.lines.reduce((n, l) => n + costOf(l.quantity, l.unitCost), 0);
      integer(amount, 0, MAX_CENTS);
      await sql.run(
        "INSERT INTO purchase_orders(id,number,supplier_id,supplier_name,status,note,actor_id,actor_name,created_at) VALUES(?,?,?,?,'ordered',?,?,?,?)",
        [
          id,
          number,
          supplier.id,
          supplier.name,
          input.note.trim().slice(0, 500),
          actor.id,
          actor.name,
          timestamp(),
        ],
      );
      for (const l of input.lines) {
        if (Boolean(l.itemId) === Boolean(l.productId))
          throw new Error('Selecciona un ingrediente o un producto de compra.');
        const [item] = l.productId
          ? await sql.query<Product>(
              "SELECT * FROM products WHERE id=? AND active=1 AND track_stock=1 AND inventory_mode='product'",
              [l.productId],
            )
          : await sql.query<StockItem>('SELECT * FROM stock_items WHERE id=? AND active=1', [
              l.itemId!,
            ]);
        if (!item) throw new Error('Artículo de compra no disponible.');
        if (l.productId && l.quantity % 1000 !== 0)
          throw new Error('Los productos de venta se compran en unidades enteras.');
        await sql.run(
          'INSERT INTO purchase_order_lines(id,order_id,item_id,product_id,item_name,unit,quantity,unit_cost) VALUES(?,?,?,?,?,?,?,?)',
          [
            newId(),
            id,
            l.itemId || null,
            l.productId || null,
            item.name,
            item.unit,
            l.quantity,
            l.unitCost,
          ],
        );
      }
      await audit(sql, actor, 'purchase.order', id, { amount });
      return id;
    });
  }
  receive(input: {
    orderId: string;
    requestId: string;
    lines: { lineId: string; quantity: number; unitCost: number }[];
  }) {
    if (
      !input.requestId ||
      input.requestId.length > 100 ||
      !input.lines.length ||
      input.lines.length > 100 ||
      new Set(input.lines.map((l) => l.lineId)).size !== input.lines.length
    )
      throw new Error('Recepción no válida.');
    for (const l of input.lines) {
      integer(l.quantity, 1, 999999999);
      integer(l.unitCost);
    }
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      const [existing] = await sql.query<{ order_id: string }>(
        'SELECT order_id FROM purchase_receipts WHERE id=?',
        [input.requestId],
      );
      if (existing) {
        if (existing.order_id !== input.orderId)
          throw new Error('Identificador de recepción ya utilizado.');
        return input.requestId;
      }
      const [order] = await sql.query<Order>('SELECT * FROM purchase_orders WHERE id=?', [
        input.orderId,
      ]);
      if (!order || !['ordered', 'partial'].includes(order.status))
        throw new Error('La orden no está pendiente de recepción.');
      await sql.run(
        'INSERT INTO purchase_receipts(id,order_id,actor_id,actor_name,created_at) VALUES(?,?,?,?,?)',
        [input.requestId, input.orderId, actor.id, actor.name, timestamp()],
      );
      for (const l of input.lines) {
        const [line] = await sql.query<OrderLine>(
          'SELECT * FROM purchase_order_lines WHERE id=? AND order_id=?',
          [l.lineId, input.orderId],
        );
        if (!line || line.received + l.quantity > line.quantity)
          throw new Error('La recepción supera la cantidad pendiente.');
        let movement: string | null = null,
          productMovement: string | null = null;
        if (line.product_id) {
          if (l.quantity % 1000 !== 0) throw new Error('Recibe productos en unidades enteras.');
          const [p] = await sql.query<Product>(
            'SELECT * FROM products WHERE id=? AND track_stock=1',
            [line.product_id],
          );
          if (!p) throw new Error('El producto debe conservar su control de inventario.');
          const delta = l.quantity / 1000;
          const old = Math.max(0, p.stock);
          const denom = BigInt(old + delta);
          const weighted = Number(
            (BigInt(old) * BigInt(p.cost) + BigInt(delta) * BigInt(l.unitCost) + denom / 2n) /
              denom,
          );
          productMovement = (
            await recordStock(
              sql,
              actor,
              p,
              delta,
              'receipt',
              `Compra #${order.number} · ${order.supplier_name}`,
              { cost: l.unitCost, updateCost: weighted },
            )
          ).id;
        } else {
          const [item] = await sql.query<StockItem>('SELECT * FROM stock_items WHERE id=?', [
            line.item_id,
          ]);
          const positive = Math.max(0, item.stock);
          const numerator =
            BigInt(positive) * BigInt(item.cost) + BigInt(l.quantity) * BigInt(l.unitCost);
          const denominator = BigInt(positive + l.quantity);
          const weighted = Number((numerator + denominator / 2n) / denominator);
          movement = await materialMove(
            sql,
            actor,
            item,
            l.quantity,
            'purchase',
            `Compra #${order.number} · ${order.supplier_name}`,
            l.unitCost,
            { updateCost: weighted },
          );
        }
        await sql.run('UPDATE purchase_order_lines SET received=received+? WHERE id=?', [
          l.quantity,
          l.lineId,
        ]);
        await sql.run(
          'INSERT INTO purchase_receipt_lines(receipt_id,line_id,quantity,unit_cost,movement_id,product_movement_id) VALUES(?,?,?,?,?,?)',
          [input.requestId, l.lineId, l.quantity, l.unitCost, movement, productMovement],
        );
      }
      const [{ pending }] = await sql.query<{ pending: number }>(
        'SELECT SUM(quantity-received) AS pending FROM purchase_order_lines WHERE order_id=?',
        [input.orderId],
      );
      await sql.run('UPDATE purchase_orders SET status=? WHERE id=?', [
        pending ? 'partial' : 'received',
        input.orderId,
      ]);
      await audit(sql, actor, 'purchase.receive', input.orderId, {
        requestId: input.requestId,
        lines: input.lines,
      });
      return input.requestId;
    });
  }
  cancelOrder(id: string, reason: string) {
    const note = textRequired(reason, 'el motivo');
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      const [o] = await sql.query<Order>('SELECT * FROM purchase_orders WHERE id=?', [id]);
      if (!o || !['ordered', 'partial'].includes(o.status))
        throw new Error('La orden ya no tiene recepción pendiente.');
      await sql.run("UPDATE purchase_orders SET status='cancelled' WHERE id=?", [id]);
      await audit(sql, actor, 'purchase.cancel_remaining', id, { reason: note });
    });
  }
  count(input: { itemId: string; counted: number; reason: string }) {
    integer(input.counted, 0, 999999999);
    const reason = textRequired(input.reason, 'el motivo del conteo');
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      const [item] = await sql.query<StockItem>('SELECT * FROM stock_items WHERE id=?', [
        input.itemId,
      ]);
      if (!item) throw new Error('Ingrediente no disponible.');
      const id = newId();
      await sql.run(
        "INSERT INTO material_counts(id,item_id,expected,counted,status,reason,actor_id,actor_name,created_at) VALUES(?,?,?,?,'pending',?,?,?,?)",
        [id, item.id, item.stock, input.counted, reason, actor.id, actor.name, timestamp()],
      );
      await audit(sql, actor, 'material.count', id);
      return id;
    });
  }
  approveCount(id: string, approve = true) {
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'inventory');
      if (!['admin', 'supervisor'].includes(actor.role))
        throw new Error('La autorización de conteos requiere administrador o supervisor.');
      const [count] = await sql.query<MaterialCount>('SELECT * FROM material_counts WHERE id=?', [
        id,
      ]);
      if (!count || count.status !== 'pending') throw new Error('El conteo ya fue resuelto.');
      const [item] = await sql.query<StockItem>('SELECT * FROM stock_items WHERE id=?', [
        count.item_id,
      ]);
      if (approve && item.stock !== count.expected)
        throw new Error(
          'Las existencias cambiaron desde el conteo. Rechaza y realiza un nuevo conteo.',
        );
      const movement = approve
        ? await materialMove(
            sql,
            actor,
            item,
            count.counted - count.expected,
            'count',
            count.reason,
          )
        : null;
      await sql.run(
        'UPDATE material_counts SET status=?,approved_id=?,approved_name=?,approved_at=?,movement_id=? WHERE id=?',
        [approve ? 'approved' : 'rejected', actor.id, actor.name, timestamp(), movement, id],
      );
      await audit(sql, actor, approve ? 'material.count_approve' : 'material.count_reject', id);
    });
  }
}
