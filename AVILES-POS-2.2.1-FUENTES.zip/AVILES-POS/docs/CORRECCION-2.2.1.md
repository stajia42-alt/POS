# Corrección 2.2.1 después de la prueba del usuario

El usuario confirmó que la variante 2.2 PRUEBAS se instaló en BlueStacks y rechazó su resultado visual y operativo. Esta corrección recupera la distribución de trabajo de 2.1 y resuelve bloqueos de inventario reproducibles. No se presenta como aceptación del diseño ni como validación de periféricos.

## Base comprobada

El APK AVILES-POS-2.1.apk adjuntado de nuevo es idéntico byte a byte al anterior (SHA256 `82e5fb7068c6398eacca6e173b3ca3b3febbaa153dfd6b8d4f0b1db0ffe208d4`). Se comparó con sus fuentes originales conservadas. No se reinició el proyecto ni se reemplazó la base de datos.

El APK LoyversePOS-2.75.apk supera el límite de transferencia de 32 MiB de este entorno; no se pudo abrir ni ejecutar. No se afirma una comparación de su interfaz ni se incorporó código suyo.

## Cambios

- Se retira la barra lateral fija que reducía el catálogo. Se recuperan el menú, las proporciones catálogo/ticket de 2.1 y las categorías al pie. Continúan venta rápida y mesas. La paleta propia azul se conserva.
- El nombre y precio de cada producto tienen un área blanca separada de la fotografía, sin textos superpuestos. GUARDAR y COBRAR permanecen accesibles en la tableta compacta.
- Inventario abre en la pantalla de productos de 2.1: existencias, entradas, salidas, ajustes, conteos e historial. Recetas, ingredientes, compras y conteos de insumos se abren desde **Más opciones de inventario**. Se puede regresar al inventario simple sin eliminar la configuración avanzada.
- Un producto que vendió con la política de negativos puede volver a editarse y recibir entradas parciales aunque todavía falten unidades. No se pueden crear ni agravar negativos desde ajustes manuales. El costo de reposición no divide entre un saldo cero ni promedia cantidades negativas.
- Se permite regresar de una receta al control directo del producto mediante confirmación y conteo físico. Se conserva la receta para reactivarla, los ingredientes, los movimientos y los costos históricos.

## Datos e instalación

Versión Android 2.2.1, código 6. Esquema SQLite 5, sin cambios destructivos ni migraciones nuevas. La variante de pruebas mantiene `mx.aviles.pos.pruebas` y el mismo certificado del APK 2.2 PRUEBAS que ya pudo instalarse. Está preparada para actualizar esa app de pruebas conservando su base. La instalación y persistencia de esta corrección en el BlueStacks del usuario siguen sin comprobarse.

La app original 2.1 utiliza `mx.aviles.pos` y una base independiente. No se modificó ni se mezclaron sus datos. Esta entrega no resuelve la actualización de aquella instalación.

## Impresoras

En el APK 2.1 recibido y sus fuentes no existe el módulo de impresión: solo se registra SQLite como plugin nativo. Se inspeccionaron las ramas remotas de AVILES y tampoco contienen esa integración. Una rama de otro producto de escritorio tiene impresión, pero no pertenece a esta app y no se integró.

Se mantiene la instrucción de no duplicar la tarea de impresoras. Hace falta localizar su implementación real y conocer modelo/conexión para revisar el fallo. No se añadieron botones simulados de impresión ni se declara que funcionen las impresoras. Véase REVISION_IMPRESORAS.md.

## Validación

Los resultados finales se registran en AVILES_POS_PROGRESO.md y en los archivos de verificación de la descarga. Las pruebas del navegador no sustituyen la instalación, SQLite nativo ni una impresión real. Las capturas en `docs/capturas/2.2.1` usan exclusivamente datos de prueba aislados.
