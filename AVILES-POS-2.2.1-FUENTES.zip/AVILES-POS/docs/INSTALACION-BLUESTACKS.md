# Instalación de pruebas en BlueStacks

El usuario confirmó la instalación de AVILES POS 2.2 PRUEBAS. La corrección 2.2.1 conserva su identificador `mx.aviles.pos.pruebas` y certificado, y aumenta el código de versión a 6. Está preparada para actualizar esa app de pruebas, sin reinstalar ni limpiar almacenamiento. La comprobación en el BlueStacks del usuario queda pendiente.

Aparece como **AVILES POS 2.2.1 PRUEBAS**. Si ya usabas la edición PRUEBAS, debe abrir su misma base y pedir el PIN de esa edición. Si es su primera instalación, crea propietario y PIN propios; no hay acceso predeterminado.

La instalación original AVILES 2.1 sigue siendo independiente: sus ventas, productos, PIN e impresoras no se trasladan automáticamente. No se debe desinstalar ni borrar para intentar actualizarla.

Consulta [qué se corrigió y qué sigue pendiente](CORRECCION-2.2.1.md).
