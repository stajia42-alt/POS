# Referencias visuales de AVILES POS

Las imágenes 2.1 se tomaron antes del rediseño. Las imágenes 2.2 provienen de flujos reales de la aplicación con fixtures de prueba en contextos Chromium aislados. **No son datos comerciales ni catálogo precargado.** Los nombres “de prueba” y las imágenes geométricas identifican estas fixtures; no se usan fotografías del negocio.

La galería actual 2.2.1 se regenera con `npm run build && npm run test:e2e -- e2e/visual.spec.ts`. Los diálogos se comprueban dentro de pantalla; móvil alterna catálogo/ticket. Los cambios de color/transición se capturan sin animación.

## Antes: 2.1

[Acceso](2.1/01-pin.png) · [Ventas](2.1/13-ticket-cuadricula.png) · [Cobro](2.1/15-cobro.png) · [Caja](2.1/08-caja.png)

## Rediseño: 2.2

- [01-pin](2.2/01-pin.png)
- [02-apertura](2.2/02-apertura.png)
- [03-ventas-vacio](2.2/03-ventas-vacio.png)
- [04-productos](2.2/04-productos.png)
- [05-inventario](2.2/05-inventario.png)
- [06-clientes](2.2/06-clientes.png)
- [07-empleados](2.2/07-empleados.png)
- [08-caja](2.2/08-caja.png)
- [09-configuracion](2.2/09-configuracion.png)
- [10-historial](2.2/10-historial.png)
- [11-mesas](2.2/11-mesas.png)
- [12-producto-formulario](2.2/12-producto-formulario.png)
- [13-ticket-cuadricula](2.2/13-ticket-cuadricula.png)
- [14-lista](2.2/14-lista.png)
- [15-cobro](2.2/15-cobro.png)
- [16-edicion-cantidad](2.2/16-edicion-cantidad.png)
- [17-opciones-ticket](2.2/17-opciones-ticket.png)
- [18-recibo](2.2/18-recibo.png)
- [19-insumos](2.2/19-insumos.png)
- [20-recetas](2.2/20-recetas.png)
- [21-compras](2.2/21-compras.png)
- [22-conteos](2.2/22-conteos.png)
- [23-reportes](2.2/23-reportes.png)
- [24-costos](2.2/24-costos.png)
- [25-respaldos](2.2/25-respaldos.png)
- [26-cierre-caja](2.2/26-cierre-caja.png)
- [27-adaptable-1024](2.2/27-adaptable-1024.png)
- [27-adaptable-390](2.2/27-adaptable-390.png)
- [27-adaptable-893](2.2/27-adaptable-893.png)
- [27-adaptable-960](2.2/27-adaptable-960.png)

![Ventas con identidad 2.2](2.2/13-ticket-cuadricula.png)

![PIN 2.2](2.2/01-pin.png)

![Reportes 2.2](2.2/23-reportes.png)

## Corrección: 2.2.1

Se conservan las capturas 2.2 para comparar con la entrega que el usuario rechazó. Las capturas actuales están en 2.2.1.

[Venta en tableta](2.2.1/28-venta-tableta.png) · [Inventario directo](2.2.1/29-inventario-directo.png) · [Catálogo y ticket](2.2.1/13-ticket-cuadricula.png) · [Cobro](2.2.1/15-cobro.png)

![Distribución recuperada en tableta compacta](2.2.1/28-venta-tableta.png)
