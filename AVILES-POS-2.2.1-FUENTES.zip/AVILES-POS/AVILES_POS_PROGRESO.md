# AVILES POS — Registro de avance 2.2 y corrección 2.2.1

Actualización de las fuentes 2.1 aportadas; React/TypeScript, Capacitor y SQLite se conservan. Código integrado en el checkout existente. La referencia histórica anterior está en `docs/PROGRESO-2.1.md`.

## Corrección 2.2.1 — estado actual

El usuario confirmó que la edición 2.2 PRUEBAS se instaló en BlueStacks, pero rechazó el resultado visual y reportó errores. Las fases 2.2 de abajo son el registro histórico de aquella entrega; las pruebas web aprobadas no equivalen a aceptación de la experiencia real.

- Recuperada la distribución de venta de 2.1: menú, catálogo amplio, ticket al lado y categorías al pie; se elimina la barra fija añadida. Nombre/precio se separan de la foto para mantener legibilidad.
- Inventario abre directamente en Productos. Las funciones avanzadas se conservan detrás de Más opciones de inventario. Se distingue Conteos de insumos del conteo de producto original.
- Reparados bloqueos al editar stock negativo y recibir mercancía parcial para recuperar faltantes; costo de reposición sin divisiones por cero ni cantidades negativas.
- Reparada la vuelta de receta a existencias de producto, con conteo físico obligatorio, permisos, movimiento y auditoría atómicos. Se conserva receta y costos históricos.
- Android 2.2.1/código 6, esquema 5. La edición de pruebas conserva paquete y certificado de la que pudo instalarse; está preparada para actualizarla sin limpiar datos.
- APK 2.1 nuevo idéntico al anterior. Impresoras siguen NO DISPONIBLES en ese APK y en las ramas AVILES revisadas. El APK Loyverse excedió el límite de transferencia de este entorno y no se inspeccionó.

Detalle: [CORRECCION-2.2.1.md](docs/CORRECCION-2.2.1.md). Pruebas finales: **127 pruebas en 11 archivos aprobadas**, **24 flujos Chromium aprobados**, build web aprobado. Las capturas 2.2.1 se regeneraron en cinco tamaños de pantalla. La compilación Android y verificación del instalador se registran en el manifiesto de descarga. La instalación de esta corrección en BlueStacks y los periféricos siguen pendientes.

## Fases y evidencia histórica 2.2

| Fase                         | Implementación                                                                                                                                                                                                    | Verificación / límite                                                                                                                                     |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1. Inspección y restauración | Integración del ZIP 2.1; archivo previo del checkout y fuentes originales; flujos documentados; 15 referencias visuales originales                                                                                | Baseline: 85 pruebas y 18 flujos web aprobados; APK original comprobado por SHA256                                                                        |
| 2. Identidad y pantallas     | Tokens, navegación lateral, categorías superiores, catálogo, lista, ticket, PIN, mesas, caja, administración, formularios/estados/diálogos; acción de cobro siempre visible                                       | Regresión original aprobada tras rediseño; 30 capturas finales, adaptabilidad hasta 893×533 y móvil; tacto/teclado Android físico pendiente               |
| 3. Respaldos/estabilidad     | Exportación íntegra, manifiesto/SHA256, inspección aislada, integridad/referencias, copia de recuperación y restauración confirmada, transacciones y recuperación de cuentas/abonos                               | Pruebas unitarias de corrupción/tipos/rollback y flujo completo web aprobados; selector/SQLite nativos pendientes                                         |
| 4. Inventario                | Ingredientes/insumos, unidades precisas, recetas/costo/margen, compras de insumos y productos, proveedores, recepción parcial idempotente, promedio ponderado, movimientos/precios, alertas y conteos autorizados | Pruebas comerciales y flujo web aprobados; medición con catálogo real en tableta pendiente                                                                |
| 5. MXN/USD                   | Tasa capturada, recibido/cambio físico por moneda, combinados, abonos persistentes, saldo bloqueado, cortes por turno sin duplicación                                                                             | Ejemplo $350/$20 USD a 18, cambio $10 MXN; reinicio y turnos distintos comprobados; efectivo físico pendiente                                             |
| 6. Reportes                  | Día/periodo/empleado/producto/categoría/hora, descuentos/cancelaciones, pagos, MXN/USD, cortes, inventario, costos/margen, comparaciones equivalentes, CSV/PDF                                                    | Datos de operaciones persistidas; históricos incompletos explícitos; PDF abierto y extraído con herramientas independientes; exportación nativa pendiente |
| 7. Impresoras                | Revisión documentada, sin implementación paralela                                                                                                                                                                 | NO DISPONIBLE: falta integrar el código de la otra tarea                                                                                                  |
| 8. Regresión/Android         | 121 pruebas de lógica/persistencia; 23 flujos Chromium; build web; APK 2.2.0/versionCode 5; proyecto Android y esquema 5                                                                                          | Compilación y verificación del artefacto; instalación/actualización/SQLite nativo y Samsung física pendientes                                             |

## Funciones terminadas y comprobadas en software

- Persistencia de catálogo/fotos, tickets, mesas, empleados/permisos y turnos preservada por migraciones desde los esquemas históricos 1–4.
- Cobros transaccionales y reintentos idempotentes; abonos no descuentan stock ni liberan mesa; liquidación realiza ambas operaciones junto al pago final.
- Caja calcula fondos físicos por moneda, incluido cambio cruzado y abonos de turnos distintos.
- Un único módulo Inventario: productos originales más ingredientes, recetas, compras y conteos. Las compras de producto usan su mismo libro de stock.
- Respaldo completo sin copiar un archivo SQLite vivo: instantánea transaccional, SHA256, validación en base temporal y restauración con confirmación/copia previa. No hay restauración automática destructiva.
- Reportes sin datos precargados ni costos históricos inventados; CSV protegido y PDF offline paginado.
- Identidad 2.2 aplicada a la interfaz completa. Base de tokens oscuros preparada, sin declarar un tema oscuro final validado.

## Pendientes concretos

1. **Firma compatible con la instalación anterior.** Los APK 1.1/1.2/2.1 aportados comparten certificado, pero ninguno de los ZIP contiene la clave privada original. El APK de prueba generado aquí tiene otro certificado; no actualiza una instalación existente con la firma anterior. No desinstalar ni borrar datos. Se requiere recuperar esa clave para firmar la actualización. Véase `docs/FIRMA-ANDROID.md`.
2. **Validación Android física:** instalación, actualización conservando datos, SQLite/SQLCipher, selector/exportación/restore, cierre forzado, teclado/insets, rendimiento con fotos y caja física. Plan en `docs/PRUEBAS-FISICAS-2.2.md`. No existe tableta conectada/KVM; no se afirma prueba física ni emulador.
3. **Impresoras/comandas:** NO DISPONIBLE; integración y pruebas de hardware pendientes de la otra tarea.
4. **Fuera de esta entrega:** devoluciones de pagos/abonos, variantes/modificadores, conversión automática entre unidades, tema oscuro completo y edición gráfica avanzada del PDF. No se añaden botones que simulen estas funciones.

## Recuperabilidad y entrega

`/workspace/restoration-aviles-2.1` conserva el checkout previo, las fuentes originales, el checkpoint visual y los esquemas históricos inspeccionados. Los adjuntos originales no se modificaron. Los ZIP/APK de entrega se generan en `artifacts/`, ignorado por Git. No contienen keystores, datos comerciales ni dependencias instaladas.

La configuración reutilizable de instalación/inicio se guarda por separado en el borrador del entorno para revisión; guardarla no publica el entorno ni inicia procesos futuros. Código, pruebas, documentación y capturas están en el checkout local; no se han publicado los cambios de fuentes en main ni el entorno. Los artefactos descargables sí se publicaron en la rama dedicada de descargas.

## Instalación en paralelo para BlueStacks

Ante el rechazo de actualización por firma distinta sobre una versión anterior instalada, se añade la variante Android `sideTest`. El identificador de producción sigue siendo `mx.aviles.pos`; solo esta variante usa `mx.aviles.pos.pruebas` y se identifica como AVILES POS 2.2 PRUEBAS. Usa el mismo código y tiene datos independientes; no traslada ni modifica los de la instalación anterior. Véase `docs/INSTALACION-BLUESTACKS.md`. El usuario confirmó después que la edición 2.2 PRUEBAS pudo instalarse. La corrección 2.2.1 conserva esa identidad; su instalación efectiva todavía no se ha comprobado.
