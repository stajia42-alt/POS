# Validación de impresión 2.2.2

- `npm run build`: aprobado.
- `npm test`: 158 pruebas aprobadas en 14 archivos.
- `npm run test:e2e`: 25 flujos aprobados, incluido configuración, persistencia de IP, impresión de prueba en cola, incrementos de comanda, ticket original idempotente y pantallas compactas. En navegador no se simula un envío físico.
- `npx vitest run tests/upgrade.test.ts`: 8 pruebas aprobadas después de añadir una regresión independiente desde el esquema 5 de las fuentes publicadas de 2.2.1; conserva catálogo, fotos, ventas, pagos, empleados/permisos, mesas, ingredientes y recetas. Esta es una prueba adicional a la suite completa anterior.
- Gradle `:app:testSideTestUnitTest :app:assembleSideTest`: aprobado. Ocho pruebas Java comprueban TCP real contra servidor local, entrega byte a byte, cierre, conexión rechazada, fallo parcial, plazo durante escritura bloqueada, cancelación y validación de entradas.
- Formato, certificado, versión, arquitecturas, zipalign y coincidencia de recursos web se registran en el manifiesto de descarga.

No se ha conectado una impresora física del usuario, una tableta ni BlueStacks a este entorno. Falta ejecutar Imprimir prueba con su IP, comprobar ancho, acentos, corte, cuenta con mesa/mesero, cocina/bar y reconexión. Una escritura TCP terminada no es confirmación de papel.

La migración 6 añade tablas, sin reiniciar la base. Restaurar un respaldo no reenvía automáticamente trabajos antiguos y se bloquea durante envíos en curso. Las pruebas cubren retención de la cola restaurada, permisos, rollback, idempotencia, bloqueo por impresora y copias explícitas.

Capturas `docs/capturas/2.2.2/impresoras.png` y `comanda.png`: datos aislados de prueba, sin precargar impresoras ni productos en la aplicación.
