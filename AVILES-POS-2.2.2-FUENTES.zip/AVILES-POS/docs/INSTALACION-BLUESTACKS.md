# Instalación de pruebas en BlueStacks

El usuario confirmó la instalación de AVILES POS 2.2 PRUEBAS. La versión 2.2.2 con impresoras conserva su identificador `mx.aviles.pos.pruebas` y certificado, y aumenta el código de versión a 7. Está preparada para actualizar esa app de pruebas, sin reinstalar ni limpiar almacenamiento. La comprobación en el BlueStacks del usuario queda pendiente.

Aparece como **AVILES POS 2.2.2 PRUEBAS**. Si ya usabas la edición PRUEBAS, debe abrir su misma base y pedir el PIN de esa edición. Si es su primera instalación, crea propietario y PIN propios; no hay acceso predeterminado.

La instalación original AVILES 2.1 sigue siendo independiente: sus ventas, productos, PIN e impresoras no se trasladan automáticamente. No se debe desinstalar ni borrar para intentar actualizarla.

Consulta [qué se corrigió y qué sigue pendiente](CORRECCION-2.2.1.md).

Para imprimir desde Android o BlueStacks, configura la IP de la impresora ESC/POS en Menú → Impresoras. La conexión es de red; el controlador USB de Windows no expone automáticamente una impresora a BlueStacks. Esta entrega implementa la conexión por IP que el usuario confirmó que utiliza en Loyverse.
