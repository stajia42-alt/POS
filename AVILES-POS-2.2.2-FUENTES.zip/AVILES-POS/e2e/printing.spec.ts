import { test, expect } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
import { createProduct, navigate, ready, reload } from './helpers';

test('configura ESC/POS80, conserva impresora y encola cambios de cocina y ticket sin duplicarlos', async ({
  page,
}) => {
  await ready(page);
  await createProduct(page, 'Café de impresión prueba', '40.00');
  await navigate(page, 'Impresoras');
  await page.getByRole('button', { name: 'Agregar impresora', exact: true }).click();
  const setup = page.getByRole('dialog');
  await setup.getByLabel('Nombre de la impresora', { exact: true }).fill('Caja y cocina de prueba');
  await setup.getByLabel('Dirección IP', { exact: true }).fill('127.0.0.1');
  await expect(setup.getByLabel('Puerto', { exact: true })).toHaveValue('9100');
  await expect(setup.getByLabel('Ancho del papel', { exact: true })).toHaveValue('80');
  await setup.getByLabel('Imprimir comandas', { exact: true }).check();
  await setup.getByRole('button', { name: 'Guardar impresora', exact: true }).click();
  await expect(setup).toHaveCount(0);
  await expect(page.getByText('127.0.0.1:9100 · 80 mm · Activa', { exact: true })).toBeVisible();
  await page
    .getByRole('button', { name: 'Imprimir prueba · Caja y cocina de prueba', exact: true })
    .click();
  await expect(page.getByRole('button', { name: 'Prueba AVILES POS', exact: true })).toHaveCount(1);
  await expect(page.getByText('En cola', { exact: true })).toHaveCount(1);
  await reload(page);
  await navigate(page, 'Impresoras');
  await expect(page.getByText('127.0.0.1:9100 · 80 mm · Activa', { exact: true })).toBeVisible();
  await navigate(page, 'Punto de venta');
  await page.getByRole('button', { name: 'Agregar Café de impresión prueba', exact: true }).click();
  await page.getByRole('button', { name: 'Enviar comanda', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: 'Comanda en cola' })).toBeVisible();
  await page.getByRole('button', { name: 'Enviar comanda', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: 'No hay cambios nuevos' })).toBeVisible();
  await page.getByRole('button', { name: 'Agregar Café de impresión prueba', exact: true }).click();
  await page.getByRole('button', { name: 'Enviar comanda', exact: true }).click();
  await expect(page.getByTestId('app-ready')).toHaveAttribute('aria-busy', 'false');
  await page.getByRole('button', { name: 'COBRAR', exact: true }).click();
  await page.getByLabel('Efectivo recibido (MXN)', { exact: true }).fill('100');
  await page.getByRole('button', { name: 'Confirmar cobro', exact: true }).click();
  await expect(page.getByTestId('receipt')).toBeVisible();
  await page.getByRole('button', { name: 'Imprimir ticket', exact: true }).click();
  await expect(page.getByTestId('app-ready')).toHaveAttribute('aria-busy', 'false');
  await page.getByRole('button', { name: 'Nueva venta', exact: true }).click();
  await navigate(page, 'Impresoras');
  await expect(page.getByRole('button', { name: /^Comanda / })).toHaveCount(2);
  await expect(page.getByRole('button', { name: /^Ticket #/ })).toHaveCount(1);
  // Browser tests do not pretend to send native TCP data or confirm paper.
  await expect(page.getByText('Enviado', { exact: true })).toHaveCount(0);
  await page
    .getByRole('button', { name: /^Comanda / })
    .first()
    .click();
  const preview = page.getByRole('dialog');
  await expect(preview.locator('pre')).toContainText('AGREGAR 1 x Café de impresión prueba');
  await expect(preview.locator('pre')).not.toContainText('TOTAL');
  await mkdir('docs/capturas/2.2.2', { recursive: true });
  await page.screenshot({ path: 'docs/capturas/2.2.2/comanda.png', animations: 'disabled' });
  await preview.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
  await page.screenshot({ path: 'docs/capturas/2.2.2/impresoras.png', animations: 'disabled' });
  for (const size of [
    { width: 893, height: 533 },
    { width: 390, height: 844 },
  ]) {
    await page.setViewportSize(size);
    await page
      .getByRole('button', { name: 'Editar impresora Caja y cocina de prueba', exact: true })
      .click();
    await expect(page.getByRole('dialog')).toBeInViewport();
    await page
      .getByRole('button', { name: 'Guardar impresora', exact: true })
      .scrollIntoViewIfNeeded();
    await expect(
      page.getByRole('button', { name: 'Guardar impresora', exact: true }),
    ).toBeInViewport();
    await page.getByRole('button', { name: 'Cerrar ventana', exact: true }).click();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
      true,
    );
  }
});
