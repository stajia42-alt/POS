import { describe, expect, it } from 'vitest';
import { fixture, product } from './support';
import type { Printer } from '../src/domain/printing';
import type { Permission } from '../src/domain/access-types';
import type { Pos } from '../src/domain/pos';

const config = (overrides: Partial<Printer> = {}) => ({
  name: 'Cocina de prueba',
  host: '192.168.1.50',
  port: 9100,
  width: 80 as const,
  receipt: 0,
  kitchen: 1,
  cut: 1,
  active: 1,
  ...overrides,
});
async function currentSale(pos: Pos, productId: string) {
  const sale = (await pos.snapshot()).active;
  await pos.addProduct(sale.id, productId);
  return sale;
}
async function cashier(pos: Pos, permissions: Permission[]) {
  await pos.access.save({
    name: 'Cajero de prueba',
    identifier: 'printer-cashier',
    role: 'cashier',
    active: 1,
    pin: '739154',
    permissions,
  });
  await pos.access.login('739154');
}
async function tableLayout(pos: Pos) {
  const area = await pos.tables.saveArea('Salón de prueba');
  const tables: string[] = [];
  for (const [name, x] of [
    ['1', 20],
    ['2', 220],
  ] as const)
    tables.push(
      await pos.tables.save({
        area_id: area,
        name,
        shape: 'square',
        x,
        y: 20,
        width: 140,
        height: 140,
        capacity: 4,
      }),
    );
  return tables;
}
const text = (job: { payload: { lines: string[] } }) => job.payload.lines.join('\n');

describe('configuración y cola persistente de impresoras', () => {
  it('guarda impresora y rutas de forma atómica, y conserva la principal si una nueva configuración falla', async () => {
    const { pos } = await fixture();
    const category = await pos.saveCategory('Cocina');
    const id = await pos.printing.savePrinter(config({ receipt: 1 }), [category]);
    expect((await pos.printing.snapshot()).printers[0]).toMatchObject({
      id,
      receipt: 1,
      all_products: 0,
    });
    await expect(
      pos.printing.savePrinter(config({ name: 'Fallida', host: '192.168.1.51', receipt: 1 }), [
        'missing',
      ]),
    ).rejects.toThrow('Categoría');
    const snap = await pos.printing.snapshot();
    expect(snap.printers).toHaveLength(1);
    expect(snap.printers[0].receipt).toBe(1);
    expect(snap.routes).toEqual([{ printer_id: id, category_id: category }]);
    expect(() => pos.printing.savePrinter(config({ host: 'http://192.168.1.50' }))).toThrow('IP');
    expect(() => pos.printing.savePrinter(config({ port: 0 }))).toThrow('puerto');
  });

  it('sin configuración no añade trabajos ni impide guardar o cobrar una venta', async () => {
    const { pos } = await fixture();
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    await pos.park(sale.id, 'Pendiente');
    await pos.resume(sale.id);
    await pos.checkout(sale.id, 14000);
    expect((await pos.printing.snapshot()).jobs).toEqual([]);
    await expect(pos.printing.enqueueReceipt(sale.id)).rejects.toThrow('Configura');
  });

  it('el ticket original es idempotente y una copia usa sus propios permisos y captura de datos', async () => {
    const { pos } = await fixture();
    const id = await pos.printing.savePrinter(config({ receipt: 1, kitchen: 0 }));
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    await pos.checkout(sale.id, 15000);
    const original = await pos.printing.enqueueReceipt(sale.id);
    expect(await pos.printing.enqueueReceipt(sale.id)).toBe(original);
    await pos.checkout(sale.id, 15000);
    expect((await pos.printing.snapshot()).jobs).toHaveLength(1);
    await pos.printing.savePrinter(config({ id, host: '192.168.1.99', receipt: 1, kitchen: 0 }));
    const dispatch = (await pos.printing.claimNext())!;
    expect(dispatch.printer.host).toBe('192.168.1.50');
    expect(text(dispatch)).toContain('$140.00');
    await pos.printing.complete(dispatch.id, dispatch.attemptId);
    const copy = await pos.printing.enqueueReceipt(sale.id, true);
    const copyJob = (await pos.printing.snapshot()).jobs.find((j) => j.id === copy)!;
    expect(text(copyJob)).toContain('COPIA');
    expect(copyJob.copyOf).toBe(original);
    expect((await pos.printing.latestReceipt(sale.id))?.id).toBe(copy);
  });

  it('bloquea por impresora tras fallo, permite avanzar otra y reintenta sin cambiar el orden', async () => {
    const { pos } = await fixture();
    const a = await pos.printing.savePrinter(config());
    const b = await pos.printing.savePrinter(config({ name: 'Bar', host: '192.168.1.51' }));
    const first = await pos.printing.enqueueTest(a);
    const second = await pos.printing.enqueueTest(a);
    const other = await pos.printing.enqueueTest(b);
    const start = (await pos.printing.claimNext())!;
    expect(start.id).toBe(first);
    await pos.printing.fail(start.id, start.attemptId, 'Sin conexión', false);
    const next = (await pos.printing.claimNext())!;
    expect(next.id).toBe(other);
    await pos.printing.complete(next.id, next.attemptId);
    expect(await pos.printing.claimNext()).toBeNull();
    expect(await pos.printing.retry(first)).toBe(first);
    const retry = (await pos.printing.claimNext())!;
    expect(retry.id).toBe(first);
    await pos.printing.complete(retry.id, retry.attemptId);
    expect((await pos.printing.claimNext())!.id).toBe(second);
  });

  it('un envío incierto se reemplaza por COPIA antes de los documentos posteriores sin marcar el original enviado', async () => {
    const { pos } = await fixture();
    const printer = await pos.printing.savePrinter(config());
    const first = await pos.printing.enqueueTest(printer);
    const second = await pos.printing.enqueueTest(printer);
    const start = (await pos.printing.claimNext())!;
    await pos.printing.fail(start.id, start.attemptId, 'Conexión cortada', true);
    expect(await pos.printing.claimNext()).toBeNull();
    const copy = await pos.printing.retry(first);
    expect((await pos.printing.snapshot()).jobs.find((j) => j.id === first)!.status).toBe(
      'superseded',
    );
    expect(await pos.printing.retry(first)).toBe(copy);
    const redo = (await pos.printing.claimNext())!;
    expect(redo.id).toBe(copy);
    expect(text(redo)).toContain('COPIA');
    await pos.printing.complete(redo.id, redo.attemptId);
    expect((await pos.printing.claimNext())!.id).toBe(second);
  });

  it('recupera una interrupción como incierta y exige confirmación manual para desbloquear', async () => {
    const { pos, db } = await fixture();
    const printer = await pos.printing.savePrinter(config());
    const first = await pos.printing.enqueueTest(printer);
    const second = await pos.printing.enqueueTest(printer);
    const start = (await pos.printing.claimNext())!;
    expect(await pos.printing.recoverInterrupted()).toBe(1);
    expect(await pos.printing.complete(first, start.attemptId)).toBe(false);
    expect(await pos.printing.claimNext()).toBeNull();
    await pos.printing.confirmReceived(first);
    expect((await pos.printing.claimNext())!.id).toBe(second);
    const actions = await db.read((s) =>
      s.query("SELECT details FROM administrative_actions WHERE action='print.confirm_received'"),
    );
    expect(actions).toHaveLength(1);
  });

  it('mantiene visible el fallo que bloquea una impresora aunque existan más de cien documentos nuevos', async () => {
    const { pos } = await fixture();
    const printer = await pos.printing.savePrinter(config({ receipt: 1, kitchen: 0 }));
    const first = await pos.printing.enqueueTest(printer);
    const dispatch = (await pos.printing.claimNext())!;
    await pos.printing.fail(first, dispatch.attemptId, 'Impresora desconectada', false);
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    await pos.checkout(sale.id, 14000);
    const receipt = await pos.printing.latestReceipt(sale.id);
    for (let n = 0; n < 105; n++) await pos.printing.enqueueTest(printer);
    expect(await pos.printing.claimNext()).toBeNull();
    const snapshot = await pos.printing.snapshot();
    expect(snapshot.jobs.find((job) => job.id === first)?.status).toBe('failed');
    expect(snapshot.jobs.some((job) => job.id === receipt!.id)).toBe(false);
    expect((await pos.printing.latestReceipt(sale.id))?.id).toBe(receipt!.id);
    await pos.printing.retry(first);
    expect((await pos.printing.claimNext())!.id).toBe(first);
  });

  it('revalida permisos de configuración, impresión ajena y reimpresión', async () => {
    const { pos } = await fixture();
    const printer = await pos.printing.savePrinter(config({ receipt: 1, kitchen: 0 }));
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    await pos.checkout(sale.id, 14000);
    await cashier(pos, ['sell']);
    await expect(pos.printing.savePrinter(config({ id: printer }))).rejects.toThrow('Sin permiso');
    await expect(pos.printing.enqueueTest(printer)).rejects.toThrow('Sin permiso');
    await expect(pos.printing.enqueueReceipt(sale.id)).rejects.toThrow('Sin permiso');
    await expect(pos.printing.latestReceipt(sale.id)).rejects.toThrow('Sin permiso');
    const original = (await pos.printing.snapshot()).jobs[0];
    await expect(pos.printing.retry(original.id)).rejects.toThrow('Sin permiso');
  });
});

describe('comandas incrementales y conservación de preparación', () => {
  it('envía solo diferencias, cambios de notas y cancelaciones, sin repetir al guardar o cobrar', async () => {
    const { pos } = await fixture();
    await pos.printing.savePrinter(config());
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    const [first] = await pos.printing.enqueueKitchen(sale.id);
    expect(await pos.printing.enqueueKitchen(sale.id)).toEqual([]);
    let line = (await pos.snapshot()).lines[0];
    await pos.updateLine(sale.id, line.id, 3, '');
    const [more] = await pos.printing.enqueueKitchen(sale.id);
    let jobs = (await pos.printing.snapshot()).jobs;
    expect(text(jobs.find((j) => j.id === first)!)).toContain('AGREGAR 1 x');
    expect(text(jobs.find((j) => j.id === more)!)).toContain('AGREGAR 2 x');
    await pos.updateLine(sale.id, line.id, 2, 'Sin cebolla');
    const [changed] = await pos.printing.enqueueKitchen(sale.id);
    jobs = (await pos.printing.snapshot()).jobs;
    const changedText = text(jobs.find((j) => j.id === changed)!);
    expect(changedText).toContain('CANCELAR 3 x');
    expect(changedText).toContain('AGREGAR 2 x');
    expect(changedText).toContain('Sin cebolla');
    await pos.park(sale.id, 'Mesa');
    expect((await pos.printing.snapshot()).jobs).toHaveLength(3);
    await pos.resume(sale.id);
    await pos.checkout(sale.id, 28000);
    expect((await pos.printing.snapshot()).jobs).toHaveLength(3);
  });

  it('un cambio de nota general actualiza la cuenta sin volver a preparar productos', async () => {
    const { pos } = await fixture();
    await pos.printing.savePrinter(config());
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    await pos.printing.enqueueKitchen(sale.id);
    await pos.updateTicket(sale.id, {
      customerId: null,
      discountBps: 0,
      label: '',
      note: 'Entregar por separado',
    });
    const [update] = await pos.printing.enqueueKitchen(sale.id);
    const job = (await pos.printing.snapshot()).jobs.find((j) => j.id === update)!;
    expect(text(job)).toContain('ACTUALIZACION');
    expect(text(job)).toContain('NO REPETIR PREPARACION');
    expect(text(job)).toContain('Entregar por separado');
    expect(text(job)).not.toContain('AGREGAR');
    expect(text(job)).not.toContain('CANCELAR');
    expect(await pos.printing.enqueueKitchen(sale.id)).toEqual([]);
  });

  it('recuerda líneas borradas y cancelaciones de cuenta una sola vez aunque la impresora se desactive', async () => {
    const { pos } = await fixture();
    const printer = await pos.printing.savePrinter(config());
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    await pos.printing.enqueueKitchen(sale.id);
    const line = (await pos.snapshot()).lines[0];
    await pos.printing.savePrinter(config({ id: printer, active: 0 }));
    await pos.updateLine(sale.id, line.id, 0, '');
    const [cancel] = await pos.printing.enqueueKitchen(sale.id);
    expect(text((await pos.printing.snapshot()).jobs.find((j) => j.id === cancel)!)).toContain(
      'CANCELAR 1 x',
    );
    expect(await pos.printing.enqueueKitchen(sale.id)).toEqual([]);
    await pos.addProduct(sale.id, pid);
    expect(await pos.printing.enqueueKitchen(sale.id)).toEqual([]);
    await pos.printing.savePrinter(config({ id: printer }));
    await pos.printing.enqueueKitchen(sale.id);
    const before = (await pos.printing.snapshot()).jobs.length;
    await pos.cancel(sale.id, 'Prueba de cancelación');
    const jobs = (await pos.printing.snapshot()).jobs;
    expect(jobs.length).toBe(before + 1);
    expect(text(jobs[0])).toContain('CANCELAR 1 x');
  });

  it('congela el destino original de una línea y aplica nuevas rutas solo a líneas nuevas', async () => {
    const { pos } = await fixture();
    const kitchen = await pos.saveCategory('Cocina');
    const bar = await pos.saveCategory('Bebidas');
    const a = await pos.printing.savePrinter(config(), [kitchen]);
    const b = await pos.printing.savePrinter(config({ name: 'Bar', host: '192.168.1.51' }), [bar]);
    const pid = await product(pos, { category_id: kitchen });
    const sale = await currentSale(pos, pid);
    await pos.printing.enqueueKitchen(sale.id);
    const p = (await pos.snapshot()).products.find((p) => p.id === pid)!;
    await pos.saveProduct({ ...p, category_id: bar });
    await pos.printing.setCategories(a, [bar]);
    const line = (await pos.snapshot()).lines[0];
    await pos.updateLine(sale.id, line.id, 2, '');
    const [more] = await pos.printing.enqueueKitchen(sale.id);
    const claim = (await pos.printing.claimNext())!;
    await pos.printing.complete(claim.id, claim.attemptId);
    const delta = (await pos.printing.claimNext())!;
    expect(delta.id).toBe(more);
    expect(delta.printer.id).toBe(a);
    expect(delta.printer.id).not.toBe(b);
    await pos.updateLine(sale.id, line.id, 2, 'Nueva nota');
    await pos.addProduct(sale.id, pid);
    await pos.printing.enqueueKitchen(sale.id);
    const all = (await pos.printing.snapshot()).jobs;
    expect(all.some((j) => j.printerName === 'Bar')).toBe(true);
  });

  it('borrar la última categoría asignada no convierte una impresora restringida en todos los productos', async () => {
    const { pos } = await fixture();
    const category = await pos.saveCategory('Solo cocina');
    const id = await pos.printing.savePrinter(config(), [category]);
    await pos.deleteCategory(category);
    expect((await pos.printing.snapshot()).printers[0].all_products).toBe(0);
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    expect(await pos.printing.enqueueKitchen(sale.id)).toEqual([]);
    await pos.printing.setCategories(id, []);
    expect((await pos.printing.snapshot()).printers[0].all_products).toBe(1);
    expect(await pos.printing.enqueueKitchen(sale.id)).toHaveLength(1);
  });

  it('al unir mesas transfiere el historial de líneas sin repetir preparación y avisa del cambio de mesa', async () => {
    const { pos } = await fixture();
    await pos.printing.savePrinter(config());
    const pid = await product(pos);
    const [a, b] = await tableLayout(pos);
    const first = await pos.tables.open(a);
    await pos.addProduct(first, pid);
    await pos.printing.enqueueKitchen(first);
    const second = await pos.tables.open(b);
    await pos.addProduct(second, pid);
    await pos.printing.enqueueKitchen(second);
    await pos.tables.merge(first, b);
    const [changed] = await pos.printing.enqueueKitchen(second);
    const job = (await pos.printing.snapshot()).jobs.find((j) => j.id === changed)!;
    expect(text(job)).toContain('NO REPETIR PREPARACION');
    expect(text(job)).not.toContain('AGREGAR');
    expect(await pos.printing.enqueueKitchen(second)).toEqual([]);
  });

  it('un fallo de persistencia revierte cola e historial de preparación en la misma transacción', async () => {
    const { pos, db, persistence } = await fixture();
    await pos.printing.savePrinter(config());
    const pid = await product(pos);
    const sale = await currentSale(pos, pid);
    persistence.fail = true;
    await expect(pos.printing.enqueueKitchen(sale.id)).rejects.toThrow('disk full');
    persistence.fail = false;
    expect((await pos.printing.snapshot()).jobs).toEqual([]);
    expect(await db.read((s) => s.query('SELECT * FROM kitchen_line_state'))).toEqual([]);
    expect(await pos.printing.enqueueKitchen(sale.id)).toHaveLength(1);
  });
});
