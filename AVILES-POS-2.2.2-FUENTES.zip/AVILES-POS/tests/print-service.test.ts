import { describe, expect, it } from 'vitest';
import { fixture } from './support';
import { processPrintQueue } from '../src/ui/print-service';

async function printer(pos: Awaited<ReturnType<typeof fixture>>['pos'], host = '127.0.0.1') {
  return pos.printing.savePrinter(
    {
      name: 'Impresora de prueba',
      host,
      port: 9100,
      width: 80,
      cut: 1,
      receipt: 1,
      kitchen: 1,
      active: 1,
    },
    [],
  );
}
describe('envío real de cola con transporte sustituible', () => {
  it('serializa dos peticiones de envío y entrega cada documento una sola vez', async () => {
    const { pos } = await fixture();
    const id = await printer(pos);
    const first = await pos.printing.enqueueTest(id);
    const second = await pos.printing.enqueueTest(id);
    const delivered: string[] = [];
    let release!: () => void;
    const waiting = new Promise<void>((resolve) => {
      release = resolve;
    });
    const sender = async (job: { id: string }, bytes: Uint8Array) => {
      expect(Array.from(bytes.slice(0, 2))).toEqual([27, 64]);
      if (!delivered.length) await waiting;
      delivered.push(job.id);
    };
    const work = processPrintQueue(pos.printing, sender, true);
    const repeated = processPrintQueue(pos.printing, sender, true);
    expect(repeated).toBe(work);
    release();
    await work;
    expect(delivered).toEqual([first, second]);
    expect((await pos.printing.snapshot()).jobs.every((j) => j.status === 'sent')).toBe(true);
  });
  it('un fallo sin bytes bloquea su impresora, permite otra y solo reintenta al solicitarlo', async () => {
    const { pos } = await fixture();
    const a = await printer(pos);
    const first = await pos.printing.enqueueTest(a);
    const later = await pos.printing.enqueueTest(a);
    const b = await printer(pos, '127.0.0.2');
    const other = await pos.printing.enqueueTest(b);
    const delivered: string[] = [];
    await processPrintQueue(
      pos.printing,
      async (job) => {
        if (job.id === first)
          throw Object.assign(new Error('Sin red de prueba'), { code: 'PRINT_OFFLINE' });
        delivered.push(job.id);
      },
      true,
    );
    const jobs = (await pos.printing.snapshot()).jobs;
    expect(jobs.find((j) => j.id === first)!.status).toBe('failed');
    expect(jobs.find((j) => j.id === later)!.status).toBe('pending');
    expect(delivered).toEqual([other]);
    await processPrintQueue(
      pos.printing,
      async (job) => {
        delivered.push(job.id);
      },
      true,
    );
    expect(delivered).toEqual([other]);
    await pos.printing.retry(first);
    await processPrintQueue(
      pos.printing,
      async (job) => {
        delivered.push(job.id);
      },
      true,
    );
    expect(delivered).toEqual([other, first, later]);
  });
  it('un envío incierto exige copia explícita y mantiene la copia delante de documentos posteriores', async () => {
    const { pos } = await fixture();
    const id = await printer(pos);
    const first = await pos.printing.enqueueTest(id);
    const later = await pos.printing.enqueueTest(id);
    await processPrintQueue(
      pos.printing,
      async () => {
        throw Object.assign(new Error('Corte de red durante envío'), { code: 'PRINT_UNCERTAIN' });
      },
      true,
    );
    expect((await pos.printing.snapshot()).jobs.find((j) => j.id === first)!.status).toBe(
      'unknown',
    );
    const delivered: string[] = [];
    await processPrintQueue(
      pos.printing,
      async (job) => {
        delivered.push(job.id);
      },
      true,
    );
    expect(delivered).toEqual([]);
    const copy = await pos.printing.retry(first);
    await processPrintQueue(
      pos.printing,
      async (job, bytes) => {
        if (job.id === copy) expect(String.fromCharCode(...bytes)).toContain('COPIA');
        delivered.push(job.id);
      },
      true,
    );
    expect(delivered).toEqual([copy, later]);
    expect((await pos.printing.snapshot()).jobs.find((j) => j.id === first)!.status).toBe(
      'superseded',
    );
  });
  it('restaurar un respaldo retiene la cola para revisión y no vuelve a imprimirla automáticamente', async () => {
    const { pos } = await fixture();
    const id = await printer(pos);
    const jobId = await pos.printing.enqueueTest(id);
    const backup = await pos.backups.create();
    await pos.backups.restore(JSON.stringify(backup), 'RESTAURAR', backup.manifest.sha256);
    await pos.access.login('832641');
    expect((await pos.printing.snapshot()).jobs.find((j) => j.id === jobId)!.status).toBe(
      'unknown',
    );
    let sent = false;
    await processPrintQueue(
      pos.printing,
      async () => {
        sent = true;
      },
      true,
    );
    expect(sent).toBe(false);
  });
  it('no restaura datos mientras un documento está en tránsito', async () => {
    const { pos } = await fixture();
    const id = await printer(pos);
    await pos.printing.enqueueTest(id);
    const job = (await pos.printing.claimNext())!;
    const safety = await pos.backups.create();
    await expect(
      pos.backups.restore(JSON.stringify(safety), 'RESTAURAR', safety.manifest.sha256),
    ).rejects.toThrow('termine el envío');
    expect((await pos.printing.snapshot()).jobs[0].status).toBe('sending');
    await pos.printing.complete(job.id, job.attemptId);
  });
});
