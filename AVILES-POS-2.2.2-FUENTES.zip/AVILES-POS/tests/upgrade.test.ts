import { describe, it, expect } from 'vitest';
import initSqlJs from 'sql.js';
import { spawnSync } from 'node:child_process';
import { Database, type SqlDriver } from '../src/db/database';
import { WasmDriver } from '../src/db/wasm-driver';
import { migrate, SCHEMA_VERSION } from '../src/db/migrations';
import { migrate as v1 } from './fixtures/migrations-v1';
import { migrate as v2 } from './fixtures/migrations-v2';
import { migrate as v3 } from './fixtures/migrations-v3';
import { migrate as v4 } from './fixtures/migrations-v4';
import { migrate as v5 } from './fixtures/migrations-v5';
import { fixture, product } from './support';

describe('actualización desde las fuentes de versiones anteriores', () => {
  it.each([
    [1, v1],
    [2, v2],
    [3, v3],
    [4, v4],
    [5, v5],
  ] as const)(
    'esquema %s conserva catálogo, fotos, ventas, permisos y mesas disponibles',
    async (version, original) => {
      const db = new Database(
        new WasmDriver(await initSqlJs(), {
          async load() {
            return undefined;
          },
          async save() {},
        }),
      );
      await original(db);
      await db.transaction(async (sql) => {
        await sql.run("INSERT INTO categories(id,name,color) VALUES('cat','Bebidas','#49aa50')");
        await sql.run(
          "INSERT INTO products(id,name,category_id,price,cost,photo,stock,track_stock) VALUES('product','Producto heredado','cat',100,40,'data:image/png;base64,aGVsbG8=',7,1)",
        );
        await sql.run(
          "INSERT INTO sales(id,number,status,total,business_name,created_at,updated_at,paid_at) VALUES('paid',1,'paid',100,'Original','2026-10-19','2026-10-19','2026-10-19'),('pending',2,'parked',100,'Original','2026-10-19','2026-10-19',NULL)",
        );
        await sql.run(
          "INSERT INTO sale_lines(id,sale_id,product_id,name,unit_price,quantity) VALUES('line','paid','product','Producto heredado',100,1),('pending-line','pending','product','Producto heredado',100,1)",
        );
        await sql.run(
          version === 1
            ? "INSERT INTO payments(id,sale_id,method,amount,tendered,change_amount,created_at) VALUES('payment','paid','cash',100,200,100,'2026-10-19')"
            : "INSERT INTO payments(id,sale_id,position,method,amount,tendered,change_amount,created_at) VALUES('payment','paid',0,'cash',100,200,100,'2026-10-19')",
        );
        if (version >= 5) {
          await sql.run('UPDATE payments SET original_tendered=tendered,change_mxn=change_amount');
          await sql.run(
            "INSERT INTO stock_items(id,name,kind,unit,cost,stock,low_stock,active) VALUES('ingredient','Ingrediente heredado','ingredient','kg',1000,2500,500,1)",
          );
          await sql.run(
            "INSERT INTO recipe_lines(product_id,item_id,quantity) VALUES('product','ingredient',150)",
          );
        }
        if (version >= 3) {
          await sql.run(
            "INSERT INTO employees(id,name,identifier,role,active,pin_hash,salt,iterations,created_at) VALUES('employee','Empleado heredado','caja','cashier',1,'historical-hash','historical-salt',600000,'2026-10-19')",
          );
          await sql.run(
            "INSERT INTO employee_permissions(employee_id,permission,allowed) VALUES('employee','sell',1),('employee','settings',0)",
          );
        }
        if (version >= 4) {
          await sql.run("INSERT INTO dining_areas(id,name) VALUES('area','Salón')");
          await sql.run(
            "INSERT INTO dining_tables(id,area_id,name,shape,x,y,width,height,capacity) VALUES('table','area','1','square',20,20,140,140,4)",
          );
          await sql.run(
            "INSERT INTO table_sessions(id,table_id,sale_id,opened_at) VALUES('session','table','pending','2026-10-19')",
          );
        }
      });
      const before = await db.read(async (sql) => ({
        products: await sql.query('SELECT * FROM products'),
        sales: await sql.query('SELECT * FROM sales'),
        lines: await sql.query('SELECT * FROM sale_lines'),
        payments: await sql.query('SELECT * FROM payments'),
      }));
      await migrate(db);
      await migrate(db);
      await db.read(async (sql) => {
        expect(await sql.query('PRAGMA user_version')).toEqual([{ user_version: SCHEMA_VERSION }]);
        expect(await sql.query('SELECT * FROM products')).toMatchObject(before.products);
        expect(await sql.query('SELECT * FROM sales')).toMatchObject(before.sales);
        expect(await sql.query('SELECT * FROM sale_lines')).toMatchObject(before.lines);
        expect(await sql.query('SELECT * FROM payments')).toMatchObject(before.payments);
        expect(
          (
            await sql.query<{ original_tendered: number }>('SELECT original_tendered FROM payments')
          )[0].original_tendered,
        ).toBe(200);
        if (version >= 3) {
          expect(await sql.query('SELECT identifier,pin_hash FROM employees')).toEqual([
            { identifier: 'caja', pin_hash: 'historical-hash' },
          ]);
          expect(
            await sql.query("SELECT allowed FROM employee_permissions WHERE permission='settings'"),
          ).toEqual([{ allowed: 0 }]);
        }
        if (version >= 4)
          expect(await sql.query('SELECT closed_at FROM table_sessions')).toEqual([
            { closed_at: null },
          ]);
        if (version >= 5) {
          expect(await sql.query('SELECT stock,cost FROM stock_items')).toEqual([
            { stock: 2500, cost: 1000 },
          ]);
          expect(await sql.query('SELECT quantity FROM recipe_lines')).toEqual([{ quantity: 150 }]);
          expect(await sql.query('SELECT * FROM printers')).toEqual([]);
        }
        expect(await sql.query('PRAGMA foreign_key_check')).toEqual([]);
        expect(await sql.query('PRAGMA integrity_check')).toEqual([{ integrity_check: 'ok' }]);
      });
    },
  );
  it('DDL compatible con SQLite de archivo y WAL; actualización conserva datos', async () => {
    const statements: string[] = [];
    const driver: SqlDriver = {
      async query<T>() {
        return [{ user_version: 0 }] as T[];
      },
      async run(sql) {
        statements.push(sql);
      },
      async begin() {},
      async commit() {},
      async rollback() {},
    };
    await migrate(new Database(driver));
    const python = `import sqlite3,tempfile,json,sys,os\nwith tempfile.TemporaryDirectory() as d:\n c=sqlite3.connect(os.path.join(d,'pos.db'))\n c.execute('PRAGMA foreign_keys=ON')\n assert c.execute('PRAGMA journal_mode=WAL').fetchone()[0]=='wal'\n c.execute('BEGIN IMMEDIATE')\n for s in json.load(sys.stdin): c.execute(s)\n c.commit()\n assert c.execute('PRAGMA user_version').fetchone()[0]==${SCHEMA_VERSION}\n assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'\n assert c.execute('PRAGMA foreign_key_check').fetchall()==[]\n print('SQLite file/WAL integrity OK')\n`;
    const result = spawnSync('python3', ['-c', python], {
      input: JSON.stringify(statements),
      encoding: 'utf8',
    });
    expect(result.stderr).toBe('');
    expect(result.status).toBe(0);
    expect(result.stdout).toContain('integrity OK');
  });
  it('respaldo espera la transacción y no mezcla cambios posteriores', async () => {
    const { pos } = await fixture();
    const p = await product(pos);
    const { active } = await pos.snapshot();
    const [_, file] = await Promise.all([pos.addProduct(active.id, p), pos.backups.create()]);
    await pos.addProduct(active.id, p);
    const lines = file.payload.sale_lines;
    const quantity = lines.columns.indexOf('quantity');
    expect(lines.rows[0][quantity]).toBe(1);
    expect((await pos.snapshot()).lines[0].quantity).toBe(2);
    await pos.backups.inspect(JSON.stringify(file));
  });
  it('los abonos de mesa no cierran sesión ni descuentan hasta liquidar', async () => {
    const { pos } = await fixture();
    const p = await product(pos, { price: 10000 });
    const area = await pos.tables.saveArea('Salón prueba');
    const table = await pos.tables.save({
      area_id: area,
      name: '1',
      shape: 'square',
      x: 20,
      y: 20,
      width: 140,
      height: 140,
      capacity: 4,
    });
    const sale = await pos.tables.open(table);
    await pos.addProduct(sale, p);
    await pos.payPartial(
      sale,
      [{ method: 'cash', amount: 5000, tendered: 5000 }],
      crypto.randomUUID(),
    );
    expect((await pos.tables.snapshot()).tables[0].bill?.sale_id).toBe(sale);
    await pos.checkout(sale, 5000);
    expect((await pos.tables.snapshot()).tables[0].bill).toBeNull();
    expect((await pos.snapshot()).products[0].stock).toBe(9);
  });
});
