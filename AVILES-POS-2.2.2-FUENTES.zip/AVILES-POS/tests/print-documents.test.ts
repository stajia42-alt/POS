import { describe, expect, it } from 'vitest';
import {
  encodeEscPos,
  kitchenDocument,
  receiptDocument,
  type PrintDocument,
} from '../src/domain/print-documents';
import type { Receipt } from '../src/domain/types';
import { fixture, product } from './support';

function fits(document: PrintDocument) {
  expect(document.lines.every((line) => Array.from(line).length <= document.columns)).toBe(true);
  expect(document.lines.join('')).not.toMatch(
    /[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/,
  );
}
const compact = (document: PrintDocument) => document.lines.join(' ').replace(/\s+/g, ' ');

async function saleReceipt() {
  const { pos } = await fixture();
  const { active, business } = await pos.snapshot();
  await pos.saveBusiness({
    ...business,
    name: 'Café Peña y Limón',
    address: 'Avenida de la Constitución 123, Colonia Centro, Ensenada',
    phone: '646 123 4567',
    usdChange: true,
  });
  await pos.cash.move({
    shiftId: (await pos.snapshot()).shift!.id,
    kind: 'in',
    currency: 'USD',
    amount: 1000,
    reason: 'Cambio de prueba',
  });
  const pid = await product(pos, {
    name: 'Camarón al limón con salsa de la casa y guarnición',
    price: 35000,
  });
  await pos.addProduct(active.id, pid);
  await pos.payPartial(
    active.id,
    [{ method: 'cash', amount: 10000, tendered: 10000 }],
    crypto.randomUUID(),
  );
  const receipt = await pos.checkoutPayments(active.id, [
    { method: 'cash', currency: 'USD', tendered: 1400, changeCurrency: 'USD' },
  ]);
  // Reprinting must use the captured exchange rate, even after changing settings.
  await pos.saveBusiness({ ...(await pos.snapshot()).business, exchangeRate: 200000 });
  return { receipt, pos };
}

describe('documentos de tickets y comandas', () => {
  it.each([32, 48] as const)(
    'recibo de %i columnas conserva abonos y cambio físico por moneda',
    async (columns) => {
      const { receipt, pos } = await saleReceipt();
      const original = JSON.stringify(receipt);
      const doc = receiptDocument(
        await pos.getReceipt(receipt.sale.id),
        'Gracias por su visita',
        columns,
      );
      fits(doc);
      const text = compact(doc);
      expect(text).toContain('Café Peña y Limón');
      expect(text).toContain('Avenida de la Constitución 123, Colonia Centro, Ensenada');
      expect(text).toContain('Camarón al limón con salsa de la casa y guarnición');
      expect(text).toContain('TOTAL $350.00 MXN');
      expect(text).toContain('Aplicado $100.00 MXN');
      expect(text).toContain('Aplicado $250.00 MXN');
      expect(text).toContain('Recibido $14.00 USD');
      expect(text).toContain('1 USD = 18.0000 MXN');
      expect(text).toContain('Cambio MXN $0.02 MXN');
      expect(text).toContain('Cambio USD $0.11 USD');
      expect(text).not.toContain('20.0000');
      expect(JSON.stringify(receipt)).toBe(original);
    },
  );

  it('conserva cantidades, centavos, descuentos, impuestos y referencias capturados', async () => {
    const { receipt } = await saleReceipt();
    const sample: Receipt = {
      ...receipt,
      sale: {
        ...receipt.sale,
        subtotal: 303,
        discount_bps: 1000,
        discount: 30,
        tax_bps: 1600,
        tax: 44,
        total: 317,
        note: 'Para llevar',
      },
      lines: [
        {
          ...receipt.lines[0],
          name: 'Café con piñón',
          unit_price: 101,
          quantity: 3,
          note: 'Sin azúcar',
        },
      ],
      payments: [
        {
          ...receipt.payments[0],
          method: 'card',
          amount: 317,
          tendered: 317,
          reference: 'REF-1234567890-Referencia-extensa-para-el-cliente',
        },
      ],
    };
    const doc = receiptDocument(sample, '', 32, true);
    fits(doc);
    const text = compact(doc);
    expect(text).toContain('COPIA');
    expect(text).toContain('3 x Café con piñón');
    expect(text).toContain('$1.01 MXN c/u $3.03 MXN');
    expect(text).toContain('Nota: Sin azúcar');
    expect(text).toContain('Descuento (10%) -$0.30 MXN');
    expect(text).toContain('Impuesto (16%) $0.44 MXN');
    expect(text).toContain('TOTAL $3.17 MXN');
    expect(text).toContain('Pago 1: Tarjeta');
    expect(doc.lines.join('').replaceAll(' ', '')).toContain(
      'REF-1234567890-Referencia-extensa-para-el-cliente',
    );
    expect(text).toContain('Nota de cuenta: Para llevar');
    expect(text).not.toContain('Recibido');
  });

  it.each([32, 48] as const)(
    'comanda de %i columnas identifica agregados, cancelaciones y notas sin precios',
    (columns) => {
      const doc = kitchenDocument(
        {
          orderNumber: 23,
          tableName: 'Terraza 4',
          waiterName: 'María Núñez',
          areaName: 'Cocina caliente',
          createdAt: '2026-10-21T18:45:00.000Z',
          note: 'Primero las entradas, después los platos fuertes',
          lines: [
            {
              name: 'Enchiladas con salsa de chile poblano y guarnición extra',
              quantity: 2,
              note: 'Sin cebolla, separar salsa y evitar cacahuates',
            },
            {
              name: 'Café de olla',
              quantity: 1,
              note: 'Ya no lo requiere la mesa',
              kind: 'cancel',
            },
          ],
        },
        columns,
        true,
      );
      fits(doc);
      const text = compact(doc);
      expect(text).toContain('COCINA CALIENTE');
      expect(text).toContain('COPIA');
      expect(text).toContain('Cuenta #0023');
      expect(text).toContain('Mesa: Terraza 4');
      expect(text).toContain('Mesero: María Núñez');
      expect(text).toContain(
        'AGREGAR 2 x Enchiladas con salsa de chile poblano y guarnición extra',
      );
      expect(text).toContain('Sin cebolla, separar salsa y evitar cacahuates');
      expect(text).toContain('CANCELAR 1 x Café de olla');
      expect(text).not.toMatch(/\$|MXN|USD/);
    },
  );

  it('neutraliza controles de impresión y conserva palabras largas completas', () => {
    const word = 'Productoñ'.repeat(12);
    const doc = kitchenDocument(
      {
        orderNumber: 1,
        tableName: 'Mesa\n5\u001b@',
        waiterName: 'Ana\u0000Ríos',
        areaName: 'Cocina\u001dV',
        createdAt: '2026-10-21T18:45:00.000Z',
        note: 'Sin\r\ncebolla\u202e',
        lines: [{ name: word, quantity: 1, note: 'Extra\tlimón\u000c\u001b\u007f' }],
      },
      32,
    );
    fits(doc);
    expect(doc.title).not.toMatch(/[\u0000-\u001f]/);
    expect(doc.lines.join('').replaceAll(' ', '')).toContain(word);
    expect(compact(doc)).toContain('Mesa: Mesa 5 @');
    expect(compact(doc)).toContain('Sin cebolla');
    expect(compact(doc)).toContain('Extra limón');
  });

  it('actualiza solo mesa, mesero y notas sin volver a ordenar la preparación', () => {
    const input = {
      orderNumber: 25,
      tableName: 'Terraza 8',
      waiterName: 'María Núñez',
      areaName: 'Cocina',
      createdAt: '2026-10-21T18:45:00Z',
      note: 'La mesa cambió de lugar. Servir primero las entradas.',
      updateOnly: true,
      lines: [],
    };
    const doc = kitchenDocument(input, 32);
    fits(doc);
    const text = compact(doc);
    expect(text).toContain('ACTUALIZACION DE CUENTA');
    expect(text).toContain('NO REPETIR PREPARACION');
    expect(text).toContain('Mesa: Terraza 8');
    expect(text).toContain('Mesero: María Núñez');
    expect(text).toContain('La mesa cambió de lugar. Servir primero las entradas.');
    expect(text).not.toMatch(/AGREGAR|CANCELAR/);
    expect(() => encodeEscPos(doc)).not.toThrow();
    expect(() => kitchenDocument({ ...input, updateOnly: false }, 32)).toThrow('No hay artículos');
    expect(() =>
      kitchenDocument({ ...input, lines: [{ name: 'Café', quantity: 1, note: '' }] }, 32),
    ).toThrow('no debe repetir');
  });

  it('rechaza comandas vacías, cantidades inválidas y fechas inválidas', () => {
    const input = {
      orderNumber: 1,
      tableName: '',
      waiterName: '',
      areaName: '',
      createdAt: '2026-10-21T18:45:00Z',
      note: '',
      lines: [{ name: 'Café', quantity: 1, note: '' }],
    };
    expect(() => kitchenDocument({ ...input, lines: [] }, 32)).toThrow('No hay artículos');
    expect(() =>
      kitchenDocument({ ...input, lines: [{ ...input.lines[0], quantity: -1 }] }, 32),
    ).toThrow();
    expect(() => kitchenDocument({ ...input, createdAt: 'fecha inválida' }, 48)).toThrow('Fecha');
  });
});

describe('perfil ESC/POS CP850', () => {
  it('envía los bytes CP850 de español conservando la alineación y corta al terminar', () => {
    const bytes = encodeEscPos({
      title: 'Prueba',
      columns: 48,
      lines: ['  ñÑáéíóúü¿¡', 'Total                  $1.00 MXN'],
    });
    expect(Array.from(bytes.slice(0, 11))).toEqual([
      0x1b, 0x40, 0x1b, 0x74, 2, 0x1b, 0x4d, 0, 0x1b, 0x61, 0,
    ]);
    expect(Array.from(bytes.slice(11, 24))).toEqual([
      32, 32, 0xa4, 0xa5, 0xa0, 0x82, 0xa1, 0xa2, 0xa3, 0x81, 0xa8, 0xad, 10,
    ]);
    expect(Array.from(bytes.slice(-4))).toEqual([0x1d, 0x56, 0x42, 0]);
    expect(Array.from(bytes.slice(24, 29))).toEqual(Array.from(new TextEncoder().encode('Total')));
  });

  it('neutraliza comandos dentro del texto y permite omitir el corte', () => {
    const bytes = encodeEscPos(
      {
        title: 'Prueba',
        columns: 32,
        lines: ['Hola\u001b@\u001dV\u0000\nmesa', 'Cafe\u0301 — œ 漢'],
      },
      false,
    );
    const body = Array.from(bytes.slice(11));
    expect(body).not.toContain(0x1b);
    expect(body).not.toContain(0x1d);
    expect(body).not.toContain(0);
    expect(body).toEqual([
      ...new TextEncoder().encode('Hola @ V  mesa'),
      10,
      67,
      97,
      102,
      0x82,
      32,
      45,
      32,
      63,
      32,
      63,
      10,
      10,
      10,
      10,
    ]);
  });

  it('rechaza documentos vacíos y líneas que exceden el ancho configurado', () => {
    expect(() => encodeEscPos({ title: '', columns: 32, lines: [] })).toThrow('No hay texto');
    expect(() => encodeEscPos({ title: '', columns: 32, lines: ['X'.repeat(33)] })).toThrow(
      'excede',
    );
  });
});
