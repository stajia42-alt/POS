package mx.aviles.pos;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Base64;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.Test;

public class TcpPrinterSenderTest {
    @Test
    public void deliversExactBinaryPayloadToTcpAndClosesConnection() throws Exception {
        byte[] payload = new byte[32768];
        for (int i = 0; i < payload.length; i++) payload[i] = (byte) i;
        ExecutorService server = Executors.newSingleThreadExecutor();
        try (ServerSocket listener = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
             TcpPrinterSender sender = new TcpPrinterSender()) {
            listener.setSoTimeout(3000);
            Future<byte[]> received = server.submit(() -> {
                try (Socket client = listener.accept(); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    client.setSoTimeout(3000);
                    byte[] chunk = new byte[1024];
                    int count;
                    while ((count = client.getInputStream().read(chunk)) != -1) buffer.write(chunk, 0, count);
                    return buffer.toByteArray();
                }
            });
            assertEquals(payload.length, sender.send("127.0.0.1", listener.getLocalPort(), payload));
            assertArrayEquals(payload, received.get(4, TimeUnit.SECONDS));
        } finally {
            server.shutdownNow();
        }
    }

    @Test
    public void refusedConnectionIsSafeToRetryAndNoBytesWereAttempted() throws Exception {
        int port;
        try (ServerSocket unused = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))) {
            port = unused.getLocalPort();
        }
        try (TcpPrinterSender sender = new TcpPrinterSender()) {
            TcpPrinterSender.PrintFailure error = assertThrows(TcpPrinterSender.PrintFailure.class,
                () -> sender.send("127.0.0.1", port, new byte[] { 27, 64, 10 }));
            assertFalse(error.uncertain);
        }
    }

    @Test
    public void failureAfterWriteStartsIsUncertainAndNeverRetried() throws Exception {
        AtomicInteger sockets = new AtomicInteger();
        AtomicInteger writes = new AtomicInteger();
        FakeSocket socket = new FakeSocket(new OutputStream() {
            @Override public void write(int value) throws IOException {
                writes.incrementAndGet();
                throw new IOException("Simulated partial write");
            }
        });
        try (TcpPrinterSender sender = new TcpPrinterSender(50, 200, () -> {
            sockets.incrementAndGet();
            return socket;
        })) {
            TcpPrinterSender.PrintFailure error = assertThrows(TcpPrinterSender.PrintFailure.class,
                () -> sender.send("192.168.1.50", 9100, new byte[] { 27, 64, 10 }));
            assertTrue(error.uncertain);
            assertEquals(1, sockets.get());
            assertEquals(1, writes.get());
            assertTrue(socket.wasClosed.get());
            assertEquals(50, socket.connectTimeout);
        }
    }

    @Test
    public void totalDeadlineClosesBlockedWriteAndKeepsUncertainOutcome() throws Exception {
        CountDownLatch closed = new CountDownLatch(1);
        FakeSocket socket = blockedSocket(closed);
        long start = System.nanoTime();
        try (TcpPrinterSender sender = new TcpPrinterSender(50, 150, () -> socket)) {
            TcpPrinterSender.PrintFailure error = assertThrows(TcpPrinterSender.PrintFailure.class,
                () -> sender.send("192.168.1.50", 9100, new byte[] { 65 }));
            assertTrue(error.uncertain);
            assertTrue(socket.wasClosed.get());
            assertTrue(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start) < 3000);
        }
    }

    @Test
    public void closingSenderCancelsInflightWriteInsteadOfLeavingWorkerBlocked() throws Exception {
        CountDownLatch closed = new CountDownLatch(1);
        CountDownLatch entered = new CountDownLatch(1);
        FakeSocket socket = new FakeSocket(new OutputStream() {
            @Override public void write(int value) throws IOException {
                entered.countDown();
                awaitClose(closed);
            }
        }) {
            @Override public synchronized void close() {
                super.close();
                closed.countDown();
            }
        };
        ExecutorService worker = Executors.newSingleThreadExecutor();
        TcpPrinterSender sender = new TcpPrinterSender(1000, 5000, () -> socket);
        try {
            Future<TcpPrinterSender.PrintFailure> failure = worker.submit(() -> {
                try {
                    sender.send("192.168.1.50", 9100, new byte[] { 65 });
                    throw new AssertionError("Send should be cancelled");
                } catch (TcpPrinterSender.PrintFailure error) {
                    return error;
                }
            });
            assertTrue(entered.await(2, TimeUnit.SECONDS));
            sender.close();
            assertTrue(failure.get(2, TimeUnit.SECONDS).uncertain);
        } finally {
            sender.close();
            worker.shutdownNow();
        }
    }

    @Test
    public void invalidTargetOrPayloadDoesNotCreateAnySocket() throws Exception {
        AtomicInteger sockets = new AtomicInteger();
        try (TcpPrinterSender sender = new TcpPrinterSender(50, 100, () -> {
            sockets.incrementAndGet();
            return new Socket();
        })) {
            for (String host : new String[] { "printer.local", "192.168.1.256", "1.2.3", "1.2.3.4/24", "1.2.3.-1", "1.2.3. 4", "" }) {
                assertThrows(IllegalArgumentException.class, () -> sender.send(host, 9100, new byte[] { 65 }));
            }
            assertThrows(IllegalArgumentException.class, () -> sender.send("127.0.0.1", 0, new byte[] { 65 }));
            assertThrows(IllegalArgumentException.class, () -> sender.send("127.0.0.1", 65536, new byte[] { 65 }));
            assertThrows(IllegalArgumentException.class, () -> sender.send("127.0.0.1", 9100, new byte[0]));
            assertThrows(IllegalArgumentException.class, () -> sender.send("127.0.0.1", 9100, new byte[TcpPrinterSender.MAX_PAYLOAD_BYTES + 1]));
            assertEquals(0, sockets.get());
            sender.close();
            TcpPrinterSender.PrintFailure error = assertThrows(TcpPrinterSender.PrintFailure.class,
                () -> sender.send("127.0.0.1", 9100, new byte[] { 65 }));
            assertFalse(error.uncertain);
            assertEquals(0, sockets.get());
        }
    }

    @Test
    public void strictBase64PreservesAllByteValuesAndMaximumDocumentSize() {
        for (int length : new int[] { 1, 2, 3, 256, TcpPrinterSender.MAX_PAYLOAD_BYTES }) {
            byte[] bytes = new byte[length];
            for (int i = 0; i < bytes.length; i++) bytes[i] = (byte) i;
            assertArrayEquals(bytes, TcpPrinterSender.decodePayload(Base64.getEncoder().encodeToString(bytes)));
        }
    }

    @Test
    public void strictBase64RejectsWhitespaceGarbageWrongPaddingAndOversize() {
        for (String value : new String[] { "", "AQ", "AQ==\n", "AQ ==", "A===", "AA=A", "AR==", "AAB=", "AAAA!AAA", "____", "====" }) {
            assertThrows(value, IllegalArgumentException.class, () -> TcpPrinterSender.decodePayload(value));
        }
        assertThrows(IllegalArgumentException.class, () -> TcpPrinterSender.decodePayload(null));
        byte[] tooLarge = new byte[TcpPrinterSender.MAX_PAYLOAD_BYTES + 1];
        assertThrows(IllegalArgumentException.class,
            () -> TcpPrinterSender.decodePayload(Base64.getEncoder().encodeToString(tooLarge)));
    }

    private static FakeSocket blockedSocket(CountDownLatch closed) {
        return new FakeSocket(new OutputStream() {
            @Override public void write(int value) throws IOException { awaitClose(closed); }
        }) {
            @Override public synchronized void close() {
                super.close();
                closed.countDown();
            }
        };
    }

    private static void awaitClose(CountDownLatch closed) throws IOException {
        try {
            if (!closed.await(3, TimeUnit.SECONDS)) throw new IOException("Test write did not close");
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new IOException(error);
        }
        throw new IOException("Closed while writing");
    }

    private static class FakeSocket extends Socket {
        final AtomicBoolean wasClosed = new AtomicBoolean(false);
        final OutputStream output;
        int connectTimeout;
        FakeSocket(OutputStream output) { this.output = output; }
        @Override public void connect(SocketAddress endpoint, int timeout) { this.connectTimeout = timeout; }
        @Override public void setTcpNoDelay(boolean enabled) {}
        @Override public OutputStream getOutputStream() { return output; }
        @Override public synchronized void close() { wasClosed.set(true); }
    }
}
