package mx.aviles.pos;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** Direct ESC/POS TCP transport; the application owns durable jobs and explicit retries. */
@CapacitorPlugin(name = "ThermalPrinter")
public class ThermalPrinterPlugin extends Plugin {
    private final TcpPrinterSender sender = new TcpPrinterSender();
    private final ThreadPoolExecutor worker = new ThreadPoolExecutor(
        1, 1, 0, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(8), task -> {
            Thread thread = new Thread(task, "aviles-printer-send");
            thread.setDaemon(true);
            return thread;
        }
    );

    @PluginMethod
    public void send(PluginCall call) {
        final String host = call.getString("host");
        final String encoded = call.getString("dataBase64");
        final Integer suppliedPort = call.getInt("port");
        if (call.getData().has("port") && suppliedPort == null) {
            call.reject("El puerto de la impresora debe ser un número entero.", "PRINT_OFFLINE");
            return;
        }
        final int port = suppliedPort == null ? 9100 : suppliedPort;
        try {
            worker.execute(() -> {
                try {
                    int sent = sender.send(host, port, TcpPrinterSender.decodePayload(encoded));
                    JSObject result = new JSObject();
                    result.put("bytesSent", sent);
                    call.resolve(result);
                } catch (TcpPrinterSender.PrintFailure error) {
                    call.reject(error.getMessage(), error.uncertain ? "PRINT_UNCERTAIN" : "PRINT_OFFLINE");
                } catch (IllegalArgumentException error) {
                    call.reject(error.getMessage(), "PRINT_OFFLINE");
                }
            });
        } catch (RejectedExecutionException error) {
            call.reject("La conexión de impresión está ocupada o cerrada. Intenta de nuevo cuando termine el envío actual.", "PRINT_OFFLINE");
        }
    }

    @Override
    protected void handleOnDestroy() {
        sender.close();
        worker.shutdownNow();
        super.handleOnDestroy();
    }
}
