package mx.aviles.pos;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Sends one immutable ESC/POS payload. A completed socket write does not confirm paper output. */
public final class TcpPrinterSender implements Closeable {
    public static final int MAX_PAYLOAD_BYTES = 262144;
    private static final int CONNECT_TIMEOUT_MS = 4000;
    private static final int TOTAL_TIMEOUT_MS = 12000;

    interface SocketFactory {
        Socket create() throws IOException;
    }

    public static final class PrintFailure extends IOException {
        public final boolean uncertain;

        PrintFailure(boolean uncertain, Throwable cause) {
            super(
                uncertain
                    ? "No se pudo confirmar el envío. Revisa si salió papel antes de volver a enviarlo."
                    : "No se pudo conectar con la impresora. Revisa la IP, el puerto y la red.",
                cause
            );
            this.uncertain = uncertain;
        }
    }

    private final int connectTimeoutMs;
    private final int totalTimeoutMs;
    private final SocketFactory socketFactory;
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final Set<Socket> active = ConcurrentHashMap.newKeySet();
    private final ScheduledExecutorService deadlines = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread thread = new Thread(task, "aviles-printer-deadline");
        thread.setDaemon(true);
        return thread;
    });

    public TcpPrinterSender() {
        this(CONNECT_TIMEOUT_MS, TOTAL_TIMEOUT_MS, Socket::new);
    }

    // Shorter deadlines and a socket factory permit deterministic transport-failure tests.
    TcpPrinterSender(int connectTimeoutMs, int totalTimeoutMs, SocketFactory socketFactory) {
        if (connectTimeoutMs < 1 || totalTimeoutMs < connectTimeoutMs || socketFactory == null)
            throw new IllegalArgumentException("Plazos de conexión no válidos.");
        this.connectTimeoutMs = connectTimeoutMs;
        this.totalTimeoutMs = totalTimeoutMs;
        this.socketFactory = socketFactory;
    }

    public int send(String host, int port, byte[] payload) throws PrintFailure {
        byte[] address = ipv4(host);
        if (port < 1 || port > 65535)
            throw new IllegalArgumentException("El puerto debe estar entre 1 y 65535.");
        if (payload == null || payload.length == 0 || payload.length > MAX_PAYLOAD_BYTES)
            throw new IllegalArgumentException("El documento está vacío o supera el límite de 256 KiB.");
        if (closed.get()) throw new PrintFailure(false, new IOException("Conexión cerrada."));

        boolean writeStarted = false;
        Socket socket = null;
        ScheduledFuture<?> deadline = null;
        AtomicBoolean timedOut = new AtomicBoolean(false);
        try {
            socket = socketFactory.create();
            active.add(socket);
            if (closed.get()) throw new IOException("Conexión cerrada.");
            final Socket pending = socket;
            deadline = deadlines.schedule(() -> {
                timedOut.set(true);
                closeSocket(pending);
            }, totalTimeoutMs, TimeUnit.MILLISECONDS);

            // Literal address bytes avoid an unbounded DNS lookup outside the connection deadline.
            socket.connect(new InetSocketAddress(InetAddress.getByAddress(address), port), connectTimeoutMs);
            socket.setTcpNoDelay(true);
            OutputStream stream = socket.getOutputStream();
            if (timedOut.get() || closed.get()) throw new IOException("Conexión cerrada.");
            // Even the first write may send only part of the payload before failing.
            writeStarted = true;
            stream.write(payload);
            stream.flush();
            if (timedOut.get()) throw new IOException("Tiempo de envío agotado.");
            socket.close();
            return payload.length;
        } catch (IOException | RuntimeException error) {
            throw new PrintFailure(writeStarted, error);
        } finally {
            if (deadline != null) deadline.cancel(false);
            if (socket != null) {
                active.remove(socket);
                closeSocket(socket);
            }
        }
    }

    /** Strict padded Base64, implemented without APIs added after Android 7 / API 24. */
    public static byte[] decodePayload(String encoded) {
        if (encoded == null || encoded.isEmpty() || encoded.length() % 4 != 0
            || encoded.length() > ((MAX_PAYLOAD_BYTES + 2) / 3) * 4)
            throw new IllegalArgumentException("El documento de impresión no es válido.");
        int padding = encoded.endsWith("==") ? 2 : encoded.endsWith("=") ? 1 : 0;
        int length = encoded.length() / 4 * 3 - padding;
        if (length < 1 || length > MAX_PAYLOAD_BYTES)
            throw new IllegalArgumentException("El documento está vacío o supera el límite de 256 KiB.");
        for (int i = 0; i < encoded.length() - padding; i++) {
            if (base64(encoded.charAt(i)) < 0)
                throw new IllegalArgumentException("El documento de impresión no es válido.");
        }
        if ((padding == 2 && (base64(encoded.charAt(encoded.length() - 3)) & 15) != 0)
            || (padding == 1 && (base64(encoded.charAt(encoded.length() - 2)) & 3) != 0))
            throw new IllegalArgumentException("El documento de impresión no es válido.");
        byte[] result = new byte[length];
        int offset = 0;
        for (int i = 0; i < encoded.length(); i += 4) {
            int a = base64(encoded.charAt(i));
            int b = base64(encoded.charAt(i + 1));
            int c = encoded.charAt(i + 2) == '=' ? 0 : base64(encoded.charAt(i + 2));
            int d = encoded.charAt(i + 3) == '=' ? 0 : base64(encoded.charAt(i + 3));
            int value = (a << 18) | (b << 12) | (c << 6) | d;
            if (offset < length) result[offset++] = (byte) (value >> 16);
            if (offset < length) result[offset++] = (byte) (value >> 8);
            if (offset < length) result[offset++] = (byte) value;
        }
        return result;
    }

    private static int base64(char value) {
        if (value >= 'A' && value <= 'Z') return value - 'A';
        if (value >= 'a' && value <= 'z') return value - 'a' + 26;
        if (value >= '0' && value <= '9') return value - '0' + 52;
        if (value == '+') return 62;
        if (value == '/') return 63;
        return -1;
    }

    private static byte[] ipv4(String host) {
        if (host == null || host.length() > 15)
            throw new IllegalArgumentException("Escribe la dirección IP de la impresora, por ejemplo 192.168.1.50.");
        String[] parts = host.split("\\.", -1);
        if (parts.length != 4)
            throw new IllegalArgumentException("Escribe una dirección IPv4 de impresora válida.");
        byte[] address = new byte[4];
        for (int i = 0; i < 4; i++) {
            if (parts[i].isEmpty() || parts[i].length() > 3)
                throw new IllegalArgumentException("Escribe una dirección IPv4 de impresora válida.");
            int octet = 0;
            for (int j = 0; j < parts[i].length(); j++) {
                char digit = parts[i].charAt(j);
                if (digit < '0' || digit > '9')
                    throw new IllegalArgumentException("Escribe una dirección IPv4 de impresora válida.");
                octet = octet * 10 + digit - '0';
            }
            if (octet > 255)
                throw new IllegalArgumentException("Escribe una dirección IPv4 de impresora válida.");
            address[i] = (byte) octet;
        }
        return address;
    }

    private static void closeSocket(Socket socket) {
        try { socket.close(); } catch (IOException ignored) { /* Preserve the original transport outcome. */ }
    }

    @Override
    public void close() {
        closed.set(true);
        for (Socket socket : active) closeSocket(socket);
        deadlines.shutdownNow();
    }
}
