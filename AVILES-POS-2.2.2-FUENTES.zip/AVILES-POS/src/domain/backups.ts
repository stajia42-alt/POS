import type { Database, SqlDriver, SqlValue } from '../db/database';
import { Database as LocalDatabase } from '../db/database';
import { migrate, SCHEMA_VERSION } from '../db/migrations';
import { WasmDriver } from '../db/wasm-driver';
import type { AccessControl } from './access';

type Tables = Record<string, { columns: string[]; rows: SqlValue[][] }>;
export interface BackupFile {
  manifest: {
    format_version: 1;
    application_id: 'mx.aviles.pos';
    app_version: string;
    schema_version: number;
    created_at: string;
    payload_bytes: number;
    sha256: string;
    counts: Record<string, number>;
  };
  payload: Tables;
}
const encode = (value: unknown) => new TextEncoder().encode(JSON.stringify(value));
async function sha(value: unknown) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', encode(value)))]
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}
const identifier = (s: string) => {
  if (!/^[a-z_][a-z_0-9]*$/i.test(s)) throw new Error('Identificador de respaldo no válido.');
  return `"${s}"`;
};
async function tableNames(sql: SqlDriver) {
  return (
    await sql.query<{ name: string }>(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",
    )
  ).map((r) => r.name);
}
async function dump(sql: SqlDriver): Promise<Tables> {
  const payload: Tables = {};
  for (const name of await tableNames(sql)) {
    const columns = (
      await sql.query<{ name: string }>(`PRAGMA table_info(${identifier(name)})`)
    ).map((r) => r.name);
    const rows = await sql.query<Record<string, SqlValue>>(
      `SELECT * FROM ${identifier(name)} ORDER BY rowid`,
    );
    payload[name] = { columns, rows: rows.map((r) => columns.map((c) => r[c])) };
  }
  return payload;
}
async function check(sql: SqlDriver) {
  const result = await sql.query<{ integrity_check: string }>('PRAGMA integrity_check');
  if (
    result.length !== 1 ||
    result[0].integrity_check !== 'ok' ||
    (await sql.query('PRAGMA foreign_key_check')).length
  )
    throw new Error('La integridad o las referencias SQLite no son válidas.');
}
async function replace(sql: SqlDriver, tables: Tables) {
  await sql.run('PRAGMA defer_foreign_keys = ON');
  for (const name of await tableNames(sql)) await sql.run(`DELETE FROM ${identifier(name)}`);
  for (const [name, data] of Object.entries(tables)) {
    const statement = `INSERT INTO ${identifier(name)}(${data.columns.map(identifier).join(',')}) VALUES(${data.columns.map(() => '?').join(',')})`;
    for (const row of data.rows) await sql.run(statement, row);
  }
  await check(sql);
}
export class Backups {
  constructor(
    private db: Database,
    private access: AccessControl,
  ) {}
  private async administrator(sql: SqlDriver) {
    const actor = await this.access.require(sql, 'settings');
    if (actor.role !== 'admin')
      throw new Error('Solo un administrador puede respaldar o restaurar la base.');
    return actor;
  }
  async create(): Promise<BackupFile> {
    // BEGIN IMMEDIATE + the shared queue supplies one consistent SQLite snapshot,
    // including committed WAL pages. Never copy the live .db file without its WAL.
    return this.db.transaction(async (sql) => {
      await this.administrator(sql);
      await check(sql);
      const payload = await dump(sql);
      return {
        manifest: {
          format_version: 1,
          application_id: 'mx.aviles.pos',
          app_version: '2.2.2',
          schema_version: SCHEMA_VERSION,
          created_at: new Date().toISOString(),
          payload_bytes: encode(payload).length,
          sha256: await sha(payload),
          counts: Object.fromEntries(Object.entries(payload).map(([k, v]) => [k, v.rows.length])),
        },
        payload,
      };
    });
  }
  async inspect(text: string): Promise<BackupFile> {
    if (text.length > 100_000_000) throw new Error('El respaldo supera el límite de 100 MB.');
    let file: BackupFile;
    try {
      file = JSON.parse(text) as BackupFile;
    } catch {
      throw new Error('El archivo no es un respaldo JSON válido.');
    }
    const m = file?.manifest;
    if (
      !m ||
      typeof m.app_version !== 'string' ||
      !/^\d+\.\d+\.\d+$/.test(m.app_version) ||
      m.format_version !== 1 ||
      m.application_id !== 'mx.aviles.pos' ||
      !Number.isInteger(m.schema_version) ||
      m.schema_version < 4 ||
      m.schema_version > SCHEMA_VERSION ||
      !Number.isFinite(Date.parse(m.created_at))
    )
      throw new Error('Formato, aplicación o versión de respaldo incompatible.');
    if (
      !file.payload ||
      encode(file.payload).length !== m.payload_bytes ||
      (await sha(file.payload)) !== m.sha256
    )
      throw new Error('La verificación SHA-256 falló. No se modificó la base.');
    const [{ default: init }, { default: wasm }] = await Promise.all([
      import('sql.js'),
      import('sql.js/dist/sql-wasm.wasm?url'),
    ]);
    const sqlite = await init({
      locateFile: typeof window === 'undefined' ? undefined : () => wasm,
    });
    const driver = new WasmDriver(sqlite, {
      async load() {
        return undefined;
      },
      async save() {},
    });
    const scratch = new LocalDatabase(driver);
    try {
      await migrate(scratch, m.schema_version);
      const schema = await scratch.read(dump);
      if (
        JSON.stringify(Object.keys(schema).sort()) !==
        JSON.stringify(Object.keys(file.payload).sort())
      )
        throw new Error('El respaldo no contiene todas las tablas esperadas.');
      for (const [name, data] of Object.entries(file.payload)) {
        const columnTypes = await scratch.read((sql) =>
          sql.query<{ name: string; type: string }>(`PRAGMA table_info(${identifier(name)})`),
        );
        if (
          !data ||
          !Array.isArray(data.rows) ||
          !Array.isArray(data.columns) ||
          new Set(data.columns).size !== data.columns.length ||
          JSON.stringify([...schema[name].columns].sort()) !==
            JSON.stringify([...data.columns].sort())
        )
          throw new Error('Estructura de respaldo no válida.');
        if (
          m.counts?.[name] !== data.rows.length ||
          data.rows.some(
            (r) =>
              !Array.isArray(r) ||
              r.length !== data.columns.length ||
              r.some(
                (v) =>
                  v !== null &&
                  typeof v !== 'string' &&
                  !(typeof v === 'number' && Number.isSafeInteger(v)),
              ),
          )
        )
          throw new Error('Filas o conteos no válidos.');
        for (const row of data.rows)
          for (let i = 0; i < data.columns.length; i++) {
            const v = row[i];
            const type = columnTypes.find((c) => c.name === data.columns[i])!.type;
            if (v !== null && (type === 'INTEGER' ? typeof v !== 'number' : typeof v !== 'string'))
              throw new Error('Tipo de dato no válido dentro del respaldo.');
          }
      }
      await scratch.transaction((sql) => replace(sql, file.payload));
      await migrate(scratch);
      await scratch.read(async (sql) => {
        const [business] = await sql.query<{ value: string }>(
          "SELECT value FROM settings WHERE key='business'",
        );
        const b = JSON.parse(business?.value || 'null');
        if (
          !b ||
          typeof b.name !== 'string' ||
          !Number.isInteger(b.taxBps) ||
          b.taxBps < 0 ||
          b.taxBps > 10000
        )
          throw new Error('Configuración del negocio incompleta.');
        const [active] = await sql.query<{ value: string }>(
          "SELECT value FROM settings WHERE key='activeSale'",
        );
        if (!active || !(await sql.query('SELECT id FROM sales WHERE id=?', [active.value])).length)
          throw new Error('El ticket activo del respaldo no está disponible.');
        await check(sql);
      });
      return file;
    } finally {
      driver.close();
    }
  }
  async restore(text: string, confirmation: string, safetyDigest: string) {
    if (confirmation !== 'RESTAURAR')
      throw new Error(
        'Confirma escribiendo RESTAURAR después de exportar la copia de seguridad actual.',
      );
    const file = await this.inspect(text);
    // Validate/migrate in isolation before touching any live data.
    const [{ default: init }, { default: wasm }] = await Promise.all([
      import('sql.js'),
      import('sql.js/dist/sql-wasm.wasm?url'),
    ]);
    const driver = new WasmDriver(
      await init({ locateFile: typeof window === 'undefined' ? undefined : () => wasm }),
      {
        async load() {
          return undefined;
        },
        async save() {},
      },
    );
    const scratch = new LocalDatabase(driver);
    let tables: Tables;
    try {
      await migrate(scratch, file.manifest.schema_version);
      await scratch.transaction((sql) => replace(sql, file.payload));
      await migrate(scratch);
      tables = await scratch.read(dump);
    } finally {
      driver.close();
    }
    await this.db.transaction(async (sql) => {
      const actor = await this.administrator(sql);
      if ((await sql.query("SELECT id FROM print_jobs WHERE status='sending' LIMIT 1")).length)
        throw new Error('Espera a que termine el envío a las impresoras antes de restaurar.');
      if (!safetyDigest || (await sha(await dump(sql))) !== safetyDigest)
        throw new Error(
          'La base cambió. Exporta una nueva copia de recuperación antes de restaurar.',
        );
      await replace(sql, tables);
      await sql.run(
        "UPDATE print_jobs SET status='unknown',error='Respaldo restaurado: revisa el papel antes de repetir.' WHERE status IN ('pending','sending','failed')",
      );
      // Restored actors may differ; audit as a system event without a dangling foreign key.
      await sql.run(
        'INSERT INTO administrative_actions(id,actor_id,actor_name,action,target,details,created_at) VALUES(?,NULL,?,?,?,?,?)',
        [
          crypto.randomUUID(),
          actor.name,
          'backup.restore',
          file.manifest.sha256,
          JSON.stringify({ sourceVersion: file.manifest.schema_version }),
          new Date().toISOString(),
        ],
      );
      await check(sql);
    });
    this.access.lock();
  }
  integrity() {
    return this.db.read(async (sql) => {
      await this.administrator(sql);
      await check(sql);
      return 'Integridad SQLite y referencias correctas';
    });
  }
}
