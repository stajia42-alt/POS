import { currencyMoney, integer, money } from './money';
import { PAYMENT_LABELS } from './payments';
import type { Receipt } from './types';

export interface PrintDocument {
  title: string;
  columns: 32 | 48;
  lines: string[];
}

export interface KitchenPrintInput {
  orderNumber: number;
  tableName: string;
  waiterName: string;
  areaName: string;
  createdAt: string;
  note: string;
  /** Header-only change; never repeats food quantities already sent to the kitchen. */
  updateOnly?: boolean;
  lines: { name: string; quantity: number; note: string; kind?: 'add' | 'cancel' }[];
}

// A document contains text, never transport commands. Flatten embedded line breaks,
// printer control bytes and directional overrides before wrapping every text field.
function clean(value: string) {
  return String(value ?? '')
    .normalize('NFC')
    .replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, ' ')
    .replace(/\s+/gu, ' ')
    .trim();
}
const length = (value: string) => Array.from(value).length;

function wrap(value: string, columns: number) {
  let remaining = Array.from(clean(value));
  const result: string[] = [];
  while (remaining.length > columns) {
    const boundary = remaining.slice(0, columns + 1).lastIndexOf(' ');
    const take = boundary > 0 ? boundary : columns;
    result.push(remaining.slice(0, take).join(''));
    remaining = remaining.slice(take);
    while (remaining[0] === ' ') remaining.shift();
  }
  if (remaining.length) result.push(remaining.join(''));
  return result;
}

function document(columns: 32 | 48) {
  if (columns !== 32 && columns !== 48) throw new Error('Ancho de impresión no válido.');
  const lines: string[] = [];
  const put = (value: string) => lines.push(...wrap(value, columns));
  const center = (value: string) => {
    for (const line of wrap(value, columns))
      lines.push(' '.repeat(Math.floor((columns - length(line)) / 2)) + line);
  };
  const pair = (label: string, value: string) => {
    const left = clean(label);
    const right = clean(value);
    if (length(left) + length(right) + 1 <= columns) {
      lines.push(left + ' '.repeat(columns - length(left) - length(right)) + right);
    } else {
      put(left);
      for (const line of wrap(right, columns))
        lines.push(' '.repeat(columns - length(line)) + line);
    }
  };
  return { lines, put, center, pair, separator: () => lines.push('-'.repeat(columns)) };
}

function printedDate(value: string) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) throw new Error('Fecha de impresión no válida.');
  // Use the device's local clock, as the POS does on screen; do not reinterpret
  // the stored instant as a different business date.
  return new Intl.DateTimeFormat('es-MX', {
    dateStyle: 'short',
    timeStyle: 'short',
  }).format(date);
}

function orderLabel(number: number) {
  integer(number, 1, Number.MAX_SAFE_INTEGER);
  return `#${String(number).padStart(4, '0')}`;
}

function percentage(bps: number) {
  integer(bps, 0, 10000);
  return (bps / 100).toFixed(2).replace(/\.?0+$/, '');
}

/** A paid receipt's snapshots are the authority; current catalogue/settings do not recalculate it. */
export function receiptDocument(
  receipt: Receipt,
  footer: string,
  columns: 32 | 48,
  duplicate = false,
): PrintDocument {
  const { sale } = receipt;
  if (sale.status !== 'paid' || !sale.paid_at || !receipt.payments.length)
    throw new Error('El ticket debe estar cobrado para imprimir el recibo.');
  if (!receipt.lines.length) throw new Error('El ticket no contiene artículos.');
  const number = orderLabel(sale.number);
  const doc = document(columns);
  doc.center(sale.business_name);
  if (sale.business_address) doc.center(sale.business_address);
  if (sale.business_phone) doc.center(`Tel: ${sale.business_phone}`);
  doc.separator();
  doc.center(`TICKET ${number}`);
  if (duplicate) doc.center('COPIA');
  doc.put(printedDate(sale.paid_at));
  if (sale.table_name) doc.put(`Mesa: ${sale.table_name}`);
  if (sale.waiter_name) doc.put(`Mesero: ${sale.waiter_name}`);
  if (sale.employee_name) doc.put(`Cobró: ${sale.employee_name}`);
  if (sale.customer_name) doc.put(`Cliente: ${sale.customer_name}`);
  doc.separator();
  for (const line of receipt.lines) {
    integer(line.quantity, 1, 9999);
    integer(line.unit_price);
    const amount = integer(line.quantity * line.unit_price);
    doc.put(`${line.quantity} x ${line.name}`);
    doc.pair(`${money(line.unit_price)} c/u`, money(amount));
    if (line.note) doc.put(`Nota: ${line.note}`);
  }
  doc.separator();
  doc.pair('Subtotal', money(integer(sale.subtotal)));
  if (sale.discount > 0)
    doc.pair(`Descuento (${percentage(sale.discount_bps)}%)`, `-${money(integer(sale.discount))}`);
  doc.pair(`Impuesto (${percentage(sale.tax_bps)}%)`, money(integer(sale.tax)));
  doc.pair('TOTAL', money(integer(sale.total)));
  doc.separator();
  for (const [index, payment] of receipt.payments.entries()) {
    doc.put(`Pago ${index + 1}: ${PAYMENT_LABELS[payment.method] || 'Pago registrado'}`);
    doc.pair('Aplicado', money(integer(payment.amount)));
    if (payment.method === 'cash') {
      const currency = payment.currency || 'MXN';
      doc.pair(
        'Recibido',
        currencyMoney(integer(payment.original_tendered ?? payment.tendered), currency),
      );
      if (currency === 'USD' && payment.exchange_rate) {
        integer(payment.exchange_rate, 1, 99999999);
        doc.put(`1 USD = ${(payment.exchange_rate / 10000).toFixed(4)} MXN`);
      }
      doc.pair(
        'Cambio MXN',
        currencyMoney(integer(payment.change_mxn ?? payment.change_amount), 'MXN'),
      );
      if (payment.change_usd > 0)
        doc.pair('Cambio USD', currencyMoney(integer(payment.change_usd), 'USD'));
    }
    if (payment.reference) doc.put(`Referencia: ${payment.reference}`);
  }
  if (sale.note) {
    doc.separator();
    doc.put(`Nota de cuenta: ${sale.note}`);
  }
  if (clean(footer)) {
    doc.separator();
    doc.center(footer);
  }
  return { title: `Ticket ${number}${duplicate ? ' - Copia' : ''}`, columns, lines: doc.lines };
}

/** Kitchen deltas use positive quantities with an explicit add/cancel operation, never prices. */
export function kitchenDocument(
  input: KitchenPrintInput,
  columns: 32 | 48,
  duplicate = false,
): PrintDocument {
  const updateOnly = input.updateOnly === true;
  if (!input.lines.length && !updateOnly)
    throw new Error('No hay artículos para enviar en la comanda.');
  if (input.lines.length && updateOnly)
    throw new Error('Una actualización de cuenta no debe repetir artículos.');
  const number = orderLabel(input.orderNumber);
  const doc = document(columns);
  doc.center('COMANDA');
  if (updateOnly) {
    doc.center('ACTUALIZACION DE CUENTA');
    doc.center('NO REPETIR PREPARACION');
  }
  if (input.areaName) doc.center(input.areaName.toLocaleUpperCase('es-MX'));
  if (duplicate) doc.center('COPIA');
  doc.separator();
  doc.put(`Cuenta ${number}`);
  doc.put(printedDate(input.createdAt));
  doc.put(input.tableName ? `Mesa: ${input.tableName}` : 'Venta rápida');
  if (input.waiterName) doc.put(`Mesero: ${input.waiterName}`);
  if (input.note) doc.put(`Nota de cuenta: ${input.note}`);
  doc.separator();
  for (const line of input.lines) {
    integer(line.quantity, 1, 9999);
    if (line.kind !== undefined && line.kind !== 'add' && line.kind !== 'cancel')
      throw new Error('Operación de comanda no válida.');
    doc.put(`${line.kind === 'cancel' ? 'CANCELAR' : 'AGREGAR'} ${line.quantity} x ${line.name}`);
    if (line.note) doc.put(`Nota: ${line.note}`);
    doc.separator();
  }
  return {
    title: clean(
      `Comanda ${number}${input.areaName ? ` - ${input.areaName}` : ''}${updateOnly ? ' - Actualización' : ''}${duplicate ? ' - Copia' : ''}`,
    ),
    columns,
    lines: doc.lines,
  };
}

// IBM CP850 positions 128–255, corresponding to ESC t 2 on the selected
// ESC/POS profile. Keep this explicit: the APK needs no platform codec/library.
const CP850 =
  '\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8\u00a3\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u00ae\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u00c1\u00c2\u00c0\u00a9\u2563\u2551\u2557\u255d\u00a2\u00a5\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u00e3\u00c3\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u00a4\u00f0\u00d0\u00ca\u00cb\u00c8\u0131\u00cd\u00ce\u00cf\u2518\u250c\u2588\u2584\u00a6\u00cc\u2580\u00d3\u00df\u00d4\u00d2\u00f5\u00d5\u00b5\u00fe\u00de\u00da\u00db\u00d9\u00fd\u00dd\u00af\u00b4\u00ad\u00b1\u2017\u00be\u00b6\u00a7\u00f7\u00b8\u00b0\u00a8\u00b7\u00b9\u00b3\u00b2\u25a0\u00a0';
const cp850Bytes = new Map(Array.from(CP850).map((character, index) => [character, index + 128]));
const punctuation: Record<string, string> = {
  '‘': "'",
  '’': "'",
  '“': '"',
  '”': '"',
  '–': '-',
  '—': '-',
  '…': '.',
};

function encodedCharacter(character: string): number {
  const point = character.codePointAt(0)!;
  if (point >= 0x20 && point <= 0x7e) return point;
  const mapped = cp850Bytes.get(character);
  if (mapped !== undefined) return mapped;
  const replacement = punctuation[character] || character.normalize('NFKD').replace(/\p{M}/gu, '');
  // One output byte per unsupported code point preserves the document's column
  // bounds. Other scripts/symbols use '?' rather than sending printer controls.
  return /^[ -~]$/.test(replacement) ? replacement.charCodeAt(0) : 0x3f;
}

/** Bytes for an explicitly selected ESC/POS CP850 profile, not a printer capability claim. */
export function encodeEscPos(document: PrintDocument, cut = true): Uint8Array {
  if (document.columns !== 32 && document.columns !== 48)
    throw new Error('Ancho de impresión no válido.');
  if (!document.lines.length || !document.lines.some((line) => clean(line)))
    throw new Error('No hay texto para imprimir.');
  // Reset, select CP850, font A and left alignment. Padding in document lines
  // supplies its centering/columns and must survive encoding unchanged.
  const bytes = [0x1b, 0x40, 0x1b, 0x74, 0x02, 0x1b, 0x4d, 0x00, 0x1b, 0x61, 0x00];
  for (const line of document.lines) {
    const safe = line
      .normalize('NFC')
      .replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, ' ');
    if (length(safe) > document.columns)
      throw new Error('El documento excede el ancho de impresión configurado.');
    for (const character of safe) bytes.push(encodedCharacter(character));
    bytes.push(0x0a);
  }
  bytes.push(0x0a, 0x0a, 0x0a);
  if (cut) bytes.push(0x1d, 0x56, 0x42, 0x00);
  return Uint8Array.from(bytes);
}
