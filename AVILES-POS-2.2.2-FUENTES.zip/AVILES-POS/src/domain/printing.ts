import type { Database, SqlDriver } from '../db/database';
import type { AccessControl } from './access';
import type { Actor } from './access-types';
import type { Category, Payment, Product, Receipt, Sale } from './types';
import { audit, newId, textRequired, timestamp } from './shared';
import { business, linesFor, saleById } from './sales';
import { kitchenDocument, receiptDocument, type PrintDocument } from './print-documents';

export interface Printer {
  id: string;
  name: string;
  host: string;
  port: number;
  width: 80 | 58;
  cut: number;
  receipt: number;
  kitchen: number;
  active: number;
  all_products?: number;
}
export type PrintStatus = 'pending' | 'sending' | 'sent' | 'failed' | 'unknown' | 'superseded';
export interface PrintJob {
  id: string;
  kind: 'receipt' | 'kitchen' | 'test';
  saleId: string | null;
  printerName: string;
  status: PrintStatus;
  createdAt: string;
  error: string;
  copyOf: string | null;
  payload: PrintDocument;
}
export interface DispatchJob extends PrintJob {
  attemptId: string;
  printer: Printer;
}
interface JobRow {
  id: string;
  kind: PrintJob['kind'];
  sale_id: string | null;
  printer_id: string;
  printer_name: string;
  printer_json: string;
  payload: string;
  status: PrintStatus;
  created_at: string;
  error: string;
  copy_of: string | null;
  attempt_id: string | null;
  queue_order: number;
}
interface KitchenState {
  line_id: string;
  printer_id: string;
  sale_id: string;
  product_id: string;
  name: string;
  note: string;
  quantity: number;
  sale_note: string;
  table_name: string;
  waiter_name: string;
  printer_json: string;
}
type KitchenChange = { name: string; quantity: number; note: string; kind: 'add' | 'cancel' };
const columns = (printer: Printer) => (printer.width === 58 ? 32 : 48);
const flag = (value: number) => {
  if (value !== 0 && value !== 1) throw new Error('Selecciona las opciones de la impresora.');
  return value;
};
function view(row: JobRow): PrintJob {
  return {
    id: row.id,
    kind: row.kind,
    saleId: row.sale_id,
    printerName: row.printer_name,
    status: row.status,
    createdAt: row.created_at,
    error: row.error,
    copyOf: row.copy_of,
    payload: JSON.parse(row.payload) as PrintDocument,
  };
}
function originalPrinter(row: Pick<JobRow, 'printer_json'>): Printer {
  return JSON.parse(row.printer_json) as Printer;
}
async function insertJob(
  sql: SqlDriver,
  actor: Actor,
  kind: PrintJob['kind'],
  saleId: string | null,
  printer: Printer,
  payload: PrintDocument,
  dedupeKey: string | null = null,
  copyOf: string | null = null,
  queueOrder?: number,
) {
  const id = newId(),
    date = timestamp();
  const order =
    queueOrder ??
    (
      await sql.query<{ n: number }>('SELECT COALESCE(MAX(queue_order),0)+1 AS n FROM print_jobs')
    )[0].n;
  await sql.run(
    `INSERT INTO print_jobs(id,kind,sale_id,printer_id,printer_name,printer_json,payload,status,queue_order,dedupe_key,copy_of,created_at,updated_at,actor_id,actor_name)
     VALUES(?,?,?,?,?,?,?,'pending',?,?,?,?,?,?,?)`,
    [
      id,
      kind,
      saleId,
      printer.id,
      printer.name,
      JSON.stringify(printer),
      JSON.stringify(payload),
      order,
      dedupeKey,
      copyOf,
      date,
      date,
      actor.id,
      actor.name,
    ],
  );
  return id;
}

/** For an already-authorized sale transaction. No socket is ever opened here. */
export async function queueReceiptSql(
  sql: SqlDriver,
  saleId: string,
  actor: Actor,
  duplicate = false,
  options: { optional?: boolean } = {},
): Promise<string | null> {
  const sale = await saleById(sql, saleId);
  if (sale.status !== 'paid') throw new Error('El ticket todavía no está pagado.');
  const [old] = await sql.query<JobRow>('SELECT * FROM print_jobs WHERE dedupe_key=?', [
    `receipt:${saleId}`,
  ]);
  if (!duplicate && old) return old.id;
  const [printer] = await sql.query<Printer>('SELECT * FROM printers WHERE receipt=1 AND active=1');
  if (!printer) {
    if (options.optional) return null;
    throw new Error('Configura una impresora activa para tickets.');
  }
  if (duplicate && !actor.permissions.includes('reprint'))
    throw new Error('Sin permiso para reimprimir tickets.');
  const receipt: Receipt = {
    sale,
    lines: await linesFor(sql, saleId),
    payments: await sql.query<Payment>('SELECT * FROM payments WHERE sale_id=? ORDER BY position', [
      saleId,
    ]),
    payment: undefined as unknown as Payment,
  };
  if (!receipt.payments.length) throw new Error('El ticket no tiene pagos registrados.');
  receipt.payment = receipt.payments[0];
  const settings = await business(sql);
  const id = await insertJob(
    sql,
    actor,
    'receipt',
    saleId,
    printer,
    receiptDocument(receipt, settings.receiptFooter, columns(printer), duplicate),
    duplicate ? null : `receipt:${saleId}`,
    duplicate ? (old?.id ?? null) : null,
  );
  await audit(sql, actor, duplicate ? 'print.receipt_copy' : 'print.receipt', id, { saleId });
  return id;
}

/** Append only changes since the last durable kitchen submission. */
export async function queueKitchenSql(
  sql: SqlDriver,
  saleId: string,
  actor: Actor,
): Promise<string[]> {
  const sale = (await saleById(sql, saleId)) as Sale & { merged_into?: string | null };
  if (sale.merged_into) return [];
  const current = sale.status === 'cancelled' ? [] : await linesFor(sql, saleId);
  const previous = await sql.query<KitchenState>(
    'SELECT * FROM kitchen_line_state WHERE sale_id=?',
    [saleId],
  );
  const printers = await sql.query<Printer>(
    'SELECT * FROM printers WHERE kitchen=1 AND active=1 ORDER BY rowid',
  );
  const routes = await sql.query<{ printer_id: string; category_id: string }>(
    'SELECT * FROM printer_categories',
  );
  const categories = new Map(
    (
      await sql.query<Pick<Product, 'id' | 'category_id'>>('SELECT id,category_id FROM products')
    ).map((p) => [p.id, p.category_id]),
  );
  const grouped = new Map<string, { printer: Printer; changes: KitchenChange[] }>();
  function append(
    printer: Printer,
    name: string,
    quantity: number,
    note: string,
    kind: KitchenChange['kind'],
  ) {
    if (!quantity) return;
    if (!grouped.has(printer.id)) grouped.set(printer.id, { printer, changes: [] });
    grouped.get(printer.id)!.changes.push({ name, quantity, note, kind });
  }
  for (const line of current) {
    // Once submitted, its kitchen remains stable even if category routing is edited later.
    const known = previous.filter((p) => p.line_id === line.id);
    const destinations = known.length
      ? known.map((p) => JSON.parse(p.printer_json) as Printer)
      : printers.filter((p) => {
          const selected = routes.filter((r) => r.printer_id === p.id);
          return (
            p.all_products === 1 ||
            selected.some((r) => r.category_id === categories.get(line.product_id))
          );
        });
    for (const printer of destinations) {
      const old = known.find((p) => p.printer_id === printer.id);
      if (
        old &&
        old.quantity > 0 &&
        (old.sale_note !== sale.note ||
          old.table_name !== sale.table_name ||
          old.waiter_name !== sale.waiter_name)
      ) {
        if (!grouped.has(printer.id)) grouped.set(printer.id, { printer, changes: [] });
      }
      if (old && (old.note !== line.note || old.name !== line.name)) {
        append(printer, old.name, old.quantity, old.note, 'cancel');
        append(printer, line.name, line.quantity, line.note, 'add');
      } else {
        const delta = line.quantity - (old?.quantity ?? 0);
        append(printer, line.name, Math.abs(delta), line.note, delta < 0 ? 'cancel' : 'add');
      }
      await sql.run(
        `INSERT INTO kitchen_line_state(line_id,printer_id,sale_id,product_id,name,note,quantity,sale_note,table_name,waiter_name,printer_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(line_id,printer_id) DO UPDATE SET sale_id=excluded.sale_id,name=excluded.name,note=excluded.note,quantity=excluded.quantity,sale_note=excluded.sale_note,table_name=excluded.table_name,waiter_name=excluded.waiter_name`,
        [
          line.id,
          printer.id,
          saleId,
          line.product_id,
          line.name,
          line.note,
          line.quantity,
          sale.note,
          sale.table_name,
          sale.waiter_name,
          JSON.stringify(printer),
        ],
      );
    }
  }
  for (const old of previous.filter((p) => !current.some((l) => l.id === p.line_id))) {
    append(JSON.parse(old.printer_json) as Printer, old.name, old.quantity, old.note, 'cancel');
    await sql.run('UPDATE kitchen_line_state SET quantity=0 WHERE line_id=? AND printer_id=?', [
      old.line_id,
      old.printer_id,
    ]);
  }
  const ids: string[] = [];
  for (const { printer, changes } of grouped.values()) {
    const payload = kitchenDocument(
      {
        orderNumber: sale.number,
        tableName: sale.table_name,
        waiterName: sale.waiter_name || actor.name,
        areaName: printer.name,
        createdAt: timestamp(),
        note: sale.note,
        lines: changes,
        updateOnly: !changes.length,
      },
      columns(printer),
    );
    ids.push(await insertJob(sql, actor, 'kitchen', saleId, printer, payload));
  }
  if (ids.length) await audit(sql, actor, 'print.kitchen', saleId, { jobs: ids });
  return ids;
}

/** Lines retain their IDs during a merge, so transfer their submission history too. */
export async function moveKitchenSnapshots(
  sql: SqlDriver,
  sourceSaleId: string,
  targetSaleId: string,
) {
  await sql.run('UPDATE kitchen_line_state SET sale_id=? WHERE sale_id=?', [
    targetSaleId,
    sourceSaleId,
  ]);
}

async function setCategoriesSql(sql: SqlDriver, printerId: string, categoryIds: string[]) {
  if (
    !Array.isArray(categoryIds) ||
    categoryIds.length > 500 ||
    new Set(categoryIds).size !== categoryIds.length
  )
    throw new Error('Selecciona categorías sin duplicados.');
  if (!(await sql.query('SELECT id FROM printers WHERE id=?', [printerId])).length)
    throw new Error('Impresora no disponible.');
  for (const id of categoryIds)
    if (!(await sql.query('SELECT id FROM categories WHERE id=?', [id])).length)
      throw new Error('Categoría no disponible.');
  await sql.run('UPDATE printers SET all_products=? WHERE id=?', [
    categoryIds.length ? 0 : 1,
    printerId,
  ]);
  await sql.run('DELETE FROM printer_categories WHERE printer_id=?', [printerId]);
  for (const id of categoryIds)
    await sql.run('INSERT INTO printer_categories(printer_id,category_id) VALUES(?,?)', [
      printerId,
      id,
    ]);
}

export class Printing {
  constructor(
    private db: Database,
    private access: AccessControl,
  ) {}
  private async operator(sql: SqlDriver) {
    const actor = await this.access.require(sql);
    if (!actor.permissions.some((p) => ['sell', 'settings', 'reprint'].includes(p)))
      throw new Error('Sin permiso para consultar impresoras y trabajos.');
    return actor;
  }
  status() {
    return this.db.read(async (sql) => {
      await this.operator(sql);
      const [row] = await sql.query<{ attention: number; kitchen: number }>(
        "SELECT EXISTS(SELECT 1 FROM print_jobs WHERE status IN ('failed','unknown')) AS attention, EXISTS(SELECT 1 FROM printers WHERE active=1 AND kitchen=1) AS kitchen",
      );
      return { needsAttention: !!row.attention, kitchenEnabled: !!row.kitchen };
    });
  }
  snapshot() {
    return this.db.read(async (sql) => {
      await this.operator(sql);
      return {
        printers: await sql.query<Printer>('SELECT * FROM printers ORDER BY name'),
        categories: await sql.query<Category>('SELECT * FROM categories ORDER BY name'),
        routes: await sql.query<{ printer_id: string; category_id: string }>(
          'SELECT * FROM printer_categories',
        ),
        jobs: (
          await sql.query<JobRow>(
            "SELECT * FROM print_jobs WHERE status IN ('failed','unknown','sending') OR rowid IN (SELECT rowid FROM print_jobs ORDER BY rowid DESC LIMIT 100) ORDER BY rowid DESC",
          )
        ).map(view),
      };
    });
  }
  savePrinter(
    input: Omit<Printer, 'id' | 'cut'> & { id?: string; cut?: number },
    categoryIds?: string[],
  ) {
    const name = textRequired(input.name, 'el nombre de la impresora', 80);
    const rawHost = input.host.trim();
    const host = rawHost
      .split('.')
      .map((p) => String(Number(p)))
      .join('.');
    if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(rawHost) || host.split('.').some((p) => Number(p) > 255))
      throw new Error(
        'Escribe la IP de la impresora, por ejemplo 192.168.1.50, sin http ni barras.',
      );
    if (!Number.isInteger(input.port) || input.port < 1 || input.port > 65535)
      throw new Error('El puerto debe estar entre 1 y 65535.');
    if (input.width !== 80 && input.width !== 58)
      throw new Error('Selecciona papel de 58 u 80 mm.');
    for (const value of [input.cut ?? 1, input.receipt, input.kitchen, input.active]) flag(value);
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'settings');
      const id = input.id || newId();
      if (input.id && !(await sql.query('SELECT id FROM printers WHERE id=?', [id])).length)
        throw new Error('La impresora ya no está disponible.');
      if (input.receipt && input.active)
        await sql.run('UPDATE printers SET receipt=0 WHERE id<>?', [id]);
      await sql.run(
        `INSERT INTO printers(id,name,host,port,width,cut,receipt,kitchen,active) VALUES(?,?,?,?,?,?,?,?,?)
         ON CONFLICT(id) DO UPDATE SET name=excluded.name,host=excluded.host,port=excluded.port,width=excluded.width,cut=excluded.cut,receipt=excluded.receipt,kitchen=excluded.kitchen,active=excluded.active`,
        [
          id,
          name,
          host,
          input.port,
          input.width,
          input.cut ?? 1,
          input.receipt,
          input.kitchen,
          input.active,
        ],
      );
      if (categoryIds !== undefined) await setCategoriesSql(sql, id, categoryIds);
      await audit(sql, actor, 'printer.save', id);
      return id;
    });
  }
  setCategories(printerId: string, categoryIds: string[]) {
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'settings');
      await setCategoriesSql(sql, printerId, categoryIds);
      await audit(sql, actor, 'printer.categories', printerId, { categoryIds });
    });
  }
  latestReceipt(saleId: string): Promise<PrintJob | null> {
    return this.db.read(async (sql) => {
      const actor = await this.operator(sql);
      const sale = await saleById(sql, saleId);
      if (!actor.permissions.includes('reports') && sale.employee_id !== actor.id)
        throw new Error('Sin permiso para imprimir esta venta.');
      const [row] = await sql.query<JobRow>(
        "SELECT * FROM print_jobs WHERE kind='receipt' AND sale_id=? AND status<>'superseded' ORDER BY rowid DESC LIMIT 1",
        [saleId],
      );
      return row ? view(row) : null;
    });
  }
  enqueueReceipt(saleId: string, duplicate = false) {
    return this.db.transaction(async (sql) => {
      const actor = await this.operator(sql);
      const sale = await saleById(sql, saleId);
      if (!actor.permissions.includes('reports') && sale.employee_id !== actor.id)
        throw new Error('Sin permiso para imprimir esta venta.');
      if (duplicate) await this.access.require(sql, 'reprint');
      return (await queueReceiptSql(sql, saleId, actor, duplicate))!;
    });
  }
  enqueueKitchen(saleId: string) {
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'sell');
      const [table] = await sql.query(
        'SELECT id FROM table_sessions WHERE sale_id=? AND closed_at IS NULL',
        [saleId],
      );
      if (table) await this.access.require(sql, 'tables');
      const sale = await saleById(sql, saleId);
      if (sale.status === 'paid' || sale.status === 'cancelled')
        throw new Error('La cuenta ya está cerrada.');
      return queueKitchenSql(sql, saleId, actor);
    });
  }
  enqueueTest(printerId: string) {
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'settings');
      const [printer] = await sql.query<Printer>('SELECT * FROM printers WHERE id=? AND active=1', [
        printerId,
      ]);
      if (!printer) throw new Error('Selecciona una impresora activa.');
      const b = await business(sql);
      const payload: PrintDocument = {
        title: 'Prueba AVILES POS',
        columns: columns(printer),
        lines: [
          'AVILES POS',
          'PRUEBA DE IMPRESION',
          'No es una venta ni una comanda',
          b.name,
          printer.name,
          `${printer.width} mm / ${columns(printer)} columnas`,
          'Español: ñ Ñ á é í ó ú ü ¿ ¡',
          timestamp(),
          'FIN DE PRUEBA',
        ],
      };
      payload.lines = payload.lines.flatMap((line) => {
        const chars = Array.from(
          line.normalize('NFC').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' '),
        );
        const result: string[] = [];
        for (let offset = 0; offset < chars.length; offset += payload.columns)
          result.push(chars.slice(offset, offset + payload.columns).join(''));
        return result;
      });
      return insertJob(sql, actor, 'test', null, printer, payload);
    });
  }
  claimNext(): Promise<DispatchJob | null> {
    return this.db.transaction(async (sql) => {
      await this.operator(sql);
      const [row] = await sql.query<JobRow>(
        `SELECT j.* FROM print_jobs j WHERE j.status='pending' AND NOT EXISTS(SELECT 1 FROM print_jobs s WHERE s.printer_id=j.printer_id AND (s.status='sending' OR (s.status IN ('pending','failed','unknown') AND (s.queue_order<j.queue_order OR (s.queue_order=j.queue_order AND s.rowid<j.rowid))))) ORDER BY j.queue_order,j.rowid LIMIT 1`,
      );
      if (!row) return null;
      const attemptId = newId();
      await sql.run(
        "UPDATE print_jobs SET status='sending',attempt_id=?,attempts=attempts+1,error='',updated_at=? WHERE id=?",
        [attemptId, timestamp(), row.id],
      );
      return { ...view({ ...row, status: 'sending' }), attemptId, printer: originalPrinter(row) };
    });
  }
  complete(jobId: string, attemptId: string) {
    return this.settle(jobId, attemptId, 'sent', '');
  }
  fail(jobId: string, attemptId: string, message: string, uncertain: boolean) {
    return this.settle(
      jobId,
      attemptId,
      uncertain ? 'unknown' : 'failed',
      String(message).slice(0, 500),
    );
  }
  private settle(
    jobId: string,
    attemptId: string,
    status: 'sent' | 'failed' | 'unknown',
    message: string,
  ) {
    return this.db.transaction(async (sql) => {
      const [row] = await sql.query<JobRow>(
        "SELECT * FROM print_jobs WHERE id=? AND attempt_id=? AND status='sending'",
        [jobId, attemptId],
      );
      if (!row) return false;
      await sql.run(
        'UPDATE print_jobs SET status=?,error=?,attempt_id=NULL,updated_at=? WHERE id=?',
        [status, message, timestamp(), jobId],
      );
      return true;
    });
  }
  recoverInterrupted() {
    return this.db.transaction(async (sql) => {
      const rows = await sql.query<{ id: string }>(
        "SELECT id FROM print_jobs WHERE status='sending'",
      );
      await sql.run(
        "UPDATE print_jobs SET status='unknown',attempt_id=NULL,error='La app se cerró durante el envío. Revisa el papel antes de solicitar una copia.',updated_at=? WHERE status='sending'",
        [timestamp()],
      );
      return rows.length;
    });
  }
  retry(jobId: string) {
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'reprint');
      const [job] = await sql.query<JobRow>('SELECT * FROM print_jobs WHERE id=?', [jobId]);
      if (!job) throw new Error('El trabajo ya no está disponible.');
      if (job.status === 'sending' || job.status === 'pending')
        throw new Error('El trabajo todavía está pendiente o enviándose.');
      if (job.status === 'superseded') {
        const [copy] = await sql.query<{ id: string }>(
          'SELECT id FROM print_jobs WHERE copy_of=? ORDER BY rowid DESC LIMIT 1',
          [jobId],
        );
        if (copy) return copy.id;
        throw new Error('Este envío fue sustituido. Revisa su copia.');
      }
      if (job.status === 'failed') {
        await sql.run(
          "UPDATE print_jobs SET status='pending',attempt_id=NULL,error='',updated_at=? WHERE id=?",
          [timestamp(), jobId],
        );
        await audit(sql, actor, 'print.retry_unsent', jobId);
        return jobId;
      }
      const payload = JSON.parse(job.payload) as PrintDocument;
      const duplicate = {
        ...payload,
        title: `COPIA · ${payload.title}`,
        lines: ['COPIA / REIMPRESION', ...payload.lines],
      };
      const id = await insertJob(
        sql,
        actor,
        job.kind,
        job.sale_id,
        originalPrinter(job),
        duplicate,
        null,
        jobId,
        job.status === 'unknown' ? job.queue_order : undefined,
      );
      if (job.status === 'unknown')
        await sql.run("UPDATE print_jobs SET status='superseded',updated_at=? WHERE id=?", [
          timestamp(),
          jobId,
        ]);
      await audit(sql, actor, 'print.retry_copy', id, {
        originalJobId: jobId,
        previousStatus: job.status,
      });
      return id;
    });
  }
  confirmReceived(jobId: string) {
    return this.db.transaction(async (sql) => {
      const actor = await this.access.require(sql, 'reprint');
      const [job] = await sql.query<JobRow>('SELECT * FROM print_jobs WHERE id=?', [jobId]);
      if (!job || !['unknown', 'failed'].includes(job.status))
        throw new Error('Solo puedes confirmar un envío fallido o sin confirmar.');
      await sql.run(
        "UPDATE print_jobs SET status='sent',attempt_id=NULL,error='Confirmado manualmente por el operador',updated_at=? WHERE id=?",
        [timestamp(), jobId],
      );
      await audit(sql, actor, 'print.confirm_received', jobId, { previousStatus: job.status });
    });
  }
}
