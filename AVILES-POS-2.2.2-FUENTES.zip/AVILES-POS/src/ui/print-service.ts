import { Capacitor, registerPlugin } from '@capacitor/core';
import type { Printing, DispatchJob } from '../domain/printing';
import { encodeEscPos } from '../domain/print-documents';

interface ThermalPlugin {
  send(options: { host: string; port: number; dataBase64: string }): Promise<{ bytesSent: number }>;
}
const native = registerPlugin<ThermalPlugin>('ThermalPrinter');
export type PrintSender = (job: DispatchJob, bytes: Uint8Array) => Promise<void>;
const listeners = new Set<() => void>();
export function printingChanged() {
  for (const listener of listeners) listener();
}
export function subscribePrinting(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
const nativeSend: PrintSender = async (job, bytes) => {
  // Chunked conversion avoids argument/stack limits for long tickets.
  let raw = '';
  for (let offset = 0; offset < bytes.length; offset += 8192) {
    raw += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
  }
  const result = await native.send({
    host: job.printer.host,
    port: job.printer.port,
    dataBase64: btoa(raw),
  });
  if (result.bytesSent !== bytes.length) {
    throw Object.assign(
      new Error(
        'La impresora recibió una cantidad de datos incompleta. Revisa el papel antes de repetir.',
      ),
      { code: 'PRINT_UNCERTAIN' },
    );
  }
};
const workers = new WeakMap<Printing, Promise<void>>();
const recovered = new WeakSet<Printing>();
export function processPrintQueue(
  printing: Printing,
  send: PrintSender = nativeSend,
  enabled = Capacitor.isNativePlatform(),
): Promise<void> {
  if (!enabled) return Promise.resolve();
  const current = workers.get(printing);
  if (current) return current;
  const worker = (async () => {
    if (!recovered.has(printing)) {
      await printing.recoverInterrupted();
      recovered.add(printing);
      printingChanged();
    }
    for (;;) {
      const job = await printing.claimNext();
      if (!job) return;
      let attempted = false;
      try {
        const bytes = encodeEscPos(job.payload, !!job.printer.cut);
        if (bytes.length > 262144)
          throw new Error('El documento supera el tamaño permitido para imprimir.');
        attempted = true;
        await send(job, bytes);
        await printing.complete(job.id, job.attemptId);
      } catch (error) {
        const e = error as { message?: string; code?: string };
        // A lost DB acknowledgement after a successful send is also uncertain.
        await printing.fail(
          job.id,
          job.attemptId,
          e.message || 'No se pudo enviar a la impresora.',
          attempted && e.code !== 'PRINT_OFFLINE',
        );
      }
      printingChanged();
    }
  })();
  workers.set(printing, worker);
  void worker
    .finally(() => {
      workers.delete(printing);
    })
    .catch(() => undefined);
  return worker;
}
