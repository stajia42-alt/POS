import { useEffect, useState, type FormEvent } from 'react';
import { Plus, Printer as PrinterIcon, Pencil, RefreshCw } from 'lucide-react';
import type { Printer, PrintJob } from '../domain/printing';
import { Modal } from './Modal';
import { useModule } from './useModule';
import type { ModuleProps } from './moduleTypes';
import { printingChanged, processPrintQueue, subscribePrinting } from './print-service';

const statuses: Record<string, string> = {
  pending: 'En cola',
  sending: 'Enviando',
  sent: 'Enviado',
  failed: 'Sin conexión',
  unknown: 'Revisar papel',
  superseded: 'Reemplazado por copia',
  cancelled: 'Retirado',
};
export function PrintersPanel({ pos, actor, onChanged, onLock }: ModuleProps) {
  const [revision, setRevision] = useState(0);
  useEffect(() => subscribePrinting(() => setRevision((n) => n + 1)), []);
  const m = useModule(() => pos.printing.snapshot(), onChanged, onLock, [revision]);
  const [editing, setEditing] = useState(false);
  const [printer, setPrinter] = useState<Printer>();
  const [kitchen, setKitchen] = useState(false);
  const [allProducts, setAllProducts] = useState(true);
  const [review, setReview] = useState<PrintJob>();
  const [preview, setPreview] = useState<PrintJob>();
  const configure = actor.permissions.includes('settings');
  const canReprint = actor.permissions.includes('reprint');
  function edit(value?: Printer) {
    setPrinter(value);
    setKitchen(!!value?.kitchen);
    setAllProducts(value?.all_products !== 0);
    setEditing(true);
  }
  const wake = () => {
    printingChanged();
    void processPrintQueue(pos.printing).catch((e) => m.setError((e as Error).message));
  };
  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const categories = allProducts ? [] : f.getAll('category').map(String);
    if (kitchen && !allProducts && !categories.length) {
      m.setError('Selecciona al menos una categoría o activa Todos los productos.');
      return;
    }
    const ok = await m.run(
      () =>
        pos.printing.savePrinter(
          {
            id: printer?.id,
            name: String(f.get('name')),
            host: String(f.get('host')),
            port: Number(f.get('port')),
            width: Number(f.get('width')) as 80 | 58,
            active: f.has('active') ? 1 : 0,
            receipt: f.has('receipt') ? 1 : 0,
            kitchen: kitchen ? 1 : 0,
            cut: f.has('cut') ? 1 : 0,
          },
          categories,
        ),
      'Impresora guardada',
    );
    if (ok) {
      setEditing(false);
      printingChanged();
    }
  }
  async function test(id: string) {
    if (await m.run(() => pos.printing.enqueueTest(id), 'Prueba añadida a la cola')) wake();
  }
  async function retry(id: string) {
    if (
      await m.run(
        () => pos.printing.retry(id),
        review?.status === 'failed' ? 'Reintento añadido a la cola' : 'Copia añadida a la cola',
      )
    ) {
      setReview(undefined);
      wake();
    }
  }
  return (
    <section className="admin-content printers-panel">
      <div className="section-heading">
        <div>
          <h1>Impresoras</h1>
          <p>Tickets y comandas · ESC/POS por IP</p>
        </div>
        {configure && (
          <button className="primary" onClick={() => edit()}>
            <Plus size={19} />
            Agregar impresora
          </button>
        )}
      </div>
      {!editing && m.error && (
        <p role="alert" className="inline-error">
          {m.error}
        </p>
      )}
      {m.notice && (
        <p className="module-notice" role="status">
          {m.notice}
        </p>
      )}
      <p className="field-hint">
        Usa la misma dirección IP de la impresora que tienes en Loyverse. La tableta y la impresora
        deben estar en la misma red. El puerto habitual es 9100.
      </p>
      {!m.data ? (
        <p role="status">Cargando impresoras…</p>
      ) : (
        <>
          {!m.data.printers.length ? (
            <div className="empty-state">
              <PrinterIcon size={40} />
              <h2>Conecta tu impresora de 80 mm</h2>
              <p>Agrega su IP y envía una impresión de prueba.</p>
            </div>
          ) : (
            <div className="printer-cards">
              {m.data.printers.map((p) => (
                <article className="feature-card" key={p.id}>
                  <div className="card-title">
                    <PrinterIcon />
                    <h2>{p.name}</h2>
                    {configure && (
                      <button
                        className="icon-button"
                        aria-label={`Editar impresora ${p.name}`}
                        onClick={() => edit(p)}
                      >
                        <Pencil size={18} />
                      </button>
                    )}
                  </div>
                  <p>
                    {p.host}:{p.port} · {p.width} mm · {p.active ? 'Activa' : 'Inactiva'}
                  </p>
                  <p>
                    {[p.receipt ? 'Tickets de cobro' : '', p.kitchen ? 'Comandas' : '']
                      .filter(Boolean)
                      .join(' · ') || 'Sin asignación'}
                  </p>
                  {!!p.kitchen && (
                    <p className="field-hint">
                      {p.all_products === 0
                        ? m
                            .data!.categories.filter((c) =>
                              m.data!.routes.some(
                                (r) => r.printer_id === p.id && r.category_id === c.id,
                              ),
                            )
                            .map((c) => c.name)
                            .join(', ') || 'Sin categorías asignadas'
                        : 'Comandas de todos los productos'}
                    </p>
                  )}
                  {configure && (
                    <button
                      className="secondary"
                      disabled={m.busy || !p.active}
                      onClick={() => void test(p.id)}
                    >
                      <PrinterIcon size={18} />
                      Imprimir prueba · {p.name}
                    </button>
                  )}
                </article>
              ))}
            </div>
          )}
          <div className="section-heading printer-queue-heading">
            <div>
              <h2>Registro de impresión</h2>
              <p>
                “Enviado” indica datos entregados a la conexión. Comprueba el papel en la impresora.
              </p>
            </div>
            <button
              className="secondary"
              disabled={m.busy}
              onClick={() => {
                setRevision((n) => n + 1);
                wake();
              }}
            >
              <RefreshCw size={18} />
              Actualizar
            </button>
          </div>
          {!m.data.jobs.length ? (
            <p className="field-hint">No hay documentos en la cola.</p>
          ) : (
            <div className="table-scroll">
              <table className="module-table">
                <thead>
                  <tr>
                    <th>Documento</th>
                    <th>Impresora</th>
                    <th>Estado</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {m.data.jobs.map((j) => (
                    <tr key={j.id}>
                      <td>
                        <button className="text-button" onClick={() => setPreview(j)}>
                          {j.payload.title}
                        </button>
                        <small>{new Date(j.createdAt).toLocaleString('es-MX')}</small>
                      </td>
                      <td>{j.printerName}</td>
                      <td>
                        <strong
                          className={
                            j.status === 'failed' || j.status === 'unknown' ? 'danger-text' : ''
                          }
                        >
                          {statuses[j.status] || j.status}
                        </strong>
                        {j.error && <small>{j.error}</small>}
                      </td>
                      <td>
                        {(j.status === 'failed' || j.status === 'unknown' || j.status === 'sent') &&
                          canReprint && (
                            <button
                              className="secondary"
                              disabled={m.busy}
                              onClick={() => setReview(j)}
                            >
                              {j.status === 'sent' ? 'Reimprimir' : 'Revisar envío'}
                            </button>
                          )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
      {editing && (
        <Modal
          title={printer ? 'Editar impresora' : 'Agregar impresora'}
          onClose={() => {
            if (!m.busy) setEditing(false);
          }}
        >
          {m.error && (
            <p className="inline-error" role="alert">
              {m.error}
            </p>
          )}
          <form className="form-body form-stack" onSubmit={(e) => void save(e)}>
            <label>
              Nombre de la impresora
              <input
                name="name"
                required
                maxLength={80}
                defaultValue={printer?.name}
                placeholder="Ej. Caja o Cocina"
              />
            </label>
            <div className="form-row">
              <label>
                Dirección IP
                <input
                  name="host"
                  required
                  inputMode="decimal"
                  maxLength={15}
                  defaultValue={printer?.host}
                  placeholder="Ej. 192.168.1.100"
                />
              </label>
              <label>
                Puerto
                <input
                  name="port"
                  type="number"
                  required
                  min="1"
                  max="65535"
                  defaultValue={printer?.port ?? 9100}
                />
              </label>
            </div>
            <label>
              Ancho del papel
              <select aria-label="Ancho del papel" name="width" defaultValue={printer?.width ?? 80}>
                <option value="80">80 mm</option>
                <option value="58">58 mm</option>
              </select>
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                name="active"
                defaultChecked={printer ? !!printer.active : true}
              />
              Impresora activa
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                name="receipt"
                defaultChecked={printer ? !!printer.receipt : true}
              />
              Imprimir tickets al cobrar
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                checked={kitchen}
                onChange={(e) => setKitchen(e.target.checked)}
              />
              Imprimir comandas
            </label>
            {kitchen && (
              <fieldset className="printer-routing">
                <legend>Productos para esta comanda</legend>
                <label className="check-label">
                  <input
                    type="checkbox"
                    checked={allProducts}
                    onChange={(e) => setAllProducts(e.target.checked)}
                  />
                  Todos los productos
                </label>
                {!allProducts &&
                  m.data?.categories.map((c) => (
                    <label className="check-label" key={c.id}>
                      <input
                        type="checkbox"
                        name="category"
                        value={c.id}
                        defaultChecked={m.data!.routes.some(
                          (r) => r.printer_id === printer?.id && r.category_id === c.id,
                        )}
                      />
                      {c.name}
                    </label>
                  ))}
                {!allProducts && !m.data?.categories.length && (
                  <p className="field-hint">
                    Crea categorías de productos para repartir comandas entre Cocina, Bar u otras
                    impresoras.
                  </p>
                )}
              </fieldset>
            )}
            <label className="check-label">
              <input type="checkbox" name="cut" defaultChecked={printer ? !!printer.cut : true} />
              Cortar papel al terminar
            </label>
            <p className="field-hint">
              Las comandas salen al guardar o cobrar. Al enviar de nuevo se incluyen solo cantidades
              nuevas y cancelaciones. Solo hay una impresora principal de tickets.
            </p>
            <button className="primary" disabled={m.busy}>
              Guardar impresora
            </button>
          </form>
        </Modal>
      )}
      {review && (
        <Modal
          title="Revisar impresión"
          onClose={() => {
            if (!m.busy) setReview(undefined);
          }}
        >
          {m.error && (
            <p className="inline-error" role="alert">
              {m.error}
            </p>
          )}
          <div className="form-body form-stack">
            <p>
              <strong>{review.payload.title}</strong> · {review.printerName}
            </p>
            <p>
              {review.status === 'failed'
                ? 'No se llegó a enviar el documento. Puedes revisar la conexión e intentar enviarlo de nuevo.'
                : 'Revisa si ya salió el papel antes de repetir. La nueva impresión se identifica como COPIA.'}
            </p>
            {(review.status === 'unknown' || review.status === 'failed') && (
              <button
                className="secondary"
                disabled={m.busy}
                onClick={() =>
                  void m
                    .run(() => pos.printing.confirmReceived(review.id), 'Papel confirmado')
                    .then((ok) => {
                      if (ok) {
                        setReview(undefined);
                        wake();
                      }
                    })
                }
              >
                Confirmar que ya salió el papel
              </button>
            )}
            <button className="primary" disabled={m.busy} onClick={() => void retry(review.id)}>
              {review.status === 'failed' ? 'Reintentar envío' : 'Enviar una copia'}
            </button>
          </div>
        </Modal>
      )}
      {preview && (
        <Modal title="Documento de impresión" onClose={() => setPreview(undefined)}>
          <div className="form-body">
            <pre className="print-document-preview">{preview.payload.lines.join('\n')}</pre>
          </div>
        </Modal>
      )}
    </section>
  );
}
