import type { Database } from './database';

export const SCHEMA_VERSION = 1;
const migration1 = [
  `CREATE TABLE categories (id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE, color TEXT NOT NULL)`,
  `CREATE TABLE products (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, sku TEXT NOT NULL DEFAULT '', barcode TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '', category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    price INTEGER NOT NULL CHECK(price >= 0), cost INTEGER NOT NULL DEFAULT 0 CHECK(cost >= 0), photo TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)), favorite INTEGER NOT NULL DEFAULT 0 CHECK(favorite IN (0,1)),
    track_stock INTEGER NOT NULL DEFAULT 0 CHECK(track_stock IN (0,1)), stock INTEGER NOT NULL DEFAULT 0,
    unit TEXT NOT NULL DEFAULT 'pieza')`,
  `CREATE UNIQUE INDEX products_sku ON products(sku) WHERE sku <> ''`,
  `CREATE UNIQUE INDEX products_barcode ON products(barcode) WHERE barcode <> ''`,
  `CREATE INDEX products_category ON products(category_id, active)`,
  `CREATE TABLE customers (id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '')`,
  `CREATE TABLE sales (
    id TEXT PRIMARY KEY, number INTEGER NOT NULL UNIQUE, status TEXT NOT NULL CHECK(status IN ('draft','parked','paid','cancelled')),
    label TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', customer_id TEXT REFERENCES customers(id), customer_name TEXT NOT NULL DEFAULT '',
    discount_bps INTEGER NOT NULL DEFAULT 0 CHECK(discount_bps BETWEEN 0 AND 10000), tax_bps INTEGER NOT NULL DEFAULT 0 CHECK(tax_bps BETWEEN 0 AND 10000),
    subtotal INTEGER NOT NULL DEFAULT 0, discount INTEGER NOT NULL DEFAULT 0, tax INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL DEFAULT 0,
    business_name TEXT NOT NULL, business_address TEXT NOT NULL DEFAULT '', business_phone TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL, paid_at TEXT)`,
  `CREATE INDEX sales_status_date ON sales(status, updated_at)`,
  `CREATE TABLE sale_lines (
    id TEXT PRIMARY KEY, sale_id TEXT NOT NULL REFERENCES sales(id), product_id TEXT NOT NULL REFERENCES products(id),
    name TEXT NOT NULL, unit_price INTEGER NOT NULL CHECK(unit_price >= 0), quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 9999), note TEXT NOT NULL DEFAULT '')`,
  `CREATE INDEX lines_sale ON sale_lines(sale_id)`,
  `CREATE TABLE payments (
    id TEXT PRIMARY KEY, sale_id TEXT NOT NULL UNIQUE REFERENCES sales(id), method TEXT NOT NULL CHECK(method = 'cash'),
    amount INTEGER NOT NULL CHECK(amount >= 0), tendered INTEGER NOT NULL, change_amount INTEGER NOT NULL CHECK(change_amount >= 0), created_at TEXT NOT NULL)`,
  `CREATE TABLE inventory_movements (
    id TEXT PRIMARY KEY, product_id TEXT NOT NULL REFERENCES products(id), sale_id TEXT REFERENCES sales(id),
    quantity INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(sale_id, product_id))`,
  `CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
  `INSERT INTO settings (key,value) VALUES ('business', '{"name":"Mi negocio","address":"","phone":"","taxBps":0,"receiptFooter":"Gracias por tu compra"}'), ('view','grid')`,
];

export async function migrate(db: Database): Promise<void> {
  await db.transaction(async (sql) => {
    const [{ user_version: version }] = await sql.query<{ user_version: number }>(
      'PRAGMA user_version',
    );
    if (version > SCHEMA_VERSION)
      throw new Error(
        'Esta base de datos pertenece a una versión más reciente. Actualiza AVILES POS.',
      );
    if (version < 1) {
      for (const statement of migration1) await sql.run(statement);
      await sql.run('PRAGMA user_version = 1');
    }
  });
}
