# AVILES POS 2.2

Aplicación offline Android con React/TypeScript, Capacitor y SQLite. Lee README.md, docs/ARQUITECTURA.md y docs/ARQUITECTURA-2.2.md antes de cambiar persistencia o cobros.

- Usa el checkout existente. Cada tarea cloud está aislada; no crees worktrees sin petición explícita.
- La identidad 2.2 está autorizada: azul noche, eléctrico, cian, ámbar y gris hielo. Usa tokens y componentes compartidos, SVG Lucide y controles táctiles. Conserva venta rápida, cuadrícula/lista y ticket accesible.
- No desarrolles ni reemplaces impresoras/comandas: pertenecen a otra tarea. Consulta REVISION_IMPRESORAS.md y revisa cambios concurrentes antes de integrar.
- Lógica en `src/domain`, almacenamiento en `src/db`, interfaz en `src/ui`. Nunca uses localStorage como base de datos ni precargues datos de prueba en la aplicación.
- Dinero en centavos; tasa MXN/USD escala 10000; ingredientes en milésimas de su unidad. Usa BigInt para multiplicar/dividir y captura importes históricos.
- Cobro final, movimientos de stock y cierre de mesa comparten transacción idempotente. Los abonos se guardan por turno; no se suman otra vez al liquidar. Un ticket con abonos no se puede cambiar ni cancelar sin un flujo de devolución.
- Migraciones versionadas; no reinicies bases. No cambies una migración ya publicada: añade la siguiente.
- Restaurar requiere administrador, validación, copia de recuperación y confirmación explícita. No uses datos comerciales en pruebas ni publiques respaldos.
- Valida con `npm test`, `npm run build`, `npm run test:e2e` y `npm run format:check`. No ejecutes simultáneamente instaladores, builds web y suites que compartan node_modules, dist, puerto 4173 o test-results.
- Herramientas cloud: `source scripts/cloud-env.sh`; instalación: `bash scripts/setup-cloud.sh`. Android requiere JDK 21, SDK 36 y Build Tools 36.0.0. `npm run android:debug` compila.
- Navegador/SQLite WASM y compilación no certifican SQLite nativo, Samsung física ni periféricos. Mantén los pendientes en AVILES_POS_PROGRESO.md.
- No subas claves de firma, respaldos, datos comerciales, APK ni node_modules al repositorio. El APK 2.1 tiene firma debug; una actualización necesita su clave original, no el PIN del usuario. Nunca sugieras desinstalar para resolver un conflicto de firma.
