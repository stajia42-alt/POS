import type { SqlDriver } from '../db/database';
import type { Actor } from './access-types';
import type { StockProduct } from './inventory';
import { integer } from './money';
import { newId, timestamp } from './shared';

export async function recordStock(
  sql: SqlDriver,
  actor: Actor,
  product: Pick<StockProduct, 'id' | 'stock' | 'cost'>,
  change: number,
  kind: string,
  reason: string,
  options: { saleId?: string; cost?: number; updateCost?: number } = {},
) {
  integer(product.stock, -999999, 999999);
  integer(change, -999999, 999999);
  const after = integer(product.stock + change, -999999, 999999);
  const movementId = newId();
  if (options.updateCost !== undefined) integer(options.updateCost);
  await sql.run('UPDATE products SET stock=?,cost=? WHERE id=?', [
    after,
    options.updateCost ?? product.cost,
    product.id,
  ]);
  await sql.run(
    `INSERT INTO inventory_movements(id,product_id,sale_id,quantity,reason,created_at,before_stock,after_stock,actor_id,actor_name,kind,unit_cost,previous_cost)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      movementId,
      product.id,
      options.saleId || null,
      change,
      reason,
      timestamp(),
      product.stock,
      after,
      actor.id,
      actor.name,
      kind,
      options.cost ?? null,
      product.cost,
    ],
  );
  return { id: movementId, before: product.stock, after };
}
