import type { Database, SqlValue } from '../db/database';
import type { AccessControl } from './access';
import type { Sale, SaleLine, Payment } from './types';
import type { Shift } from './cash';
import { integer } from './money';

export interface ReportFilter {
  from: string;
  to: string;
  employeeId?: string;
  period?: 'custom' | 'day' | 'week' | 'month';
}
export function localDate(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function day(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Fecha no válida.');
  const d = new Date(`${value}T00:00:00`);
  if (!Number.isFinite(d.getTime()) || localDate(d) !== value) throw new Error('Fecha no válida.');
  return d;
}
export function reportWindow(filter: ReportFilter, now = new Date()) {
  const start = day(filter.from);
  const end = day(filter.to);
  end.setDate(end.getDate() + 1);
  if (end <= start || end.getTime() - start.getTime() > 367 * 86400000)
    throw new Error('Selecciona un periodo válido de hasta 366 días.');
  const effective = new Date(Math.min(end.getTime(), now.getTime() + 1));
  const duration = Math.max(0, effective.getTime() - start.getTime());
  const previousStart = new Date(start);
  let previousLimit = new Date(start);
  if (filter.period === 'month') {
    previousStart.setMonth(previousStart.getMonth() - 1, 1);
  } else {
    const days = Math.round((end.getTime() - start.getTime()) / 86400000);
    previousStart.setDate(previousStart.getDate() - days);
  }
  const previousEnd = new Date(
    Math.min(previousLimit.getTime(), previousStart.getTime() + duration),
  );
  return {
    start: start.toISOString(),
    end: new Date(Math.max(start.getTime(), effective.getTime())).toISOString(),
    previousStart: previousStart.toISOString(),
    previousEnd: previousEnd.toISOString(),
    equivalent: previousEnd.getTime() - previousStart.getTime() === duration && duration > 0,
  };
}
function allocate(total: number, weights: number[]) {
  const sum = weights.reduce((n, w) => n + w, 0);
  if (!sum) return weights.map(() => 0);
  const entries = weights.map((w, i) => ({
    i,
    base: Number((BigInt(total) * BigInt(w)) / BigInt(sum)),
    remainder: (BigInt(total) * BigInt(w)) % BigInt(sum),
  }));
  let remaining = total - entries.reduce((n, e) => n + e.base, 0);
  for (const e of [...entries].sort((a, b) =>
    a.remainder === b.remainder ? a.i - b.i : a.remainder > b.remainder ? -1 : 1,
  )) {
    if (remaining-- <= 0) break;
    e.base++;
  }
  return entries.map((e) => e.base);
}
export interface ReportGroup {
  key: string;
  label: string;
  total: number;
  count: number;
  cost: number | null;
  margin: number | null;
}
export interface ReportMovement {
  id: string;
  name: string;
  quantity: number;
  scale: number;
  unit: string;
  reason: string;
  actor_name: string;
  created_at: string;
}
export class Reports {
  constructor(
    private db: Database,
    private access: AccessControl,
  ) {}
  snapshot(filter: ReportFilter, at = new Date()) {
    const window = reportWindow(filter, at);
    return this.db.read(async (sql) => {
      await this.access.require(sql, 'reports');
      const employee = filter.employeeId || '';
      const suffix = employee ? ' AND employee_id=?' : '';
      const args = (from: string, to: string): SqlValue[] =>
        employee ? [from, to, employee] : [from, to];
      const sales = await sql.query<Sale>(
        `SELECT * FROM sales WHERE status='paid' AND paid_at>=? AND paid_at<?${suffix} ORDER BY paid_at`,
        args(window.start, window.end),
      );
      const previous = await sql.query<Sale>(
        `SELECT * FROM sales WHERE status='paid' AND paid_at>=? AND paid_at<?${suffix}`,
        args(window.previousStart, window.previousEnd),
      );
      const lines = await sql.query<SaleLine & { sale_id: string }>(
        `SELECT l.* FROM sale_lines l JOIN sales s ON s.id=l.sale_id WHERE s.status='paid' AND s.paid_at>=? AND s.paid_at<?${employee ? ' AND s.employee_id=?' : ''}`,
        args(window.start, window.end),
      );
      const payments = await sql.query<Payment>(
        `SELECT * FROM payments WHERE created_at>=? AND created_at<?${suffix} ORDER BY created_at`,
        args(window.start, window.end),
      );
      const cancelled = await sql.query<Sale>(
        `SELECT * FROM sales WHERE status='cancelled' AND merged_into IS NULL AND EXISTS(SELECT 1 FROM sale_lines WHERE sale_id=sales.id) AND updated_at>=? AND updated_at<?${employee ? ' AND cancelled_by=?' : ''}`,
        args(window.start, window.end),
      );
      const shifts = await sql.query<Shift>(
        `SELECT * FROM shifts WHERE status='closed' AND closed_at>=? AND closed_at<?${employee ? ' AND closed_by=?' : ''} ORDER BY closed_at DESC`,
        args(window.start, window.end),
      );
      const employees = await sql.query<{ id: string; name: string }>(
        'SELECT id,name FROM employees ORDER BY name',
      );
      const movements = await sql.query<ReportMovement>(
        `SELECT m.id,p.name,m.quantity,1 AS scale,p.unit,m.reason,m.actor_name,m.created_at FROM inventory_movements m JOIN products p ON p.id=m.product_id WHERE m.created_at>=? AND m.created_at<?${employee ? ' AND m.actor_id=?' : ''} UNION ALL SELECT m.id,i.name,m.quantity,1000 AS scale,i.unit,m.reason,m.actor_name,m.created_at FROM material_movements m JOIN stock_items i ON i.id=m.item_id WHERE m.created_at>=? AND m.created_at<?${employee ? ' AND m.actor_id=?' : ''} ORDER BY created_at DESC`,
        [...args(window.start, window.end), ...args(window.start, window.end)],
      );
      const groups = (key: (s: Sale) => string) => {
        const result = new Map<string, ReportGroup>();
        for (const s of sales) {
          const k = key(s);
          const g = result.get(k) || {
            key: k,
            label: k,
            total: 0,
            count: 0,
            cost: null,
            margin: null,
          };
          g.total += s.total;
          g.count++;
          result.set(k, g);
        }
        return [...result.values()];
      };
      const linesBySale = new Map<string, SaleLine[]>();
      for (const line of lines) {
        const group = linesBySale.get(line.sale_id) || [];
        group.push(line);
        linesBySale.set(line.sale_id, group);
      }
      const productMap = new Map<string, ReportGroup>();
      const categoryMap = new Map<string, ReportGroup>();
      let knownCost = 0,
        knownNet = 0,
        costLines = 0;
      for (const sale of sales) {
        const sold = linesBySale.get(sale.id) || [];
        const nets = allocate(
          sale.subtotal - sale.discount,
          sold.map((l) => l.unit_price * l.quantity),
        );
        for (let i = 0; i < sold.length; i++) {
          const l = sold[i];
          const net = nets[i];
          const known = l.cost_total !== null && l.cost_total !== undefined;
          if (known) {
            knownCost += l.cost_total!;
            knownNet += net;
            costLines++;
          }
          for (const [map, k, label] of [
            [productMap, l.product_id, l.name],
            [
              categoryMap,
              l.category_name || 'unknown',
              l.category_name || 'Sin categoría histórica',
            ],
          ] as const) {
            const g = map.get(k) || { key: k, label, total: 0, count: 0, cost: 0, margin: 0 };
            g.total += net;
            g.count += l.quantity;
            if (!known) {
              g.cost = null;
              g.margin = null;
            } else if (g.cost !== null) {
              g.cost += l.cost_total!;
              g.margin = g.total - g.cost;
            }
            map.set(k, g);
          }
        }
      }
      const total = integer(
        sales.reduce((n, s) => n + s.total, 0),
        0,
        Number.MAX_SAFE_INTEGER,
      );
      const previousTotal = integer(
        previous.reduce((n, s) => n + s.total, 0),
        0,
        Number.MAX_SAFE_INTEGER,
      );
      const methods = new Map<string, { method: string; amount: number; count: number }>();
      for (const p of payments) {
        const g = methods.get(p.method) || { method: p.method, amount: 0, count: 0 };
        g.amount += p.amount;
        g.count++;
        methods.set(p.method, g);
      }
      const cash = payments.filter((p) => p.method === 'cash');
      const products = [...productMap.values()].sort((a, b) => b.total - a.total);
      const rentable = products
        .filter((p) => p.margin !== null)
        .sort((a, b) => b.margin! - a.margin!);
      return {
        filter,
        window,
        sales,
        previousSales: previous.length,
        employees,
        cancelled,
        shifts,
        movements,
        payments,
        methods: [...methods.values()],
        total,
        net: sales.reduce((n, s) => n + s.subtotal - s.discount, 0),
        tax: sales.reduce((n, s) => n + s.tax, 0),
        discount: sales.reduce((n, s) => n + s.discount, 0),
        average: sales.length ? Math.round(total / sales.length) : null,
        comparison:
          window.equivalent && sales.length > 0 && previous.length > 0 && previousTotal > 0
            ? {
                previous: previousTotal,
                change: total - previousTotal,
                percent: ((total - previousTotal) * 100) / previousTotal,
              }
            : null,
        costs: {
          cost: knownCost,
          margin: knownNet - knownCost,
          coveredLines: costLines,
          totalLines: lines.length,
          complete: lines.length > 0 && costLines === lines.length,
        },
        days: groups((s) => localDate(new Date(s.paid_at!))).sort((a, b) =>
          a.key.localeCompare(b.key),
        ),
        employeesSales: groups(
          (s) => `${s.employee_id || 'legacy'}|${s.employee_name || 'Sin empleado histórico'}`,
        )
          .map((g) => ({
            ...g,
            key: g.key.split('|')[0],
            label: g.label.slice(g.label.indexOf('|') + 1),
          }))
          .sort((a, b) => b.total - a.total),
        hours: groups((s) => `${String(new Date(s.paid_at!).getHours()).padStart(2, '0')}:00`).sort(
          (a, b) => a.key.localeCompare(b.key),
        ),
        products,
        categories: [...categoryMap.values()].sort((a, b) => b.total - a.total),
        mostProfitable: rentable.slice(0, 5),
        leastProfitable: [...rentable].reverse().slice(0, 5),
        physical: {
          receivedMxn: cash
            .filter((p) => p.currency === 'MXN')
            .reduce((n, p) => n + p.original_tendered, 0),
          receivedUsd: cash
            .filter((p) => p.currency === 'USD')
            .reduce((n, p) => n + p.original_tendered, 0),
          changeMxn: cash.reduce((n, p) => n + p.change_mxn, 0),
          changeUsd: cash.reduce((n, p) => n + p.change_usd, 0),
        },
      };
    });
  }
}
export type ReportData = Awaited<ReturnType<Reports['snapshot']>>;
export function csvCell(value: string | number) {
  const s = String(value);
  const safe = typeof value === 'string' && /^[\s]*[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  return `"${safe.replaceAll('"', '""')}"`;
}
export function reportRows(data: ReportData): (string | number)[][] {
  const rows: (string | number)[][] = [
    ['AVILES POS 2.2', 'Reporte de operación'],
    ['Desde', data.filter.from, 'Hasta', data.filter.to],
    ['Horario', 'Del dispositivo'],
    ['Ventas completadas', data.sales.length],
    ['Total MXN', data.total / 100],
    ['Subtotal neto sin impuestos MXN', data.net / 100],
    ['Ticket promedio MXN', data.average === null ? 'Datos insuficientes' : data.average / 100],
    ['Descuentos MXN', data.discount / 100],
    ['Cancelaciones', data.cancelled.length],
    [
      'Margen bruto estimado MXN',
      data.costs.complete ? data.costs.margin / 100 : 'Datos históricos de costo incompletos',
    ],
    [
      'Nota',
      'El margen bruto no es utilidad neta. Cobros incluye anticipos registrados en el periodo.',
    ],
  ];
  for (const [title, groups] of [
    ['Productos (ingreso neto sin impuesto)', data.products],
    ['Categorías (ingreso neto sin impuesto)', data.categories],
    ['Por empleado', data.employeesSales],
    ['Por hora', data.hours],
    ['Por día', data.days],
  ] as const) {
    rows.push([], [title, 'Cantidad', 'Importe MXN', 'Costo MXN', 'Margen bruto MXN']);
    for (const g of groups)
      rows.push([
        g.label,
        g.count,
        g.total / 100,
        g.cost === null ? 'No disponible' : g.cost / 100,
        g.margin === null ? 'No disponible' : g.margin / 100,
      ]);
  }
  rows.push([], ['Cobros por método', 'Partes', 'Aplicado MXN']);
  for (const m of data.methods) rows.push([m.method, m.count, m.amount / 100]);
  rows.push(
    [],
    ['Efectivo recibido MXN', data.physical.receivedMxn / 100],
    ['Efectivo recibido USD', data.physical.receivedUsd / 100],
    ['Cambio MXN', data.physical.changeMxn / 100],
    ['Cambio USD', data.physical.changeUsd / 100],
  );
  rows.push([], ['Ventas', 'Fecha', 'Empleado', 'Total MXN']);
  for (const s of data.sales) rows.push([s.number, s.paid_at!, s.employee_name, s.total / 100]);
  rows.push(
    [],
    [
      'Pagos',
      'Fecha',
      'Moneda',
      'Recibido original',
      'Aplicado MXN',
      'Cambio MXN',
      'Cambio USD',
      'Tasa MXN/USD',
    ],
  );
  for (const p of data.payments)
    rows.push([
      p.sale_id,
      p.created_at,
      p.currency,
      p.original_tendered / 100,
      p.amount / 100,
      p.change_mxn / 100,
      p.change_usd / 100,
      p.exchange_rate ? p.exchange_rate / 10000 : 'Sin tasa',
    ]);
  rows.push(
    [],
    [
      'Cortes',
      'Apertura',
      'Cierre',
      'Empleado',
      'Esperado MXN',
      'Contado MXN',
      'Diferencia MXN',
      'Esperado USD',
      'Contado USD',
      'Diferencia USD',
    ],
  );
  for (const s of data.shifts)
    rows.push([
      s.id,
      s.opened_at,
      s.closed_at!,
      s.closed_name || '',
      (s.expected || 0) / 100,
      (s.counted || 0) / 100,
      (s.difference || 0) / 100,
      (s.expected_usd || 0) / 100,
      (s.counted_usd || 0) / 100,
      (s.difference_usd || 0) / 100,
    ]);
  rows.push([], ['Inventario', 'Fecha', 'Artículo', 'Cantidad', 'Unidad', 'Empleado', 'Motivo']);
  for (const m of data.movements)
    rows.push([m.id, m.created_at, m.name, m.quantity / m.scale, m.unit, m.actor_name, m.reason]);
  return rows;
}
export const reportCsv = (data: ReportData) =>
  '\uFEFF' +
  reportRows(data)
    .map((row) => row.map(csvCell).join(','))
    .join('\r\n');
