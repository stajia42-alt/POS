import { useState } from 'react';
import { BarChart3, Download, FileText, TrendingUp, ReceiptText } from 'lucide-react';
import { money, currencyMoney } from '../domain/money';
import {
  localDate,
  reportCsv,
  reportRows,
  type ReportFilter,
  type ReportGroup,
} from '../domain/reports';
import { PAYMENT_LABELS } from '../domain/payments';
import type { PaymentMethod } from '../domain/types';
import { useModule } from './useModule';
import type { ModuleProps } from './moduleTypes';
import { exportFile, exportBytes } from './exportFile';
import { textPdf } from './reportPdf';
function preset(period: 'day' | 'week' | 'month'): ReportFilter {
  const start = new Date(),
    end = new Date();
  if (period === 'week') {
    const weekday = (start.getDay() + 6) % 7;
    start.setDate(start.getDate() - weekday);
    end.setDate(start.getDate() + 6);
  }
  if (period === 'month') {
    start.setDate(1);
    end.setMonth(end.getMonth() + 1, 0);
  }
  return { from: localDate(start), to: localDate(end), employeeId: '', period };
}
function Bars({ groups, label }: { groups: ReportGroup[]; label: string }) {
  const max = Math.max(1, ...groups.map((g) => g.total));
  return groups.length ? (
    <div
      className="bar-chart"
      role="img"
      aria-label={`${label}. ${groups.map((g) => `${g.label}: ${money(g.total)}`).join('; ')}`}
    >
      {groups.slice(-31).map((g) => (
        <div key={g.key} className="chart-column">
          <span className="chart-value">{money(g.total)}</span>
          <div className="chart-track">
            <div style={{ height: `${Math.max(g.total > 0 ? 2 : 0, (g.total * 100) / max)}%` }} />
          </div>
          <small>{label.includes('hora') ? g.label : g.label.slice(5)}</small>
        </div>
      ))}
    </div>
  ) : (
    <div className="chart-empty">
      <BarChart3 size={32} />
      <p>Sin ventas en este periodo</p>
    </div>
  );
}
function Breakdown({
  title,
  groups,
  costs = false,
}: {
  title: string;
  groups: ReportGroup[];
  costs?: boolean;
}) {
  return (
    <article className="feature-card report-breakdown">
      <h2>{title}</h2>
      {groups.length ? (
        <div className="table-scroll">
          <table className="module-table">
            <thead>
              <tr>
                <th>Detalle</th>
                <th>Cantidad</th>
                <th>Importe MXN</th>
                {costs && <th>Margen bruto</th>}
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => (
                <tr key={g.key}>
                  <td>{g.label}</td>
                  <td>{g.count}</td>
                  <td>{money(g.total)}</td>
                  {costs && <td>{g.margin === null ? 'Datos insuficientes' : money(g.margin)}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="field-hint">Datos insuficientes para este periodo.</p>
      )}
    </article>
  );
}
export function ReportsPanel({ pos, onChanged, onLock }: ModuleProps) {
  const [filter, setFilter] = useState<ReportFilter>(() => preset('day'));
  const [tab, setTab] = useState<'overview' | 'products' | 'cash' | 'inventory'>('overview');
  const m = useModule(() => pos.reports.snapshot(filter), onChanged, onLock, [filter]);
  const d = m.data && JSON.stringify(m.data.filter) === JSON.stringify(filter) ? m.data : undefined;
  const change = (key: 'from' | 'to' | 'employeeId', value: string) =>
    setFilter((old) => ({
      ...old,
      [key]: value,
      ...(key !== 'employeeId' ? { period: 'custom' as const } : {}),
    }));
  return (
    <section className="admin-content reports-panel">
      <div className="section-heading">
        <div>
          <p className="eyebrow">EL PULSO DE TU NEGOCIO</p>
          <h1>Reportes</h1>
          <p>Decisiones claras, con tus operaciones reales.</p>
        </div>
        <div className="inline-actions">
          <button
            className="secondary"
            disabled={!d || m.busy}
            onClick={() =>
              void m.run(
                () =>
                  exportFile(
                    `AVILES-REPORTE-${filter.from}-${filter.to}.csv`,
                    reportCsv(d!),
                    'text/csv;charset=utf-8',
                  ),
                'Reporte CSV exportado',
              )
            }
          >
            <Download size={18} />
            CSV
          </button>
          <button
            className="secondary"
            disabled={!d || m.busy}
            onClick={() =>
              void m.run(
                () =>
                  exportBytes(
                    `AVILES-REPORTE-${filter.from}-${filter.to}.pdf`,
                    textPdf(reportRows(d!).map((r) => r.join('  |  '))),
                    'application/pdf',
                  ),
                'Reporte PDF exportado',
              )
            }
          >
            <FileText size={18} />
            PDF
          </button>
        </div>
      </div>
      <div className="report-filter-card">
        <div className="period-buttons">
          {(
            [
              ['day', 'Hoy'],
              ['week', 'Esta semana'],
              ['month', 'Este mes'],
            ] as const
          ).map(([p, label]) => (
            <button
              key={p}
              aria-pressed={filter.period === p}
              onClick={() => setFilter({ ...preset(p), employeeId: filter.employeeId })}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="form-row">
          <label>
            Desde
            <input
              type="date"
              value={filter.from}
              onChange={(e) => change('from', e.target.value)}
            />
          </label>
          <label>
            Hasta
            <input type="date" value={filter.to} onChange={(e) => change('to', e.target.value)} />
          </label>
          <label>
            Empleado del reporte
            <select
              aria-label="Empleado del reporte"
              value={filter.employeeId}
              onChange={(e) => change('employeeId', e.target.value)}
            >
              <option value="">Todos los empleados</option>
              {d?.employees.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <p className="field-hint">
          Horario del dispositivo. La comparación usa el tiempo transcurrido equivalente del periodo
          anterior.
        </p>
      </div>
      {m.error && (
        <p className="inline-error" role="alert">
          {m.error}
        </p>
      )}
      {m.notice && (
        <p className="module-notice" role="status">
          {m.notice}
        </p>
      )}
      <nav className="module-tabs" aria-label="Secciones de reportes">
        {(
          [
            ['overview', 'Resumen'],
            ['products', 'Productos y costos'],
            ['cash', 'Cobros y caja'],
            ['inventory', 'Movimientos de inventario'],
          ] as const
        ).map(([id, label]) => (
          <button key={id} aria-pressed={tab === id} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </nav>
      {!d ? (
        <p role="status">
          {m.error ? 'Ajusta el periodo para cargar el reporte.' : 'Cargando operaciones…'}
        </p>
      ) : (
        <>
          {tab === 'overview' && (
            <>
              <div className="report-metrics">
                <article className="hero-metric">
                  <div>
                    <TrendingUp size={20} />
                    <span>Ventas completadas</span>
                  </div>
                  <strong data-testid="report-total">{money(d.total)}</strong>
                  <small>
                    {d.comparison
                      ? `${d.comparison.percent >= 0 ? '+' : ''}${d.comparison.percent.toFixed(1)}% · periodo anterior ${money(d.comparison.previous)}`
                      : 'Comparación: datos insuficientes'}
                  </small>
                </article>
                <article>
                  <ReceiptText size={20} />
                  <span>Tickets completados</span>
                  <strong>{d.sales.length}</strong>
                  <small>Promedio {d.average === null ? 'sin datos' : money(d.average)}</small>
                </article>
                <article>
                  <span>Descuentos</span>
                  <strong>{money(d.discount)}</strong>
                  <small>
                    {d.cancelled.length} cancelaciones ·{' '}
                    {money(d.cancelled.reduce((n, s) => n + s.total, 0))}
                  </small>
                </article>
              </div>
              <div className="report-charts">
                <article className="feature-card">
                  <h2>Ventas por día</h2>
                  <Bars groups={d.days} label="Ventas por día" />
                </article>
                <article className="feature-card">
                  <h2>Horarios de mayor venta</h2>
                  <Bars groups={d.hours} label="Ventas por hora" />
                </article>
              </div>
              <Breakdown title="Ventas por empleado" groups={d.employeesSales} />
            </>
          )}
          {tab === 'products' && (
            <>
              <div className="metric-grid">
                <div>
                  <small>Costo registrado de ventas</small>
                  <strong>{d.costs.complete ? money(d.costs.cost) : 'Datos incompletos'}</strong>
                  <small>
                    {d.costs.coveredLines}/{d.costs.totalLines} líneas con costo histórico
                  </small>
                </div>
                <div>
                  <small>Margen bruto estimado</small>
                  <strong>
                    {d.costs.complete ? money(d.costs.margin) : 'Datos insuficientes'}
                  </strong>
                  <small>Ingreso después del descuento, sin impuestos, menos costo.</small>
                </div>
              </div>
              <p className="cost-disclaimer">
                El margen bruto estimado no es utilidad neta: no incluye renta, nómina, servicios ni
                otros gastos. Los costos históricos no registrados no se inventan.
              </p>
              <Breakdown
                title="Ventas por producto · ingreso neto sin impuestos"
                groups={d.products}
                costs
              />
              <Breakdown
                title="Ventas por categoría · ingreso neto sin impuestos"
                groups={d.categories}
                costs
              />
              <div className="report-charts">
                <Breakdown title="Mayor margen bruto estimado" groups={d.mostProfitable} costs />
                <Breakdown title="Menor margen bruto estimado" groups={d.leastProfitable} costs />
              </div>
            </>
          )}
          {tab === 'cash' && (
            <>
              <p className="cost-disclaimer">
                Cobros incluye pagos parciales por su fecha de registro. Ventas se reconoce al
                liquidar el ticket. El efectivo se cuenta físicamente por moneda, sin sumar pesos y
                dólares.
              </p>
              <div className="metric-grid">
                <div>
                  <small>Efectivo recibido MXN / cambio MXN</small>
                  <strong>{currencyMoney(d.physical.receivedMxn, 'MXN')}</strong>
                  <small>Cambio entregado: {currencyMoney(d.physical.changeMxn, 'MXN')}</small>
                </div>
                <div>
                  <small>Efectivo recibido USD / cambio USD</small>
                  <strong>{currencyMoney(d.physical.receivedUsd, 'USD')}</strong>
                  <small>Cambio entregado: {currencyMoney(d.physical.changeUsd, 'USD')}</small>
                </div>
              </div>
              <article className="feature-card">
                <h2>Métodos de pago</h2>
                {d.methods.length ? (
                  <div className="data-list">
                    {d.methods.map((p) => (
                      <div className="detail-row" key={p.method}>
                        <span>
                          {PAYMENT_LABELS[p.method as PaymentMethod]} · {p.count} partes
                        </span>
                        <strong>{money(p.amount)}</strong>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p>Sin cobros registrados.</p>
                )}
              </article>
              <h2>Cortes de caja</h2>
              <div className="table-scroll">
                <table className="module-table">
                  <thead>
                    <tr>
                      <th>Cierre / empleado</th>
                      <th>Esperado MXN</th>
                      <th>Contado MXN</th>
                      <th>Diferencia MXN</th>
                      <th>Esperado USD</th>
                      <th>Contado USD</th>
                      <th>Diferencia USD</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.shifts.map((s) => (
                      <tr key={s.id}>
                        <td>
                          {new Date(s.closed_at!).toLocaleString('es-MX')}
                          <small>{s.closed_name}</small>
                        </td>
                        <td>{money(s.expected || 0)}</td>
                        <td>{money(s.counted || 0)}</td>
                        <td>{money(s.difference || 0)}</td>
                        <td>{currencyMoney(s.expected_usd || 0, 'USD')}</td>
                        <td>{currencyMoney(s.counted_usd || 0, 'USD')}</td>
                        <td>{currencyMoney(s.difference_usd || 0, 'USD')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!d.shifts.length && <p className="field-hint">Sin cortes cerrados en el periodo.</p>}
            </>
          )}
          {tab === 'inventory' && (
            <>
              <h2>Movimientos del periodo</h2>
              <div className="table-scroll">
                <table className="module-table">
                  <thead>
                    <tr>
                      <th>Fecha</th>
                      <th>Artículo</th>
                      <th>Cantidad</th>
                      <th>Empleado</th>
                      <th>Motivo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.movements.map((v) => (
                      <tr key={v.id}>
                        <td>{new Date(v.created_at).toLocaleString('es-MX')}</td>
                        <td>{v.name}</td>
                        <td>
                          {new Intl.NumberFormat('es-MX', { maximumFractionDigits: 3 }).format(
                            v.quantity / v.scale,
                          )}{' '}
                          {v.unit}
                        </td>
                        <td>{v.actor_name}</td>
                        <td>{v.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!d.movements.length && (
                <p className="field-hint">Sin movimientos en este periodo.</p>
              )}
            </>
          )}
        </>
      )}
    </section>
  );
}
