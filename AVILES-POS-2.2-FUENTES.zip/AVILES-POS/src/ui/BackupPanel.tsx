import { useState } from 'react';
import { ShieldCheck, Download, Upload, DatabaseBackup } from 'lucide-react';
import type { BackupFile } from '../domain/backups';
import type { ModuleProps } from './moduleTypes';
import { useModule } from './useModule';
import { exportFile } from './exportFile';

export function BackupPanel({ pos, onChanged, onLock }: ModuleProps) {
  const m = useModule(() => pos.backups.integrity(), onChanged, onLock);
  const [last, setLast] = useState<BackupFile>();
  const [selected, setSelected] = useState<{ text: string; file: BackupFile; size: number }>();
  const [confirmation, setConfirmation] = useState('');
  const [safety, setSafety] = useState('');
  const [ack, setAck] = useState(false);
  async function save(recovery = false) {
    await m.run(async () => {
      const file = await pos.backups.create();
      await exportFile(
        `AVILES-${recovery ? 'RECUPERACION' : 'RESPALDO'}-${file.manifest.created_at.replace(/[:.]/g, '-')}.json`,
        JSON.stringify(file),
      );
      setLast(file);
      if (recovery) setSafety(file.manifest.sha256);
    }, 'Respaldo preparado. En navegador, comprueba que la descarga se haya guardado.');
  }
  return (
    <section className="admin-content backup-panel">
      <div className="section-heading">
        <div>
          <p className="eyebrow">PROTECCIÓN DE DATOS</p>
          <h1>Respaldos y recuperación</h1>
          <p>Una copia completa de tu operación, bajo tu control.</p>
        </div>
        <ShieldCheck size={30} />
      </div>
      {m.error && (
        <p className="inline-error" role="alert">
          {m.error}
        </p>
      )}
      {m.notice && (
        <p className="module-notice" role="status">
          {m.notice}
        </p>
      )}
      <div className="backup-layout">
        <div className="feature-card">
          <DatabaseBackup size={30} />
          <h2>Respaldo completo</h2>
          <p>
            Incluye fotografías, ventas, mesas, empleados, permisos, inventario y configuración.
            Guarda el archivo en una ubicación privada fuera de la aplicación.
          </p>
          <button className="primary" disabled={m.busy} onClick={() => void save()}>
            <Download size={19} />
            Crear y exportar respaldo
          </button>
          <button
            className="secondary"
            disabled={m.busy}
            onClick={() =>
              void m.run(() => pos.backups.integrity(), 'Integridad SQLite verificada')
            }
          >
            <ShieldCheck size={19} />
            Verificar integridad
          </button>
          <p className="field-hint">{m.data}</p>
          {last && (
            <div className="metadata">
              <strong>Última copia de esta sesión</strong>
              <span>{new Date(last.manifest.created_at).toLocaleString('es-MX')}</span>
              <span>
                Versión {last.manifest.app_version} · esquema {last.manifest.schema_version}
              </span>
              <span>{(new Blob([JSON.stringify(last)]).size / 1024).toFixed(1)} KB</span>
              <code>{last.manifest.sha256}</code>
            </div>
          )}
        </div>
        <div className="feature-card">
          <Upload size={30} />
          <h2>Restaurar una copia</h2>
          <p>
            Primero se valida el archivo en una base aislada. La restauración reemplaza los datos
            actuales y requiere una copia de recuperación y tu confirmación.
          </p>
          <label>
            Archivo de respaldo
            <input
              type="file"
              accept="application/json,.json"
              disabled={m.busy}
              onChange={(e) => {
                const file = e.target.files?.[0];
                setSelected(undefined);
                setSafety('');
                setAck(false);
                setConfirmation('');
                if (file)
                  void m.run(async () => {
                    if (file.size > 100_000_000)
                      throw new Error('El respaldo supera el límite de 100 MB.');
                    const text = await file.text();
                    setSelected({ text, file: await pos.backups.inspect(text), size: file.size });
                  }, 'Archivo validado; todavía no se modificó la base.');
              }}
            />
          </label>
          {selected && (
            <>
              <div className="metadata">
                <strong>Archivo íntegro</strong>
                <span>
                  {new Date(selected.file.manifest.created_at).toLocaleString('es-MX')} ·{' '}
                  {selected.file.manifest.app_version}
                </span>
                <span>
                  {(selected.size / 1024).toFixed(1)} KB · {selected.file.manifest.counts.products}{' '}
                  productos · {selected.file.manifest.counts.sales} tickets
                </span>
              </div>
              <button className="secondary" disabled={m.busy} onClick={() => void save(true)}>
                Exportar copia de recuperación actual
              </button>
              <label>
                Escribe RESTAURAR para confirmar
                <input
                  value={confirmation}
                  onChange={(e) => setConfirmation(e.target.value)}
                  autoComplete="off"
                />
              </label>
              <label className="check-label">
                <input
                  type="checkbox"
                  required
                  disabled={!safety}
                  checked={ack}
                  onChange={(e) => setAck(e.target.checked)}
                />
                He guardado la copia de recuperación fuera de la aplicación
              </label>
              <button
                className="danger-button"
                disabled={m.busy || !ack || !safety || confirmation !== 'RESTAURAR'}
                onClick={() =>
                  void m.run(async () => {
                    await pos.backups.restore(selected.text, confirmation, safety);
                    onLock();
                  }, 'Restauración completada. Vuelve a entrar con un PIN del respaldo.')
                }
              >
                Restaurar y cerrar sesión
              </button>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
