import { Capacitor, registerPlugin } from '@capacitor/core';
const Documents = registerPlugin<{
  save(options: { name: string; mime: string; content: string; base64?: boolean }): Promise<void>;
}>('Documents');
export async function exportFile(name: string, content: string, mime = 'application/json') {
  if (Capacitor.isNativePlatform()) {
    await Documents.save({ name, mime, content });
    return;
  }
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export async function exportBytes(name: string, data: Uint8Array, mime: string) {
  if (Capacitor.isNativePlatform()) {
    let binary = '';
    for (const byte of data) binary += String.fromCharCode(byte);
    await Documents.save({ name, mime, content: btoa(binary), base64: true });
    return;
  }
  const url = URL.createObjectURL(new Blob([new Uint8Array(data).buffer], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
