/** Small, offline, paginated PDF exporter. Text is encoded as WinAnsi/Latin-1. */
export function textPdf(lines: string[]): Uint8Array {
  const plain = (s: string) => s.replace(/[–—→]/g, '-').replace(/[^\x20-\xFF]/g, ' ');
  const wrapped = lines.flatMap((line) => {
    const s = plain(line);
    const out: string[] = [];
    for (let i = 0; i < Math.max(1, s.length); i += 112) out.push(s.slice(i, i + 112));
    return out;
  });
  const pages: string[][] = [];
  for (let i = 0; i < wrapped.length; i += 47) pages.push(wrapped.slice(i, i + 47));
  if (!pages.length) pages.push([]);
  const objects: string[] = [
    '',
    '<< /Type /Catalog /Pages 2 0 R >>',
    '',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
  ];
  const refs: number[] = [];
  for (const [index, page] of pages.entries()) {
    const id = objects.length;
    refs.push(id);
    objects.push(
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ${id + 1} 0 R >>`,
    );
    const commands = `BT /F1 10 Tf 42 800 Td 15 TL ${page.map((l) => `(${l.replace(/([\\()])/g, '\\$1')}) Tj T*`).join('\n')} T* (AVILES POS 2.2 - ${index + 1}/${pages.length}) Tj ET`;
    objects.push(`<< /Length ${commands.length} >>\nstream\n${commands}\nendstream`);
  }
  objects[2] = `<< /Type /Pages /Kids [${refs.map((id) => `${id} 0 R`).join(' ')}] /Count ${refs.length} >>`;
  let pdf = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n';
  const offsets = [0];
  for (let i = 1; i < objects.length; i++) {
    offsets[i] = pdf.length;
    pdf += `${i} 0 obj\n${objects[i]}\nendobj\n`;
  }
  const start = pdf.length;
  pdf += `xref\n0 ${objects.length}\n0000000000 65535 f \n${offsets
    .slice(1)
    .map((n) => `${String(n).padStart(10, '0')} 00000 n \n`)
    .join('')}trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${start}\n%%EOF\n`;
  return Uint8Array.from(pdf, (c) => c.charCodeAt(0));
}
