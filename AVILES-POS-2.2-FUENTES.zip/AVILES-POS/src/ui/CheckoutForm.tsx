import { useState, type FormEvent } from 'react';
import { ArrowRightLeft, Banknote, CreditCard, Plus, Trash2, Wallet } from 'lucide-react';
import { currencyMoney, money, parseMoney } from '../domain/money';
import { MAX_PAYMENTS, PAYMENT_LABELS, preparePayments, usdToMxn } from '../domain/payments';
import type { PaymentMethod, PaymentRequest } from '../domain/types';

interface Entry {
  key: string;
  currency: 'MXN' | 'USD';
  changeCurrency: 'MXN' | 'USD';
  method: PaymentMethod;
  amount: string;
  tendered: string;
  reference: string;
}
const icons = { cash: Banknote, card: CreditCard, transfer: ArrowRightLeft, other: Wallet };
const decimal = (cents: number) => (cents / 100).toFixed(2);
function cents(value: string) {
  try {
    return parseMoney(value);
  } catch {
    return 0;
  }
}

export function CheckoutForm({
  total,
  busy,
  onSubmit,
  onError,
  exchangeRate,
  usdChange,
  paid = 0,
  previousCount = 0,
}: {
  total: number;
  busy: boolean;
  onSubmit: (payments: PaymentRequest[], partial: boolean, requestId: string) => void;
  exchangeRate?: number | null;
  usdChange?: boolean;
  paid?: number;
  previousCount?: number;
  onError: (message: string) => void;
}) {
  const [entries, setEntries] = useState<Entry[]>([
    {
      key: crypto.randomUUID(),
      currency: 'MXN',
      changeCurrency: 'MXN',
      method: 'cash',
      amount: decimal(total),
      tendered: '',
      reference: '',
    },
  ]);
  const [partial, setPartial] = useState(false);
  const [requestId] = useState(() => crypto.randomUUID());
  const multiple = entries.length > 1;
  const allocatedInput = multiple || partial;
  const options = { rate: exchangeRate, usdChange, partial };
  const update = (key: string, values: Partial<Entry>) =>
    setEntries((previous) =>
      previous.map((entry) => (entry.key === key ? { ...entry, ...values } : entry)),
    );
  const requests = () =>
    entries.map((entry) => ({
      method: entry.method,
      amount: parseMoney(allocatedInput ? entry.amount : decimal(total)),
      currency: entry.method === 'cash' ? entry.currency : ('MXN' as const),
      changeCurrency: entry.method === 'cash' ? entry.changeCurrency : ('MXN' as const),
      tendered: entry.method === 'cash' ? parseMoney(entry.tendered || '0') : undefined,
      reference: entry.reference,
    }));
  let valid = false;
  try {
    preparePayments(total, requests(), options);
    valid = true;
  } catch {
    /* Input validation also runs in the transaction. */
  }
  const allocated = entries.reduce((sum, entry) => sum + cents(entry.amount), 0);
  let cashChange = 0;
  try {
    cashChange = preparePayments(total, requests(), options)
      .filter((p) => p.method === 'cash')
      .reduce((n, p) => n + p.change_amount, 0);
  } catch {
    /* Show no aggregate until all entries validate. */
  }
  const submit = (event: FormEvent) => {
    event.preventDefault();
    try {
      const payments = requests();
      preparePayments(total, payments, options);
      onSubmit(payments, partial, requestId);
    } catch (error) {
      onError((error as Error).message);
    }
  };

  return (
    <form className="form-body checkout-form" onSubmit={submit}>
      <div className="checkout-fields">
        {paid > 0 && (
          <p className="module-notice">
            Ya pagado: {money(paid)} · Los pagos anteriores están guardados.
          </p>
        )}
        <div className="checkout-total">
          <span>Total a cobrar</span>
          <strong>{money(total)}</strong>
        </div>
        <div className="currency-rate">
          <span>MXN / USD</span>
          <strong>
            {exchangeRate
              ? `1 USD = ${(exchangeRate / 10000).toFixed(4)} MXN`
              : 'Tasa USD sin configurar'}
          </strong>
        </div>
        <label className="check-label">
          <input
            type="checkbox"
            checked={partial}
            disabled={busy || total === 0 || previousCount + entries.length >= 10}
            onChange={(e) => setPartial(e.target.checked)}
          />
          Registrar un pago parcial y conservar el saldo
        </label>
        {entries.map((entry, index) => {
          const amount = allocatedInput ? cents(entry.amount) : total;
          const original = cents(entry.tendered);
          let received = original;
          try {
            if (entry.currency === 'USD')
              received = exchangeRate ? usdToMxn(original, exchangeRate) : 0;
          } catch {
            received = 0;
          }
          let preview: { change_mxn: number; change_usd: number } | undefined;
          try {
            preview = preparePayments(
              amount,
              [
                {
                  method: 'cash',
                  tendered: original,
                  currency: entry.currency,
                  changeCurrency: entry.changeCurrency,
                },
              ],
              { rate: exchangeRate, usdChange },
            )[0];
          } catch {
            /* Await complete input. */
          }
          const suffix = multiple ? ` · pago ${index + 1}` : '';
          return (
            <fieldset
              className={`payment-entry ${multiple ? 'split-entry' : ''}`}
              key={entry.key}
              disabled={busy}
            >
              {multiple && <legend>Pago {index + 1}</legend>}
              {multiple ? (
                <div className="payment-entry-heading">
                  <label className="grow">
                    Método de pago {index + 1}
                    <select
                      value={entry.method}
                      onChange={(event) =>
                        update(entry.key, {
                          method: event.target.value as PaymentMethod,
                          reference: '',
                        })
                      }
                    >
                      {Object.entries(PAYMENT_LABELS).map(([method, label]) => (
                        <option key={method} value={method}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <button
                    type="button"
                    className="icon-button danger-text"
                    aria-label={`Eliminar pago ${index + 1}`}
                    onClick={() =>
                      setEntries((previous) => {
                        const remaining = previous.filter((item) => item.key !== entry.key);
                        return remaining.length === 1
                          ? [{ ...remaining[0], amount: decimal(total) }]
                          : remaining;
                      })
                    }
                  >
                    <Trash2 size={19} />
                  </button>
                </div>
              ) : (
                <div className="payment-tabs" role="group" aria-label="Forma de pago">
                  {Object.entries(PAYMENT_LABELS).map(([method, label]) => {
                    const Icon = icons[method as PaymentMethod];
                    return (
                      <button
                        type="button"
                        key={method}
                        aria-pressed={entry.method === method}
                        onClick={() =>
                          update(entry.key, { method: method as PaymentMethod, reference: '' })
                        }
                      >
                        <Icon size={21} />
                        <span>{label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
              {allocatedInput && (
                <label>
                  Importe del pago {index + 1} (MXN)
                  <input
                    required
                    inputMode="decimal"
                    value={entry.amount}
                    onChange={(event) => update(entry.key, { amount: event.target.value })}
                    placeholder="0.00"
                  />
                </label>
              )}
              {entry.method === 'cash' ? (
                <>
                  <div className="form-row">
                    <label>
                      Moneda recibida{suffix}
                      <select
                        aria-label={`Moneda recibida${suffix}`}
                        value={entry.currency}
                        onChange={(e) =>
                          update(entry.key, {
                            currency: e.target.value as 'MXN' | 'USD',
                            tendered: '',
                          })
                        }
                      >
                        <option value="MXN">Pesos · MXN</option>
                        <option value="USD" disabled={!exchangeRate}>
                          Dólares · USD
                        </option>
                      </select>
                    </label>
                    <label>
                      Entregar cambio{suffix}
                      <select
                        aria-label={`Entregar cambio${suffix}`}
                        value={entry.changeCurrency}
                        onChange={(e) =>
                          update(entry.key, { changeCurrency: e.target.value as 'MXN' | 'USD' })
                        }
                      >
                        <option value="MXN">Pesos · MXN</option>
                        <option value="USD" disabled={!usdChange || !exchangeRate}>
                          Dólares + residuo MXN
                        </option>
                      </select>
                    </label>
                  </div>
                  <label>
                    Efectivo recibido{suffix} ({entry.currency})
                    <input
                      data-autofocus={!multiple ? '' : undefined}
                      className={!multiple ? 'cash-input' : ''}
                      required
                      inputMode="decimal"
                      value={entry.tendered}
                      onChange={(event) => update(entry.key, { tendered: event.target.value })}
                      placeholder="0.00"
                    />
                  </label>
                  <div className="cash-shortcuts">
                    <button
                      type="button"
                      className="secondary"
                      onClick={() =>
                        update(entry.key, {
                          tendered: decimal(
                            entry.currency === 'USD' && exchangeRate
                              ? Number(
                                  (BigInt(amount) * 10000n + BigInt(exchangeRate) - 1n) /
                                    BigInt(exchangeRate),
                                )
                              : amount,
                          ),
                        })
                      }
                    >
                      Exacto{multiple ? ` · pago ${index + 1}` : ''}
                    </button>
                    {!multiple &&
                      entry.currency === 'MXN' &&
                      [Math.ceil(amount / 10000) * 100, Math.ceil(amount / 50000) * 500]
                        .filter(
                          (n, i, values) =>
                            n > amount / 100 && n < 999999 && values.indexOf(n) === i,
                        )
                        .map((value) => (
                          <button
                            key={value}
                            type="button"
                            className="secondary"
                            onClick={() => update(entry.key, { tendered: value.toFixed(2) })}
                          >
                            ${value.toLocaleString('es-MX')}
                          </button>
                        ))}
                  </div>
                  <div className={`change-box ${received < amount ? 'insufficient' : ''}`}>
                    <span>
                      {received < amount ? 'Faltan' : 'Cambio'}
                      {suffix}
                    </span>
                    <strong>
                      {preview
                        ? `${currencyMoney(preview.change_mxn, 'MXN')}${preview.change_usd ? ` + ${currencyMoney(preview.change_usd, 'USD')}` : ''}`
                        : money(Math.abs(received - amount))}
                    </strong>
                  </div>
                </>
              ) : (
                <>
                  <p className="manual-payment-notice">
                    Registro manual de {PAYMENT_LABELS[entry.method].toLowerCase()}. Verifica el
                    pago antes de confirmar; AVILES POS no cobra en tu terminal ni consulta tu
                    banco.
                  </p>
                  <label>
                    {multiple
                      ? `Referencia del pago ${index + 1} (opcional)`
                      : 'Referencia (opcional)'}
                    <input
                      maxLength={120}
                      value={entry.reference}
                      onChange={(event) => update(entry.key, { reference: event.target.value })}
                      placeholder="Folio, autorización o referencia"
                    />
                  </label>
                </>
              )}
            </fieldset>
          );
        })}
        {entries.length + previousCount < MAX_PAYMENTS && total >= 2 && (
          <button
            type="button"
            className="secondary"
            disabled={busy}
            onClick={() =>
              setEntries((previous) => {
                if (previous.length === 1) {
                  const first = Math.ceil(total / 2);
                  return [
                    { ...previous[0], amount: decimal(first) },
                    {
                      key: crypto.randomUUID(),
                      currency: 'MXN',
                      changeCurrency: 'MXN',
                      method: 'card',
                      amount: decimal(total - first),
                      tendered: '',
                      reference: '',
                    },
                  ];
                }
                return [
                  ...previous,
                  {
                    key: crypto.randomUUID(),
                    currency: 'MXN',
                    changeCurrency: 'MXN',
                    method: 'card',
                    amount: '',
                    tendered: '',
                    reference: '',
                  },
                ];
              })
            }
          >
            <Plus size={18} />
            {multiple ? 'Agregar forma de pago' : 'Dividir pago'}
          </button>
        )}
        {multiple && (
          <div className="payment-allocation" aria-live="polite">
            <div>
              <span>Total distribuido</span>
              <strong>{money(allocated)}</strong>
            </div>
            <div className={allocated === total ? 'status-text' : 'danger-text'}>
              <span>{allocated > total ? 'Exceso distribuido' : 'Falta distribuir'}</span>
              <strong data-testid="payment-remaining">{money(Math.abs(total - allocated))}</strong>
            </div>
            <div>
              <span>Cambio total en efectivo</span>
              <strong>{money(cashChange)}</strong>
            </div>
          </div>
        )}
        <p className="field-hint">
          Se guardarán los pagos al confirmar. Un pago parcial conserva el saldo y bloquea cambios
          de importe; el inventario se descuenta al liquidar. El cambio en USD entrega cualquier
          residuo de centavos en MXN.
        </p>
      </div>
      <button className="primary large" disabled={busy || !valid}>
        {busy ? 'Registrando pago…' : partial ? 'Registrar pago parcial' : 'Confirmar cobro'}
      </button>
    </form>
  );
}
