# Revisión de impresoras y comandas

**Resultado: NO DISPONIBLE.**

Se inspeccionaron las fuentes AVILES POS 2.1 del ZIP aportado, el checkout seleccionado y sus dependencias. No incluyen transportes de impresora, colas de impresión, áreas de preparación, enrutamiento de comandas ni pruebas automatizadas de esos componentes. No se desarrolló ni reemplazó ese módulo. La exportación de respaldos/CSV/PDF es independiente y no constituye impresión de comandas.

| Verificación solicitada                      | Resultado                                   |
| -------------------------------------------- | ------------------------------------------- |
| Configuración y asignación de impresoras     | Pendiente de integración                    |
| Áreas de preparación y enrutamiento          | Pendiente de integración                    |
| Prevención de duplicados                     | Pendiente de código y pruebas del módulo    |
| Errores y cola de impresión                  | Pendiente de integración                    |
| Compatibilidad con identidad visual 2.2      | Pendiente de acceso a sus pantallas reales  |
| Pruebas automatizadas del módulo             | No disponibles en el material inspeccionado |
| Hardware, conexión, papel y comandas físicas | No ejecutadas                               |

Antes de integrar la otra tarea, revisar diff/archivos concurrentes y conservar ambos trabajos. Después, ejecutar las pruebas disponibles de esa implementación y revisar selectores/estilos bajo los tokens 2.2. Solo emitir OK para el alcance realmente comprobado; si software pasa y falta hardware, clasificar PENDIENTE DE PRUEBA FÍSICA.
