# Punto de restauración y flujos de AVILES POS 2.1

Las fuentes proceden del ZIP aportado por el usuario. Antes de integrarlas, el checkout contenía únicamente un README. Se conservan `/workspace/restoration-aviles-2.1/checkout-before-import.tar.gz` y `source-2.1-original.tar.gz`, además de los adjuntos originales. SHA256 del APK 2.1: `82e5fb7068c6398eacca6e173b3ca3b3febbaa153dfd6b8d4f0b1db0ffe208d4`. No se importan datos comerciales ni claves de firma.

## Flujos que deben conservarse

1. Primera instalación: crear propietario con PIN exclusivo; posteriores accesos únicamente con PIN. Permisos y bloqueo de intentos se verifican en dominio.
2. Apertura obligatoria: fondos MXN/USD y tasa manual; no se puede cobrar sin turno abierto.
3. Venta rápida: búsqueda, lector como teclado, favoritos, categorías, cuadrícula/lista. Agregar, cambiar cantidades, notas, descuento y cliente persiste cada operación.
4. Guardar/recuperar: estacionar ticket sin descontar inventario; recuperar conserva el ticket anterior. Reiniciar recupera el espacio por empleado.
5. Restaurante: áreas y plano; abrir mesa reutiliza su cuenta; transferir, unir, asignar mesero, marcar cobro y liberar verifican permisos. Cobrar cierra la mesa en la misma transacción.
6. Cobro 2.1: MXN, efectivo o registro manual de tarjeta/transferencia/otro, hasta diez partes simultáneas. Un ticket pagado es idempotente. El inventario solo se descuenta al completar la venta.
7. Caja: ingresos, salidas y retiros por moneda; arqueo, consulta, cierre e historial. Cierre guarda diferencias y conserva tickets pendientes.
8. Administración: catálogo con fotografías, clientes, categorías, empleados con permisos, inventario y conteos auditados; configuración y recibos históricos.

## Límites iniciales

Esquema SQLite 4; importes en centavos; fotografías dentro de SQLite. No existen respaldo exportable, recetas, proveedores, compras, anticipos ni cobro USD. El ZIP no incluye módulo de impresoras/comandas. Su desarrollo queda reservado a la otra tarea.

El rediseño está autorizado expresamente por la solicitud 2.2 y reemplaza la antigua restricción visual verde de AGENTS.md. Se mantiene la separación entre `domain`, `db` y `ui`.

Las referencias visuales y resultados de las pruebas se generan en contextos de navegador aislados; cualquier catálogo utilizado en capturas es exclusivamente una fixture de prueba y nunca se instala en la aplicación.
