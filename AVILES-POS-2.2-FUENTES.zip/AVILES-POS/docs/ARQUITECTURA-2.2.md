# Arquitectura 2.2

Extiende el proyecto 2.1; conserva adaptadores, cola de Database, AccessControl, catálogo, Cash, Tables y separación `db/domain/ui`. No introduce servidor ni base paralela. Fotografías siguen dentro de SQLite y forman parte de los respaldos.

## Esquema 5

Las migraciones 1–4 se mantienen; se añade una transacción de actualización 5. Agrega clasificación de control de productos, costo/categoría históricos por línea, tasa y atribución de cancelación en venta, campos físicos y turno/empleado en pagos, identificadores de abonos, ingredientes/insumos, recetas, movimientos/conteos, proveedores, órdenes, líneas y recepciones. Se conservan IDs, ventas, fotografías, empleados, permisos, fondos y mesas. Los pagos anteriores se identifican como MXN y reciben su efectivo/cambio originales y turno disponible. No se inventan costos históricos ni responsables ausentes.

Ingredientes e insumos no se copian al catálogo de venta. `Inventory.smart` amplía el módulo existente. Las compras pueden referir un insumo o un producto directo, con exclusión mutua. Los productos comprados usan `recordStock` y el mismo libro histórico original; una receta descuenta solamente sus ingredientes.

## Precisión y transacciones

- Dinero: centavos enteros. Tasa: MXN/USD con escala 10000. `usdToMxn` usa BigInt y redondeo al centavo más cercano.
- Ingredientes: cantidades enteras de milésimas de su unidad fija. `0.150 kg` se guarda como 150. No hay conversión implícita de kg/g; todas las operaciones del insumo usan la unidad elegida.
- Costo ponderado: BigInt; costo por unidad en centavos. Receta: cada componente se redondea al centavo; el costo de la línea se captura al liquidar.
- Existencias negativas solo se permiten en ventas cuando el administrador selecciona esa política. Movimientos/conteos/compras tienen sus propias validaciones y auditoría.
- La recepción valida pendientes y usa un identificador único. Recibir otra vez el mismo identificador no incrementa stock.
- Un conteo de insumo conserva teórico/contado y actor; la autorización requiere rol administrativo y permiso de inventario. Si el stock cambió, se rechaza el ajuste hasta volver a contar.

## Cobro y recuperación

`Pos.collect` comparte reglas entre cobro completo y abonos. La venta conserva tasa al registrar la primera parte; cambiar configuración no recalcula lo guardado. La suma de pagos determina saldo. Cada parte conserva turno, empleado, moneda, efectivo original y cambio físico. Los métodos manuales no ejecutan operaciones bancarias.

Un abono no descuenta inventario ni cierra mesa. Bloquea modificación/cancelación de importes y unión de cuentas; puede estacionarse y recuperarse. Se reservan como máximo diez posiciones, con la última para liquidar. El UUID de operación permite reintentar el mismo abono sin duplicarlo. El estado pagado conserva la idempotencia original del cobro completo.

Al liquidar, validación de existencias, stock de productos, ingredientes, costos/categorías históricos, último pago, estado de venta, cierre de mesa y siguiente borrador comparten una transacción. Un error revierte todo. Los campos de caja usan pagos por turno propio, incluidos abonos de ventas aún abiertas; no vuelven a sumarse al finalizar en otro turno.

Cambio USD: redondeo hacia abajo de la cantidad en USD; el residuo se entrega y registra en MXN. Antes de cobrar se verifica efectivo disponible por moneda. Los cortes mantienen físicamente ambos fondos, recibidos, cambios, movimientos, contados y diferencias.

## Respaldos consistentes

Formato JSON versión 1: `manifest` y `payload`. Manifiesto incluye application_id, app_version, schema_version, created_at, tamaño UTF-8 del payload, SHA-256 y conteos. Payload contiene columnas y filas de todas las tablas de usuario, incluidas fotos/configuraciones/credenciales locales derivadas. No contiene PIN en texto plano ni claves de firma. Los archivos sí contienen información comercial y hashes de acceso: deben guardarse privadamente.

La exportación obtiene BEGIN IMMEDIATE en la misma cola transaccional y consulta las filas desde SQLite. Lee una instantánea consistente que incluye páginas confirmadas en WAL; no copia el archivo .db vivo ni hace un checkpoint destructivo. PRAGMA integrity_check y foreign_key_check validan el origen.

La inspección verifica tamaño, manifiesto, SHA256, tablas, columnas, tipos y conteos; reconstruye únicamente una base temporal WASM, aplica restricciones y migra la copia. Valida configuración y ticket activo. No interpreta SQL proporcionado por el archivo. Las sentencias SQL y esquemas proceden de las migraciones del proyecto.

La restauración requiere administrador con permiso de configuración, frase RESTAURAR y digest de una copia de recuperación actual. UI exige exportarla y confirmar que se guardó. Si la base cambió después de exportar, exige una copia nueva. La sustitución de filas en la base real se realiza dentro de una transacción con claves foráneas diferidas y chequeos antes de commit. No elimina ni reconstruye el archivo de base. Se registra restauración como evento de sistema y se cierra sesión. Un fallo de persistencia WASM restaura la imagen previa; el adaptador nativo conserva rollback SQLite.

Exportación web usa descarga; el navegador no permite certificar que el usuario conservó el archivo y exige su confirmación. Android usa DocumentsPlugin y Storage Access Framework (`ACTION_CREATE_DOCUMENT`), con selección explícita de destino, sin permisos generales de almacenamiento. El flujo nativo sigue pendiente de prueba física. Límite de importación: 100 MB; grandes catálogos fotográficos requieren perfilar memoria en la tableta.

## Reportes

Ingresos de venta se reconocen al liquidar; cobros usa fecha de cada pago. Se consultan periodos ISO calculados desde fechas locales y se filtra por responsable conocido. Comparaciones usan el tiempo transcurrido equivalente del periodo anterior; faltas de datos se muestran como tales.

Producto/categoría usan ingreso después de descuento, sin impuestos. El descuento se distribuye por pesos enteros conservando la suma exacta. Los costos capturados no cambian al editar el catálogo. Líneas antiguas sin costo se marcan incompletas. Margen bruto no representa utilidad neta.

CSV incluye desglose y protege campos de texto contra fórmulas de hoja de cálculo. PDF paginado se genera offline con Helvetica/WinAnsi; caracteres fuera de Latin-1 se sustituyen por espacios. No incorpora fotos ni gráficos en PDF. Las gráficas de la aplicación usan exclusivamente resultados consultados.

## Diseño y convivencia

Tokens en `src/design/tokens.css`; distribución y componentes comunes en styles.css. Navegación lateral, categorías superiores, catálogo y ticket separados; adaptación a móvil sin perder cuenta. Se conserva la lógica comercial y el foco/teclado de Modal. Existe base de tokens para tema oscuro, sin presentarlo como tema completo certificado.

No se desarrolla impresión/comandas. `DocumentsPlugin` exporta archivos y no imprime ni administra colas de comandas. No se tocaron archivos de una implementación de impresoras; los adjuntos inspeccionados no incluyen esa implementación.
