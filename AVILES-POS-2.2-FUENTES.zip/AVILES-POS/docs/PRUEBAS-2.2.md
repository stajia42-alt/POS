# Registro de pruebas — AVILES POS 2.2

## Resultado reproducible en este entorno

| Comprobación                          | Resultado                                                                                      |
| ------------------------------------- | ---------------------------------------------------------------------------------------------- |
| Baseline 2.1: lógica/persistencia     | 85 aprobadas                                                                                   |
| Baseline 2.1: navegador               | 18 flujos aprobados                                                                            |
| 2.2: `npm test`                       | 121 aprobadas, 10 archivos; sin omitidas ni esperadas fallidas                                 |
| 2.2: `npm run build`                  | TypeScript y Vite aprobados                                                                    |
| 2.2: `npm run test:e2e`               | 23 flujos aprobados; sin omitidos                                                              |
| PDF: `pdfinfo` y `pdftotext`          | PDF 1.4/A4 válido; prueba paginada con 120 líneas, acentos y paréntesis recuperada íntegra     |
| Formato                               | `npm run format:check` aprobado                                                                |
| Instalación reutilizable              | `bash scripts/setup-cloud.sh` repetido y aprobado                                              |
| Inicio de desarrollo                  | Vite + SQLite + pantalla de propietario en contexto aislado aprobado                           |
| Artefacto Android                     | Firma debug válida, alineación 16 KB, 11 recursos web idénticos a dist y SQLite arm64 incluido |
| Proyecto Android                      | `assembleDebug` con JDK 21, SDK 36 y Gradle 8.14.3 aprobado                                    |
| Firma de APK anteriores               | APK 1.1, 1.2 y 2.1 verificados con mismo certificado                                           |
| Actualización compatible del APK      | Pendiente de keystore original; certificado de esta máquina diferente                          |
| Instalación/tableta/SQLite nativo/SAF | No ejecutadas; plan físico separado                                                            |
| Impresoras/comandas                   | NO DISPONIBLE                                                                                  |

Herramientas: Node 24.19, npm, Chromium del entorno, SQL.js/WASM, Python SQLite de archivo y WAL. No se sustituyen los resultados Android nativos por las pruebas WASM.

## Cobertura nueva

- Respaldo con fotos, pendientes, configuración y empleados; SHA256; rechazo de archivo alterado/tipos inválidos; referencias/integridad; copia de recuperación vigente; restauración explícita y rollback por fallo de disco; instantánea consistente frente a operaciones en cola.
- Recetas y costo exacto por cantidades de milésimas; faltantes revierten pagos/stock; guardado pendiente sin descuento; reintento de cobro sin duplicación.
- Compras parciales/idempotentes, costo promedio, precio recibido, proveedores, recepción de producto en libro original, rechazo de exceso y rollback de recepción; conteos pendientes y autorización, incluido esperado desactualizado.
- MXN/USD, combinados, tipo de cambio histórico, cambio USD con residuo MXN, fondo insuficiente para cambio, turno cerrado, abonos persistentes, edición/cancelación bloqueadas, caja entre turnos sin duplicación y mesa abierta hasta liquidar.
- Reportes sin datos inventados, costos anteriores inmutables/incompletos explícitos, filtros de empleado, periodos equivalentes, exportación CSV segura y PDF paginado.
- Migraciones ejecutadas desde las fuentes históricas independientes de los ZIP 1.0, 1.1, 1.2 y 2.1. Se comparan productos/fotos, ventas/pendientes, pagos, empleados/permisos y mesas disponibles; se repite migración y se revisan integridad/referencias.
- DDL de esquema 5 ejecutado sobre SQLite de archivo con WAL. Es una comprobación de compatibilidad SQL, no una prueba del adaptador Capacitor/SQLCipher.

## Interfaz

Los 18 flujos originales se conservan. Se añaden cuatro flujos comerciales de respaldo/restauración, receta/compra/costo, abono/USD/exportación y conteo/corrupción. Un flujo visual recorre pantallas principales y genera capturas; verifica ausencia de desbordamiento global y límites de ventanas a 1280×800, 1024×600, 960×600, 893×533 y 390×844. La confirmación de cobro permanece visible; los detalles se desplazan dentro del diálogo.

Las capturas usan datos de prueba creados por la interfaz en contextos temporales. No describen resultados comerciales del usuario. No se han medido latencia táctil, memoria ni teclado/insets reales de Samsung.

## Diagnóstico de ejecuciones iniciales

Una ejecución inicial del navegador se interrumpió por reinstalación simultánea de node_modules; otra compartió puerto/carpeta de resultados con una suite concurrente. Se eliminaron esas interferencias y las suites se ejecutaron secuencialmente hasta completar la regresión. Los resultados finales de la tabla corresponden a ejecuciones completas. Las restricciones de ejecución en secuencia están en AGENTS.md.

No hay pruebas físicas aprobadas, omitidas que se cuenten como aprobadas, ni certificación comercial. Los pendientes concretos están en AVILES_POS_PROGRESO.md y PRUEBAS-FISICAS-2.2.md.
