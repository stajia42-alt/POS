# Validación física pendiente — Samsung Galaxy Tab A11 8.7 horizontal

Estas comprobaciones **no se han ejecutado** en este entorno. Chromium y SQLite WASM no sustituyen SQLite/SQLCipher ni el selector de archivos Android. No hay tableta conectada ni aceleración KVM disponible.

1. Recuperar keystore original y verificar que el certificado coincide con los APK 1.1/1.2/2.1. Instalar una actualización firmada compatible sobre una instalación de prueba existente, sin desinstalar/borrar almacenamiento. Comprobar productos, fotos, ventas, empleados/PIN, permisos, mesas e inventario.
2. Primera instalación en perfil de prueba separado: crear propietario y abrir/cerrar turno con fondos MXN/USD.
3. Verificar migración nativa a esquema 5, reiniciar varias veces, matar proceso Android con una venta y una mesa pendientes y con un abono ya confirmado. Revisar cantidades, turno, saldo y ausencia de pagos duplicados.
4. Cobrar $350 MXN con $20 USD a 18 y verificar $10 MXN de cambio, fondos físicos/corte. Repetir combinados, parcial y liquidación en otro turno; probar falta de cambio y falta de ingredientes.
5. Crear ingredientes, receta, compra parcial, recepción, conteo/autorización; comprobar cantidades y costos después de reiniciar.
6. Crear respaldo desde SQLite nativo con fotos, exportarlo mediante selector de documentos a una ubicación fuera de la app, confirmar fecha/tamaño/versión e integridad. Cancelar selector y simular falta de espacio.
7. En perfil de prueba, exportar recuperación, restaurar copia anterior, reiniciar y volver a restaurar la copia de recuperación. Probar archivo truncado/alterado, referencias inválidas y versión futura; deben rechazarse sin cambios.
8. Revisar las pantallas, teclado Android, insets, diálogos, foco, estados y desplazamiento táctil en ambos sentidos horizontales. Verificar legibilidad real, controles y ausencia de elementos fuera de pantalla con teclado visible.
9. Exportar CSV y PDF vía selector nativo, abrirlos fuera de AVILES POS y verificar contenido/acentos/paginación. Medir memoria y tiempos con el catálogo fotográfico real en una copia privada.
10. Impresoras y comandas: esperar integración de la tarea correspondiente; aplicar REVISION_IMPRESORAS.md y pruebas de hardware.

Registrar modelo, Android/WebView, versión/certificado del APK, tamaño de base, resultado y evidencia. No usar datos comerciales como fixtures ni desinstalar la aplicación existente para resolver una firma distinta.
