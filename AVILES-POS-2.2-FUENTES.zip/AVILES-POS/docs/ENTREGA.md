# Entrega de AVILES POS 2.2

Se evoluciona el proyecto 2.1 existente aportado por el usuario. El checkout seleccionado originalmente solo contenía README; se integraron las fuentes, Android, pruebas y documentación del ZIP conservando una copia previa. No se reemplaza por otra aplicación ni se cambian identificador o base de almacenamiento.

Incluye sistema de diseño completo, respaldo/restauración, inventario inteligente, pagos/abonos MXN/USD y reportes CSV/PDF. Los flujos anteriores de PIN, apertura/cierre, venta rápida, productos, tickets, mesas, empleados y clientes siguen cubiertos por regresión. La única migración nueva es la 5; las anteriores se preservan.

Consulte AVILES_POS_PROGRESO.md para fases/terminados/pendientes, docs/PRUEBAS-2.2.md para resultados y docs/capturas/README.md para la galería.

El APK de prueba usa `mx.aviles.pos`, versión 2.2.0 y versionCode 5. **No es una actualización firmada compatible con los APK anteriores.** Falta el keystore original; no se debe desinstalar ni borrar datos para resolverlo. SQLite nativo, importación/exportación Android y tableta física permanecen pendientes de la prueba descrita en docs/PRUEBAS-FISICAS-2.2.md.

Impresoras/comandas no están integradas en el material recibido. No se implementó otro módulo. REVISION_IMPRESORAS.md clasifica NO DISPONIBLE y enumera revisiones pendientes.

No hay servidor externo, pagos bancarios automáticos, datos de muestra precargados, PIN predeterminado ni claves de firma incluidas. Las capturas y pruebas usan contextos aislados y datos explícitos de prueba. La clave actual de depuración permanece fuera del repositorio y de los ZIP de entrega.
