# Firma y actualización Android

Identificador conservado: `mx.aviles.pos`. Versión 2.2.0 / versionCode 5. No se distribuyen claves de firma.

Certificado SHA256 observado en los APK aportados 1.1, 1.2 y 2.1:

`8b8918bc440fd84984f0a4de6aef8cb584e4eb61dde22f1b2ac0e7fd11f04754`

El certificado de depuración generado en esta máquina es distinto:

`ec6eafcdae1c570936a0b2dc17294f1f44839d5e903b1b5c0c1d58298834eed5`

Los ZIP inspeccionados (fuentes 1.0/1.1 y completos 1.2/2.1) no contienen `.jks`, `.keystore`, `.p12` ni claves PEM. El PIN del empleado no sirve para firmar APK. La clave privada no se recupera del certificado público dentro del APK.

El APK de esta entrega es de prueba y solo puede instalarse donde no exista una instalación firmada de manera incompatible. Para actualizar la app existente se debe recuperar el keystore utilizado en la máquina/entorno original, habitualmente su clave debug local, o compilar allí con la misma clave. No desinstalar ni borrar almacenamiento para resolver el conflicto.

Para firma externa, configura fuera del repositorio `AVILES_KEYSTORE_FILE`, `AVILES_KEY_ALIAS`, `AVILES_STORE_PASSWORD` y `AVILES_KEY_PASSWORD`; no guardes valores en archivos versionados, scripts, argumentos del chat o documentación. Las contraseñas son valores locales del proceso de firma, no credenciales de una API/proxy.

```bash
# Con la clave original y variables ya inyectadas de manera segura:
npm run android:sync
cd android
./gradlew --no-daemon --max-workers=2 assembleRelease
# Verificar certificado del resultado con apksigner antes de distribuirlo.
```

La configuración release utiliza estas variables solo si AVILES_KEYSTORE_FILE está definido. Sin él, el resultado release queda sin firma; no se presenta como actualización instalable. Este camino de firma original no está verificado porque falta la clave. La compilación debug sí se valida por separado. Instalar sobre 2.1 y conservar datos sigue pendiente de esa clave y de la prueba Android correspondiente.
