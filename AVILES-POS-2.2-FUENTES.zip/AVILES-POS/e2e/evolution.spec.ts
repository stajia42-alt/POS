import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { ready, createProduct, navigate, reload, unlock } from './helpers';

async function settled(page: import('@playwright/test').Page) {
  await expect(page.getByTestId('app-ready')).toHaveAttribute('aria-busy', 'false');
}
test('respaldo completo exportado, validado y restaurado con autorización explícita', async ({
  page,
}) => {
  await ready(page);
  await createProduct(page, 'Producto respaldado', '140.00', true, undefined, 5);
  await navigate(page, 'Punto de venta');
  await page.getByRole('button', { name: 'Agregar Producto respaldado', exact: true }).click();
  await settled(page);
  await navigate(page, 'Respaldos');
  const downloadEvent = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Crear y exportar respaldo', exact: true }).click();
  const file = await downloadEvent;
  const buffer = await readFile((await file.path())!);
  const data = JSON.parse(buffer.toString());
  expect(data.manifest.counts.products).toBe(1);
  expect(data.payload.products.rows[0].join(' ')).toContain('data:image/jpeg;base64');
  await createProduct(page, 'Producto posterior', '20.00');
  await navigate(page, 'Respaldos');
  await page
    .getByLabel('Archivo de respaldo', { exact: true })
    .setInputFiles({ name: 'respaldo.json', mimeType: 'application/json', buffer });
  await expect(page.getByText('Archivo íntegro', { exact: true })).toBeVisible();
  const recovery = page.waitForEvent('download');
  await page
    .getByRole('button', { name: 'Exportar copia de recuperación actual', exact: true })
    .click();
  await recovery;
  await page.getByLabel('Escribe RESTAURAR para confirmar', { exact: true }).fill('RESTAURAR');
  const restore = page.getByRole('button', { name: 'Restaurar y cerrar sesión', exact: true });
  await expect(restore).toBeDisabled();
  await page
    .getByLabel('He guardado la copia de recuperación fuera de la aplicación', { exact: true })
    .check();
  await restore.click();
  await unlock(page);
  await navigate(page, 'Productos');
  await expect(page.getByText('Producto respaldado', { exact: true })).toBeVisible();
  await expect(page.getByText('Producto posterior', { exact: true })).toHaveCount(0);
  await navigate(page, 'Punto de venta');
  await expect(
    page.getByRole('button', { name: 'Cantidad de Producto respaldado', exact: true }),
  ).toHaveText('1');
});

test('ingredientes, receta, proveedor, recepción parcial y venta con costo histórico', async ({
  page,
}) => {
  await ready(page);
  await createProduct(page, 'Hamburguesa prueba', '140.00');
  await navigate(page, 'Inventario');
  await page.getByRole('button', { name: 'Ingredientes e insumos', exact: true }).click();
  for (const i of [
    { name: 'Pan prueba', unit: 'pieza', stock: '10', cost: '10.00', low: '2' },
    { name: 'Carne prueba', unit: 'kg', stock: '2', cost: '320.00', low: '0.5' },
  ]) {
    await page.getByRole('button', { name: 'Crear insumo', exact: true }).click();
    const d = page.getByRole('dialog');
    await d.getByLabel('Nombre del insumo', { exact: true }).fill(i.name);
    await d.getByLabel('Unidad base', { exact: true }).selectOption(i.unit);
    await d.getByLabel('Costo por unidad (MXN)', { exact: true }).fill(i.cost);
    await d.getByLabel('Existencia mínima', { exact: true }).fill(i.low);
    await d.getByLabel('Existencia inicial', { exact: true }).fill(i.stock);
    await d.getByRole('button', { name: 'Guardar insumo', exact: true }).click();
    await expect(d).toHaveCount(0);
  }
  await page.getByRole('button', { name: 'Compras y proveedores', exact: true }).click();
  await page.getByRole('button', { name: 'Crear proveedor', exact: true }).click();
  await page.getByLabel('Nombre del proveedor', { exact: true }).fill('Proveedor prueba');
  await page.getByRole('button', { name: 'Guardar proveedor', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Crear orden', exact: true }).click();
  await page
    .getByLabel('Proveedor de la orden', { exact: true })
    .selectOption({ label: 'Proveedor prueba' });
  await page
    .getByLabel('Insumo de compra 1', { exact: true })
    .selectOption({ label: 'Pan prueba (pieza)' });
  await page.getByLabel('Cantidad de compra 1', { exact: true }).fill('5');
  await page.getByLabel('Costo unitario de compra 1', { exact: true }).fill('12.00');
  await page.getByRole('button', { name: 'Guardar orden de compra', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Recibir', exact: true }).click();
  await page.getByLabel('Recibido · Pan prueba (pieza)', { exact: true }).fill('2');
  await page.getByRole('button', { name: 'Confirmar recepción', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.getByText('Recepción parcial', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Recetas', exact: true }).click();
  await page.getByRole('button', { name: 'Configurar receta', exact: true }).click();
  await page.getByRole('button', { name: 'Agregar ingrediente', exact: true }).click();
  await page
    .getByLabel('Ingrediente 1', { exact: true })
    .selectOption({ label: 'Pan prueba (pieza)' });
  await page.getByLabel('Cantidad 1', { exact: true }).fill('1');
  await page.getByRole('button', { name: 'Agregar ingrediente', exact: true }).click();
  await page
    .getByLabel('Ingrediente 2', { exact: true })
    .selectOption({ label: 'Carne prueba (kg)' });
  await page.getByLabel('Cantidad 2', { exact: true }).fill('0.150');
  await page.getByRole('button', { name: 'Guardar receta', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.getByText('$58.33 MXN', { exact: false }).first()).toBeVisible();
  await navigate(page, 'Punto de venta');
  await page.getByRole('button', { name: 'Agregar Hamburguesa prueba', exact: true }).click();
  await settled(page);
  await page.getByRole('button', { name: 'COBRAR', exact: true }).click();
  await page.getByLabel('Efectivo recibido (MXN)', { exact: true }).fill('150');
  await page.getByRole('button', { name: 'Confirmar cobro', exact: true }).click();
  await expect(page.getByTestId('receipt')).toBeVisible();
  await page.getByRole('button', { name: 'Nueva venta', exact: true }).click();
  await navigate(page, 'Inventario');
  await page.getByRole('button', { name: 'Ingredientes e insumos', exact: true }).click();
  await expect(
    page
      .getByRole('row')
      .filter({ has: page.getByText('Carne prueba', { exact: true }) })
      .first(),
  ).toContainText('1.85 / 0.5');
  await navigate(page, 'Reportes');
  await page.getByRole('button', { name: 'Productos y costos', exact: true }).click();
  await expect(page.getByText('$81.67 MXN', { exact: true }).first()).toBeVisible();
});

test('abono persistido, saldo en USD, caja multimoneda y exportaciones de reporte', async ({
  page,
}) => {
  await ready(page, '100.00');
  await createProduct(page, 'Venta USD prueba', '350.00', false, undefined, 5);
  await navigate(page, 'Punto de venta');
  await page.getByRole('button', { name: 'Agregar Venta USD prueba', exact: true }).click();
  await settled(page);
  await page.getByRole('button', { name: 'COBRAR', exact: true }).click();
  await page.getByLabel('Registrar un pago parcial y conservar el saldo', { exact: true }).check();
  await page.getByLabel('Importe del pago 1 (MXN)', { exact: true }).fill('100');
  await page.getByLabel('Efectivo recibido (MXN)', { exact: true }).fill('100');
  await page.getByRole('button', { name: 'Registrar pago parcial', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.partial-progress')).toContainText('$250.00 MXN');
  await reload(page);
  await expect(page.locator('.partial-progress')).toContainText('$250.00 MXN');
  await page.getByRole('button', { name: 'COBRAR', exact: true }).click();
  await page.getByLabel('Moneda recibida', { exact: true }).selectOption('USD');
  await page.getByLabel('Efectivo recibido (USD)', { exact: true }).fill('14.00');
  await page.getByRole('button', { name: 'Confirmar cobro', exact: true }).click();
  await expect(page.getByTestId('receipt')).toContainText('$14.00 USD');
  await expect(page.getByTestId('receipt')).toContainText('$2.00 MXN');
  await page.getByRole('button', { name: 'Nueva venta', exact: true }).click();
  await navigate(page, 'Reportes');
  await expect(page.getByTestId('report-total')).toHaveText('$350.00 MXN');
  await page.getByRole('button', { name: 'Cobros y caja', exact: true }).click();
  await expect(page.getByText('$14.00 USD', { exact: true })).toBeVisible();
  let event = page.waitForEvent('download');
  await page.getByRole('button', { name: 'CSV', exact: true }).click();
  let download = await event;
  expect((await readFile((await download.path())!)).toString()).toContain('Venta USD prueba');
  event = page.waitForEvent('download');
  await page.getByRole('button', { name: 'PDF', exact: true }).click();
  download = await event;
  expect((await readFile((await download.path())!)).subarray(0, 8).toString()).toBe('%PDF-1.4');
});

test('conteo pendiente y autorización; respaldo alterado rechazado', async ({ page }) => {
  await ready(page);
  await navigate(page, 'Inventario');
  await page.getByRole('button', { name: 'Ingredientes e insumos', exact: true }).click();
  await page.getByRole('button', { name: 'Crear insumo', exact: true }).click();
  await page.getByLabel('Nombre del insumo', { exact: true }).fill('Insumo conteo');
  await page.getByLabel('Existencia inicial', { exact: true }).fill('10');
  await page.getByRole('button', { name: 'Guardar insumo', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Conteos físicos', exact: true }).click();
  await page.getByRole('button', { name: 'Registrar conteo', exact: true }).click();
  await page
    .getByLabel('Insumo contado', { exact: true })
    .selectOption({ label: 'Insumo conteo (pieza) · teórico 10' });
  await page.getByLabel('Cantidad física contada', { exact: true }).fill('8');
  await page.getByLabel('Motivo del conteo', { exact: true }).fill('Conteo prueba');
  await page.getByRole('button', { name: 'Guardar conteo pendiente', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Autorizar ajuste', exact: true }).click();
  await expect(page.getByText('Autorizado', { exact: false }).first()).toBeVisible();
  await navigate(page, 'Respaldos');
  const event = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Crear y exportar respaldo', exact: true }).click();
  const download = await event;
  const file = JSON.parse((await readFile((await download.path())!)).toString());
  file.payload.stock_items.rows[0][1] = 'Alterado';
  await page.getByLabel('Archivo de respaldo', { exact: true }).setInputFiles({
    name: 'alterado.json',
    mimeType: 'application/json',
    buffer: Buffer.from(JSON.stringify(file)),
  });
  await expect(page.getByRole('alert')).toContainText('SHA-256');
  await expect(
    page.getByRole('button', { name: 'Restaurar y cerrar sesión', exact: true }),
  ).toHaveCount(0);
});
