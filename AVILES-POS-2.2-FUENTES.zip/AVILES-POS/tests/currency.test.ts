import { describe, it, expect } from 'vitest';
import { fixture, product } from './support';
import { preparePayments, usdToMxn } from '../src/domain/payments';
import { Database } from '../src/db/database';
import { WasmDriver } from '../src/db/wasm-driver';
import { Pos } from '../src/domain/pos';
import { migrate } from '../src/db/migrations';

describe('cobros multimoneda y parciales', () => {
  it('350 MXN cobrados con 20 USD a 18 generan 10 MXN de cambio', async () => {
    const { pos } = await fixture();
    const pid = await product(pos, { price: 35000 });
    const { active } = await pos.snapshot();
    await pos.addProduct(active.id, pid);
    const receipt = await pos.checkoutPayments(active.id, [
      { method: 'cash', currency: 'USD', tendered: 2000 },
    ]);
    expect(receipt.payment).toMatchObject({
      amount: 35000,
      original_tendered: 2000,
      currency: 'USD',
      exchange_rate: 180000,
      change_mxn: 1000,
      change_usd: 0,
    });
    const r = (await pos.cash.snapshot()).report!;
    expect(r.expected).toBe(9000);
    expect(r.expectedUsd).toBe(2000);
    expect(r.receivedUsd).toBe(2000);
    await pos.checkoutPayments(active.id, [{ method: 'cash', currency: 'USD', tendered: 2000 }]);
    expect((await pos.cash.snapshot()).report!.expectedUsd).toBe(2000);
  });
  it('conserva la tasa histórica y convierte con BigInt', async () => {
    expect(usdToMxn(1, 183333)).toBe(18);
    expect(usdToMxn(100, 180000)).toBe(1800);
    const { pos } = await fixture();
    const pid = await product(pos, { price: 35000 });
    const { active, business } = await pos.snapshot();
    await pos.addProduct(active.id, pid);
    await pos.checkoutPayments(active.id, [{ method: 'cash', currency: 'USD', tendered: 2000 }]);
    await pos.saveBusiness({ ...business, exchangeRate: 200000 });
    expect((await pos.getReceipt(active.id)).payment.exchange_rate).toBe(180000);
  });
  it('pago combinado conserva importes y efectivo separados', async () => {
    const { pos } = await fixture();
    const p = await product(pos, { price: 35000 });
    const { active } = await pos.snapshot();
    await pos.addProduct(active.id, p);
    await pos.checkoutPayments(active.id, [
      { method: 'cash', currency: 'USD', amount: 18000, tendered: 1000 },
      { method: 'cash', amount: 10000, tendered: 10000 },
      { method: 'card', amount: 7000 },
    ]);
    const r = (await pos.cash.snapshot()).report!;
    expect(r.expected).toBe(20000);
    expect(r.expectedUsd).toBe(1000);
    expect(r.cashSales).toBe(28000);
  });
  it('USD de cambio usa centavos disponibles y residuo MXN; no crea dinero', async () => {
    const { pos } = await fixture();
    await pos.cash.move({
      shiftId: (await pos.snapshot()).shift!.id,
      kind: 'in',
      currency: 'USD',
      amount: 1000,
      reason: 'Cambio disponible',
    });
    const { business } = await pos.snapshot();
    await pos.saveBusiness({ ...business, usdChange: true });
    const p = await product(pos, { price: 35000 });
    const { active } = await pos.snapshot();
    await pos.addProduct(active.id, p);
    const r = await pos.checkoutPayments(active.id, [
      { method: 'cash', currency: 'USD', tendered: 2000, changeCurrency: 'USD' },
    ]);
    expect(r.payment.change_usd).toBe(55);
    expect(r.payment.change_mxn).toBe(10);
    expect(usdToMxn(r.payment.change_usd, 180000) + r.payment.change_mxn).toBe(1000);
    const shift = (await pos.cash.snapshot()).report!;
    expect(shift.expectedUsd).toBe(2945);
    expect(shift.expected).toBe(9990);
  });
  it('abono idempotente persiste al reiniciar, bloquea edición y solo liquida stock al final', async () => {
    const { pos, persistence, sqlite } = await fixture();
    const pid = await product(pos, { price: 35000 });
    const { active } = await pos.snapshot();
    await pos.addProduct(active.id, pid);
    const key = crypto.randomUUID();
    const abono = await pos.payPartial(
      active.id,
      [{ method: 'cash', amount: 10000, tendered: 10000 }],
      key,
    );
    expect(abono).toMatchObject({ completed: false, balance: 25000, paid: 10000 });
    await pos.payPartial(active.id, [{ method: 'cash', amount: 10000, tendered: 10000 }], key);
    expect((await pos.snapshot()).products[0].stock).toBe(10);
    expect((await pos.cash.snapshot()).report!.expected).toBe(20000);
    await expect(pos.addProduct(active.id, pid)).rejects.toThrow('pagos parciales');
    await expect(pos.cancel(active.id, 'Prueba')).rejects.toThrow('pagos parciales');
    const reopened = new Pos(
      new Database(new WasmDriver(sqlite, persistence, await persistence.load())),
    );
    await reopened.initialize();
    await reopened.access.login('832641');
    await reopened.restoreWorkspace();
    expect((await reopened.snapshot()).active.paid_amount).toBe(10000);
    await reopened.checkoutPayments(active.id, [
      { method: 'cash', currency: 'USD', tendered: 1400 },
    ]);
    expect((await reopened.snapshot()).products[0].stock).toBe(9);
    expect((await reopened.getReceipt(active.id)).payments).toHaveLength(2);
    expect((await reopened.cash.snapshot()).report!.expected).toBe(19800);
    expect((await reopened.cash.snapshot()).report!.expectedUsd).toBe(1400);
  });
  it('separa abonos de turnos distintos sin duplicarlos', async () => {
    const { pos } = await fixture();
    const p = await product(pos, { price: 20000 });
    const s = await pos.snapshot();
    await pos.addProduct(s.active.id, p);
    await pos.payPartial(
      s.active.id,
      [{ method: 'cash', amount: 10000, tendered: 10000 }],
      crypto.randomUUID(),
    );
    await pos.cash.close(s.shift!.id, 20000, 0);
    await pos.cash.open(5000);
    await pos.checkout(s.active.id, 10000);
    expect((await pos.cash.snapshot()).report!.expected).toBe(15000);
    expect((await pos.cash.getReport(s.shift!.id)).expected).toBe(20000);
  });
  it('stock insuficiente y falta de cambio revierten pagos; no cobra con turno cerrado', async () => {
    const { pos, db } = await fixture();
    const p = await product(pos, { price: 35000 });
    const s = await pos.snapshot();
    await pos.addProduct(s.active.id, p);
    await pos.cash.move({
      shiftId: s.shift!.id,
      kind: 'withdrawal',
      amount: 10000,
      reason: 'Retiro total',
    });
    await expect(
      pos.checkoutPayments(s.active.id, [{ method: 'cash', currency: 'USD', tendered: 2000 }]),
    ).rejects.toThrow('efectivo suficiente');
    expect(await db.read((sql) => sql.query('SELECT * FROM payments'))).toHaveLength(0);
    await pos.cash.close(s.shift!.id, 0, 0);
    await expect(pos.checkout(s.active.id, 35000)).rejects.toThrow('turno está cerrado');
  });
  it('rechaza tasa ausente y cambio USD deshabilitado', () => {
    expect(() =>
      preparePayments(100, [{ method: 'cash', currency: 'USD', tendered: 100 }]),
    ).toThrow('tipo de cambio');
    expect(() =>
      preparePayments(100, [{ method: 'cash', tendered: 100, changeCurrency: 'USD' }], {
        rate: 180000,
      }),
    ).toThrow('habilitado');
  });
  it('migración repetida conserva pagos MXN antiguos e integridad', async () => {
    const { db } = await fixture();
    await migrate(db);
    await migrate(db);
    expect(await db.read((s) => s.query('PRAGMA foreign_key_check'))).toEqual([]);
  });
});
