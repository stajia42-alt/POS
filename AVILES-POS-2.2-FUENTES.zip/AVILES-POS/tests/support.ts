import initSqlJs from 'sql.js';
import { Database } from '../src/db/database';
import { WasmDriver, type Persistence } from '../src/db/wasm-driver';
import { migrate } from '../src/db/migrations';
import { Pos } from '../src/domain/pos';
import type { Product } from '../src/domain/types';
export async function fixture() {
  const sqlite = await initSqlJs();
  const persistence: Persistence & { data?: Uint8Array; fail?: boolean } = {
    async load() {
      return this.data;
    },
    async save(data) {
      if (this.fail) throw new Error('disk full');
      this.data = data.slice();
    },
  };
  const db = new Database(new WasmDriver(sqlite, persistence));
  await migrate(db);
  const pos = new Pos(db);
  await pos.initialize();
  await pos.access.bootstrap({ name: 'Propietario prueba', identifier: 'owner', pin: '832641' });
  await pos.cash.open(10000, 0, 180000);
  return { pos, db, persistence, sqlite };
}
export async function product(pos: Pos, input: Partial<Product> = {}) {
  return pos.saveProduct({
    name: 'Producto prueba',
    sku: '',
    barcode: '',
    description: '',
    category_id: null,
    price: 14000,
    cost: 4800,
    photo: '',
    active: 1,
    favorite: 0,
    track_stock: 1,
    stock: 10,
    unit: 'pieza',
    ...input,
  });
}
