import { describe, it, expect } from 'vitest';
import { fixture, product } from './support';

describe('respaldos consistentes y recuperación', () => {
  it('incluye fotografías, pendientes, empleados, configuración y verifica SHA256', async () => {
    const { pos } = await fixture();
    const pid = await product(pos, { photo: 'data:image/png;base64,aGVsbG8=' });
    const s = await pos.snapshot();
    await pos.addProduct(s.active.id, pid);
    await pos.park(s.active.id, 'Por recuperar');
    const file = await pos.backups.create();
    expect(file.manifest.counts.products).toBe(1);
    expect(file.manifest.counts.employees).toBe(1);
    expect(file.manifest.sha256).toMatch(/^[a-f0-9]{64}$/);
    expect((await pos.backups.inspect(JSON.stringify(file))).manifest.sha256).toBe(
      file.manifest.sha256,
    );
  });
  it('rechaza manipulación antes de restaurar', async () => {
    const { pos } = await fixture();
    await product(pos);
    const f = await pos.backups.create();
    f.payload.products.rows[0][1] = 'Alterado';
    await expect(pos.backups.inspect(JSON.stringify(f))).rejects.toThrow('SHA-256');
    expect((await pos.snapshot()).products[0].name).toBe('Producto prueba');
  });
  it('requiere autorización explícita y copia actual; conserva datos si cambia el origen', async () => {
    const { pos } = await fixture();
    const old = await pos.backups.create();
    await expect(pos.backups.restore(JSON.stringify(old), '', '')).rejects.toThrow('RESTAURAR');
    await product(pos);
    await expect(
      pos.backups.restore(JSON.stringify(old), 'RESTAURAR', old.manifest.sha256),
    ).rejects.toThrow('base cambió');
    expect((await pos.snapshot()).products).toHaveLength(1);
  });
  it('restaura atómicamente y cierra sesión; la copia previa permite deshacer', async () => {
    const { pos } = await fixture();
    await product(pos, { name: 'Original' });
    const target = await pos.backups.create();
    await product(pos, { name: 'Posterior' });
    const recovery = await pos.backups.create();
    await pos.backups.restore(JSON.stringify(target), 'RESTAURAR', recovery.manifest.sha256);
    await pos.access.login('832641');
    expect((await pos.snapshot()).products.map((p) => p.name)).toEqual(['Original']);
    const safety = await pos.backups.create();
    await pos.backups.restore(JSON.stringify(recovery), 'RESTAURAR', safety.manifest.sha256);
    await pos.access.login('832641');
    expect((await pos.snapshot()).products).toHaveLength(2);
  });
  it('un fallo de persistencia revierte toda restauración', async () => {
    const { pos, persistence } = await fixture();
    const target = await pos.backups.create();
    await product(pos);
    const safety = await pos.backups.create();
    persistence.fail = true;
    await expect(
      pos.backups.restore(JSON.stringify(target), 'RESTAURAR', safety.manifest.sha256),
    ).rejects.toThrow('disk full');
    persistence.fail = false;
    expect((await pos.snapshot()).products).toHaveLength(1);
  });
  it('bloquea el acceso sin sesión de administrador', async () => {
    const { pos } = await fixture();
    pos.access.lock();
    await expect(pos.backups.create()).rejects.toThrow();
  });
});

it('rechaza tipos alterados incluso con checksum recalculado', async () => {
  const { pos } = await fixture();
  await product(pos);
  const f = await pos.backups.create();
  const col = f.payload.products.columns.indexOf('price');
  f.payload.products.rows[0][col] = 'corrupto';
  const bytes = new TextEncoder().encode(JSON.stringify(f.payload));
  f.manifest.payload_bytes = bytes.length;
  f.manifest.sha256 = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
    .map((v) => v.toString(16).padStart(2, '0'))
    .join('');
  await expect(pos.backups.inspect(JSON.stringify(f))).rejects.toThrow('Tipo de dato');
});
