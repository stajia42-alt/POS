import { describe, it, expect } from 'vitest';
import { fixture, product } from './support';
import { localDate, reportWindow, reportCsv, csvCell } from '../src/domain/reports';
import { textPdf } from '../src/ui/reportPdf';
const today = () => ({
  from: localDate(new Date()),
  to: localDate(new Date()),
  period: 'day' as const,
});

describe('reportes reales y exportaciones', () => {
  it('sin ventas no inventa promedios, márgenes ni comparaciones', async () => {
    const { pos } = await fixture();
    const r = await pos.reports.snapshot(today());
    expect(r.total).toBe(0);
    expect(r.average).toBeNull();
    expect(r.comparison).toBeNull();
    expect(r.costs.complete).toBe(false);
    expect(r.days).toEqual([]);
  });
  it('separa ventas, anticipos, costos históricos, impuestos y efectivo', async () => {
    const { pos } = await fixture();
    const p = await product(pos, { name: '=Nombre seguro', price: 14000, cost: 4800 });
    const s = await pos.snapshot();
    await pos.addProduct(s.active.id, p);
    await pos.updateTicket(s.active.id, {
      note: '',
      discountBps: 1000,
      label: '',
      customerId: null,
    });
    await pos.checkout(s.active.id, 13000);
    const next = await pos.snapshot();
    await pos.addProduct(next.active.id, p);
    await pos.payPartial(
      next.active.id,
      [{ method: 'cash', amount: 2000, tendered: 2000 }],
      crypto.randomUUID(),
    );
    const r = await pos.reports.snapshot(today());
    expect(r.total).toBe(12600);
    expect(r.sales).toHaveLength(1);
    expect(r.methods[0].amount).toBe(14600);
    expect(r.products[0]).toMatchObject({ count: 1, total: 12600, cost: 4800, margin: 7800 });
    expect(r.costs).toMatchObject({ cost: 4800, margin: 7800, complete: true });
    expect(r.physical).toMatchObject({ receivedMxn: 15000, changeMxn: 400 });
    expect(reportCsv(r)).toContain("'=Nombre seguro");
  });
  it('el costo anterior no cambia al editar el catálogo; filtra por empleado', async () => {
    const { pos } = await fixture();
    const p = await product(pos, { price: 14000, cost: 4800 });
    const s = await pos.snapshot();
    await pos.addProduct(s.active.id, p);
    await pos.checkout(s.active.id, 14000);
    const current = (await pos.snapshot()).products[0];
    await pos.saveProduct({ ...current, cost: 9000 });
    const r = await pos.reports.snapshot({ ...today(), employeeId: s.actor.id });
    expect(r.costs.cost).toBe(4800);
    expect(r.employeesSales[0].label).toBe('Propietario prueba');
    expect((await pos.reports.snapshot({ ...today(), employeeId: 'inexistente' })).total).toBe(0);
  });
  it('periodos equivalentes comparan mismo tiempo transcurrido y validan fechas', () => {
    const w = reportWindow(
      { from: '2026-10-20', to: '2026-10-20', period: 'day' },
      new Date('2026-10-20T12:00:00'),
    );
    expect(new Date(w.end).getTime() - new Date(w.start).getTime()).toBe(
      new Date(w.previousEnd).getTime() - new Date(w.previousStart).getTime(),
    );
    expect(w.equivalent).toBe(true);
    expect(() => reportWindow({ from: '2026-02-31', to: '2026-03-01' })).toThrow('Fecha');
    expect(() => reportWindow({ from: '2026-10-20', to: '2026-10-19' })).toThrow('periodo');
  });
  it('comparación sin periodo anterior y costos heredados incompletos son explícitos', async () => {
    const { pos, db } = await fixture();
    const p = await product(pos);
    const s = await pos.snapshot();
    await pos.addProduct(s.active.id, p);
    await pos.checkout(s.active.id, 14000);
    await db.transaction((sql) => sql.run('UPDATE sale_lines SET cost_total=NULL'));
    const r = await pos.reports.snapshot(today());
    expect(r.comparison).toBeNull();
    expect(r.costs.complete).toBe(false);
    expect(r.products[0].margin).toBeNull();
  });
  it('CSV escapa fórmulas y comillas; PDF tiene páginas y offsets válidos', () => {
    expect(csvCell('=1+1')).toBe('"\'=1+1"');
    expect(csvCell('a"b')).toBe('"a""b"');
    const pdf = textPdf(Array.from({ length: 120 }, (_, i) => `Línea ${i} (MXN) \\ corte`));
    const text = new TextDecoder('latin1').decode(pdf);
    expect(text).toContain('/Count 3');
    expect(text.startsWith('%PDF-1.4')).toBe(true);
    const start = Number(text.match(/startxref\n(\d+)/)![1]);
    expect(String.fromCharCode(...pdf.slice(start, start + 4))).toBe('xref');
  });
});
