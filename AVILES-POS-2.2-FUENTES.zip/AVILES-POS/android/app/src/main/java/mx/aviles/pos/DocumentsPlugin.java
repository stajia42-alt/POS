package mx.aviles.pos;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** User-selected export outside app storage; no storage permission or cloud service required. */
@CapacitorPlugin(name = "Documents")
public class DocumentsPlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        if (call.getString("content") == null || call.getString("name") == null) {
            call.reject("Contenido o nombre de archivo ausente."); return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(call.getString("mime", "application/json").split(";", 2)[0]);
        intent.putExtra(Intent.EXTRA_TITLE, call.getString("name"));
        try { startActivityForResult(call, intent, "documentCreated"); }
        catch (android.content.ActivityNotFoundException error) { call.reject("No hay un selector de documentos disponible en este dispositivo.", error); }
    }
    @ActivityCallback
    private void documentCreated(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Uri uri = result.getData() == null ? null : result.getData().getData();
        if (result.getResultCode() != Activity.RESULT_OK || uri == null) {
            call.reject("Exportación cancelada. No se ha restaurado ni borrado información."); return;
        }
        try (OutputStream stream = getContext().getContentResolver().openOutputStream(uri, "wt")) {
            if (stream == null) throw new java.io.IOException("No se pudo abrir el destino.");
            stream.write(Boolean.TRUE.equals(call.getBoolean("base64", false)) ? android.util.Base64.decode(call.getString("content"), android.util.Base64.DEFAULT) : call.getString("content").getBytes(StandardCharsets.UTF_8));
            stream.flush();
        } catch (Exception error) { call.reject("No se pudo guardar el archivo.", error); return; }
        call.resolve();
    }
}
