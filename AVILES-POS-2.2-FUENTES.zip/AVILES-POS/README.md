# AVILES POS 2.2

Evolución de las fuentes **AVILES POS 2.1** aportadas por el usuario. Conserva React/TypeScript, Capacitor, SQLite, identificador `mx.aviles.pos` y los flujos de venta existentes. No requiere servidor ni Internet para operar. El catálogo inicial permanece vacío.

Incluye identidad azul noche/eléctrico con navegación rápida, acceso PIN, caja obligatoria MXN/USD, venta rápida, cuadrícula/lista, tickets pendientes, mesas, empleados/permisos, clientes e inventario. Se añaden respaldos completos verificados, recetas e ingredientes, proveedores/compras con recepción parcial, conteos autorizados, cobros USD y abonos persistentes, y reportes con CSV/PDF.

**Alcance de validación:** lógica y persistencia en SQLite WASM, SQLite de archivo/WAL, navegador y compilación Android. La prueba física en Samsung Galaxy Tab A11, SQLite/SQLCipher del plugin Android, selector de documentos y periféricos se registra por separado; no está certificada por las pruebas web. Consulta [el progreso](AVILES_POS_PROGRESO.md) y [las pruebas](docs/PRUEBAS-2.2.md).

## Desarrollo

Node ≥22.12 (verificado 24.19), npm, Chromium. Para Android: JDK 21, SDK 36, Build Tools 36.0.0 y wrapper Gradle 8.14.3 con SHA256.

```bash
cd /workspace/POS
bash scripts/setup-cloud.sh
source scripts/cloud-env.sh
npm run dev
```

Fuera de la nube: `npm ci && npm run dev`, con JDK/SDK configurados para compilar Android. Usa el checkout existente; no es necesario crear un worktree. La versión web guarda SQLite en IndexedDB y permite una pestaña por origen. Sus datos son independientes de Android; mantén el mismo origen/puerto para reutilizarlos.

```bash
npm test
npm run build
npm run test:e2e
npm run format:check
npm run android:debug
```

Ejecuta estas operaciones en secuencia. Los instaladores actualizan node_modules; el build web modifica dist y las suites usan puerto 4173/test-results. Las pruebas de interfaz crean datos solo en contextos aislados. `e2e/visual.spec.ts` regenera capturas con datos de prueba identificados en [la galería](docs/capturas/README.md).

## Operación

1. Primera instalación: crea propietario con nombre y PIN propio. Una base existente conserva sus empleados y PIN; no se añade acceso predeterminado.
2. Abre turno con fondos MXN y USD separados. El administrador configura tasa MXN por USD y moneda de cambio desde Configuración.
3. Crea productos/categorías. Vende desde el catálogo; cantidad, notas, descuento y cliente se guardan inmediatamente. GUARDAR conserva el ticket sin descontar inventario.
4. Restaurante: crea áreas y mesas; abrir una mesa recupera su cuenta. Transferir, unir y asignar mesero conservan permisos y auditoría. No se permite unir cuentas con abonos.
5. Cobro: efectivo MXN/USD o registro manual MXN de tarjeta, transferencia y otros; combina hasta diez partes. Los importes aplicados se expresan en MXN. Un abono debe ser menor al saldo y reserva la última parte para liquidarlo. El ticket con pagos queda bloqueado para cambios de importe; no existe devolución de abonos en esta entrega.
6. El cambio USD requiere habilitación y efectivo disponible; se redondea hacia abajo a centavos USD y el residuo se entrega en MXN. Se conserva la tasa de la primera parte. Caja registra recibido/cambio físicamente por moneda e incluye abonos por su turno original.
7. Inventario contiene Productos, Ingredientes e insumos, Recetas, Compras y proveedores y Conteos físicos. Usa la misma unidad base en stock, receta y compra: carne en kg y receta `0.150` kg. Una receta sustituye el stock directo del producto; primero regulariza su stock a cero con motivo. Solo al liquidar se descuentan ingredientes/productos.
8. Las compras de ingredientes y productos con stock se reciben total o parcialmente; registran precio real, proveedor, empleado y promedio ponderado. Los productos directos usan unidades enteras y su libro de inventario existente. Los conteos de insumos requieren autorización de administrador/supervisor y rechazan un esperado desactualizado.
9. Reportes filtra por periodo y empleado. Ventas reconoce tickets liquidados; Cobros incluye abonos por fecha de registro. Costos/margen son estimaciones brutas sin gastos y excluyen impuestos; no se inventan costos históricos ausentes. CSV/PDF funcionan offline.
10. Respaldos requiere administrador: exporta una copia privada fuera de la app. Para restaurar, selecciona un archivo, valida integridad, exporta la copia de recuperación actual, confirma que está guardada y escribe RESTAURAR. Se reemplaza la base en una transacción y se cierra sesión. Conserva la copia previa para deshacer.

## Android y firma de actualización

`npm run android:debug` genera `android/app/build/outputs/apk/debug/app-debug.apk`, versión 2.2.0, versionCode 5, esquema SQLite 5. Se mantiene `mx.aviles.pos`, mínimo API 24, objetivo 36 y orientación horizontal.

**Los APK 1.1, 1.2 y 2.1 aportados están firmados con la misma clave de depuración. La clave de este entorno es diferente y ninguno de los ZIP incluye la original.** El APK generado aquí permite una instalación de prueba en un dispositivo/perfil sin AVILES POS; no es una actualización compatible de la instalación existente. No desinstales ni borres almacenamiento para resolverlo. El PIN del usuario no sustituye la clave de firma. Es necesario recuperar el keystore de la máquina que generó los APK anteriores y firmar allí o usar las variables externas indicadas en [FIRMA-ANDROID.md](docs/FIRMA-ANDROID.md).

La compilación de una variante de prueba no demuestra instalación ni migración nativa en una tableta. El [plan físico](docs/PRUEBAS-FISICAS-2.2.md) mantiene esas comprobaciones pendientes. No se incluyen claves ni APK en Git.

## Documentación

- [Flujos y punto de restauración 2.1](docs/BASELINE-2.1.md).
- [Arquitectura 2.2 y formato de respaldo](docs/ARQUITECTURA-2.2.md).
- [Alcance entregado](docs/ENTREGA.md) y [progreso](AVILES_POS_PROGRESO.md).
- [Resultados](docs/PRUEBAS-2.2.md), [capturas](docs/capturas/README.md), [pendientes físicos](docs/PRUEBAS-FISICAS-2.2.md).
- [Revisión de impresoras](REVISION_IMPRESORAS.md): código no disponible; no se implementó un módulo paralelo.

Los documentos anteriores a 2.2 se conservan como referencia histórica; pueden describir limitaciones ya resueltas por esta versión.
