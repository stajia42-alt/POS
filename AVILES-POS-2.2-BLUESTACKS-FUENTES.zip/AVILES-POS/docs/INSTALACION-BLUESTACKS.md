# AVILES POS 2.2 — Instalación de prueba junto a la versión anterior

El mensaje genérico «La aplicación no pudo ser instalada» se produjo al intentar instalar 2.2 en BlueStacks, donde ya existe una versión anterior. Los APK anteriores y el APK 2.2 publicado tienen el mismo identificador `mx.aviles.pos` y certificados distintos. Android no permite usarlos como actualización compatible.

La variante `sideTest` usa el mismo proyecto y recursos web, con identificador Android `mx.aviles.pos.pruebas` y nombre visible **AVILES POS 2.2 PRUEBAS**. Permite probar la actualización en paralelo. No reemplaza la app anterior ni comparte/importa sus ventas, PIN, productos o SQLite. Al abrir por primera vez solicita crear un propietario y PIN propios. No hay PIN predeterminado.

El identificador de producción `mx.aviles.pos`, su migración y su ruta de actualización permanecen sin cambios. Para actualizar esa instalación conservando sus datos sigue siendo necesaria la clave de firma original. No desinstalar ni borrar almacenamiento para resolver un conflicto de firma.

## Compilar

```bash
cd /workspace/POS
source scripts/cloud-env.sh
npm run android:sync
cd android
./gradlew --no-daemon --max-workers=2 assembleSideTest
```

Resultado de compilación: `android/app/build/outputs/apk/sideTest/app-sideTest.apk`. La entrega al usuario debe hacerse con un enlace HTTPS de descarga, no con esa ruta interna.

## Verificación

Se comprueban compilación, integridad ZIP, firma APK, identificador distinto, nombre visible, proveedor de archivos único, bibliotecas ARM/x86 y recursos web idénticos a 2.2. Esto no equivale a ejecutar una instalación física en el BlueStacks del usuario: esa confirmación queda pendiente de su prueba.

La edición de prueba requiere Android 7.0/API 24 o superior, igual que 2.1 y el APK 2.2 anterior. Si BlueStacks muestra otro fallo al instalar esta variante, se necesita su versión Android y el código completo del instalador/ADB para distinguir incompatibilidad de sistema o un archivo incompleto.
