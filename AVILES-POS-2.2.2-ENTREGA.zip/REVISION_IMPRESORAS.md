# Revisión de impresoras y comandas — 2.2.2

**Resultado: PENDIENTE DE PRUEBA FÍSICA.**

El usuario autorizó implementar el módulo después de confirmar ESC/POS, papel de 80 mm y conexión por IP que ya funciona en Loyverse desde Android. La integración anterior no estaba disponible en los APK/fuentes ni en las ramas AVILES revisadas; se añadió un único módulo en este proyecto, con la distribución 2.2.1 conservada.

| Verificación       | Implementación y evidencia                                                                                                                            |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| Configuración      | IP IPv4, puerto editable (9100 predeterminado), ancho, corte y uso caja/cocina. Persistencia comprobada en interfaz.                                  |
| Enrutamiento       | Categorías por impresora o todos los productos; independiente de áreas de mesas. Borrar categorías no convierte una selección en todos los productos. |
| Tickets            | Documentos de ventas pagadas, pagos MXN/USD y cambio físico, original idempotente y copias autorizadas. Cola guardada junto al cobro.                 |
| Comandas           | Diferencias de cantidades, notas, cancelaciones y avisos de cambios de cuenta sin repetir preparación. Historial transferido al unir mesas.           |
| Cola y orden       | SQLite persistente, FIFO por impresora, fallos bloqueantes por destino y otras impresoras independientes.                                             |
| Cortes de conexión | Fallo antes de escribir separado de resultado incierto; sin reintento automático. Confirmación del operador o copia explícita y auditada.             |
| Transporte Android | Plugin ThermalPrinter, socket TCP fuera de interfaz; conexión 4 s, plazo total 12 s, límite 256 KiB.                                                  |
| Formato            | ESC/POS PC850, 48/32 columnas, texto/envuelta, control de inyección y corte parcial opcional.                                                         |
| Respaldo           | Incluye impresoras y trabajos; restaurar retiene pendientes como inciertos y evita envío automático. No restaura durante un envío.                    |
| Software           | Pruebas de dominio, formatos, cola, interfaz y TCP real contra servidor local. Resultados finales en manifiesto de descarga y progreso.               |
| Hardware           | Pendiente: modelo exacto, IP real, papel, acentos, corte, cocina/bar, red de tableta y reconexión.                                                    |

“Enviado” significa que la escritura al socket terminó. No certifica que salió papel ni que se preparó un pedido. No se declara compatibilidad física completa por compilar el APK o por aprobar pruebas de navegador.

Guía de prueba: [IMPRESORAS-2.2.2.md](docs/IMPRESORAS-2.2.2.md).
